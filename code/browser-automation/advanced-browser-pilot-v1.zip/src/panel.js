import { configFrom, isStartPage } from './core.js';
import { runTask } from './runner.js';
const $ = id => document.getElementById(id);
let controller, pending;
const progress = text => {
  $('result').textContent = text;
  const li = document.createElement('li'); li.textContent = `${new Date().toLocaleTimeString()} · ${text}`; $('log').append(li);
  while ($('log').children.length > 100) $('log').firstChild.remove();
};
function stop() {
  controller?.abort();
  if (pending) { pending.reject(new Error('Run stopped.')); pending = undefined; }
  $('gate').hidden = true;
}
$('stop').addEventListener('click', stop);
$('reject').addEventListener('click', stop);
window.addEventListener('pagehide', stop);
$('config-form').addEventListener('submit', async event => {
  event.preventDefault();
  try {
    const config = configFrom({ endpoint: $('endpoint').value, deployment: $('deployment').value, key: $('key').value });
    if (!await chrome.permissions.request({ origins: [`${config.endpoint}/*`] })) throw new Error('Azure permission denied.');
    await chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
    await chrome.storage.local.set({ advancedConfig: config });
    $('key').value = ''; $('key').placeholder = 'Saved independently — re-enter to change'; $('settings').open = false;
    progress('Configuration saved locally. No model request made.');
  } catch (error) { progress(error.message); }
});
$('forget').addEventListener('click', async () => { stop(); await chrome.storage.local.remove('advancedConfig'); $('key').value = ''; $('key').placeholder = ''; progress('Independent configuration removed. Revoke site permissions in Chrome settings if needed.'); });
$('approve').addEventListener('click', async () => {
  const gate = pending;
  if (!gate) return;
  $('approve').disabled = true;
  try {
    if (!await chrome.permissions.request({ origins: ['http://*/*', 'https://*/*'] })) throw new Error('Website permission denied.');
    if (pending !== gate || controller.signal.aborted) return;
    pending = undefined; $('gate').hidden = true; gate.resolve();
  } catch (error) { if (pending === gate) { pending = undefined; gate.reject(error); } }
  finally { $('approve').disabled = false; }
});
function usage(t) {
  $('tokens-input').textContent = t.input; $('tokens-output').textContent = t.output; $('tokens-total').textContent = t.total; $('token-requests').textContent = t.requests;
  $('usage-note').textContent = t.missing ? `Incomplete totals: ${t.missing} request(s) have no usable usage; ${t.pending} pending.` : `API-reported totals, including vision and summaries. ${t.pending} pending. Not a cost estimate.`;
}
$('start').addEventListener('click', async () => {
  if (controller) return;
  const task = $('task').value.trim();
  if (!task) { progress('Enter instructions first.'); return; }
  controller = new AbortController();
  $('start').disabled = true; $('stop').disabled = false; $('status').textContent = 'Preparing';
  $('config-form').querySelectorAll('input,button').forEach(el => { el.disabled = true; });
  $('log').replaceChildren(); $('results-panel').hidden = true;
  usage({ input: 0, output: 0, total: 0, requests: 0, missing: 0, pending: 0 });
  try {
    const { advancedConfig } = await chrome.storage.local.get('advancedConfig');
    if (!advancedConfig) throw new Error('Save independent Azure credentials first.');
    const config = configFrom(advancedConfig);
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || (!/^https?:/.test(tab.url || '') && !isStartPage(tab.url))) throw new Error('Select a website or a new/blank tab. Other browser-internal pages cannot be automated.');
    $('gate-message').textContent = 'Allow automatic actions, DOM sharing and viewport screenshot sharing for this run?';
    $('gate-preview').textContent = `Azure endpoint: ${config.endpoint}\nDeployment: ${config.deployment}\nTask: ${task}\n\nThis run may navigate websites, click, type, hover, drag, press keys, scroll, submit forms and download files automatically. DOM evidence and, when needed, viewport screenshots are sent ONLY to this configured Azure endpoint. Images may expose any visible private content; screenshots cannot be reliably redacted. Use only non-confidential sites. This extension never opens downloaded files. Chrome debugger access controls only the selected task tab. Keep it active and this panel open. Stop cannot undo actions. Site permissions persist until revoked. No CAPTCHA, login, payment or native-dialog automation.`;
    $('gate').hidden = false; $('status').textContent = 'Consent required';
    await new Promise((resolve, reject) => { pending = { resolve, reject }; });
    controller.signal.throwIfAborted(); $('status').textContent = 'Running';
    await runTask({ tabId: tab.id, task, config, consent: true, signal: controller.signal, onProgress: progress, onUsage: usage, onResult: result => {
      $('results-panel').hidden = false; $('summary').textContent = result.report; $('results-note').textContent = result.note; $('summary-source').textContent = `Observed page: ${result.source}`;
    } });
    $('status').textContent = 'Completed'; progress('Run finished. Review the results and page.');
  } catch (error) {
    $('status').textContent = controller.signal.aborted ? 'Stopped' : 'Failed'; progress(controller.signal.aborted ? 'Run stopped. Completed actions cannot be undone.' : error.message);
  } finally {
    controller.abort(); controller = undefined; pending = undefined; $('gate').hidden = true;
    $('start').disabled = false; $('stop').disabled = true;
    $('config-form').querySelectorAll('input,button').forEach(el => { el.disabled = false; });
  }
});
try {
  await chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
  const { advancedConfig } = await chrome.storage.local.get('advancedConfig');
  if (advancedConfig) { $('endpoint').value = advancedConfig.endpoint; $('deployment').value = advancedConfig.deployment; $('key').placeholder = 'Saved independently — re-enter to change'; $('settings').open = false; }
} catch { progress('Could not load independent settings.'); }
