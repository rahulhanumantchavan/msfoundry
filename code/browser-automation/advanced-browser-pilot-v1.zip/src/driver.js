import { browserTool } from './dom.js';
import { downloadFile } from './downloads.js';
import { validateAction, validatePageAction, isStartPage, webUrl } from './core.js';
export class StaleError extends Error {}
export class CoveredError extends Error {}
export class PreparedError extends Error {}
export function imagePoint(image, x, y) {
  if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || y < 0 || x >= image.width || y >= image.height) throw new Error('Coordinates outside screenshot.');
  return { x: x * image.cssWidth / image.width, y: y * image.cssHeight / image.height };
}
export class Driver {
  constructor(tabId, signal) {
    this.tabId = tabId; this.cancellation = new AbortController(); this.signal = AbortSignal.any([signal, this.cancellation.signal]); this.pending = new Map(); this.closed = false;
    this.port = chrome.runtime.connect({ name: 'advanced-run' });
    this.port.onMessage.addListener(message => {
      if (message.stopped) { this.failure = new Error(message.stopped); this.close(); return; }
      const pending = this.pending.get(message.id);
      if (pending) { this.pending.delete(message.id); message.error ? pending.reject(new Error(message.error)) : pending.resolve(message.result); }
    });
    this.port.onDisconnect.addListener(() => { this.failure ||= new Error('Automation connection closed.'); this.close(); });
    this.abort = () => this.close(); this.signal.addEventListener('abort', this.abort, { once: true });
  }
  assert() { this.signal.throwIfAborted(); if (this.closed) throw this.failure || new Error('Run stopped.'); }
  async request(type, extra = {}) {
    this.assert();
    const id = crypto.randomUUID();
    return new Promise((resolve, reject) => { this.pending.set(id, { resolve, reject }); this.port.postMessage({ id, type, ...extra }); });
  }
  async acquire() { this.attached = (await this.request('acquire', { tabId: this.tabId })).attached; }
  async ensureAttached() {
    if (!this.attached) { await this.tab(); await this.request('attach'); this.attached = true; }
  }
  close() {
    if (this.closed) return;
    this.closed = true; this.signal.removeEventListener('abort', this.abort); this.cancellation.abort();
    for (const p of this.pending.values()) p.reject(this.failure || new Error('Run stopped.'));
    this.pending.clear();
    if (this.lastNonce) void chrome.scripting.executeScript({ target: { tabId: this.tabId }, func: browserTool, args: [{ type: 'cleanup', nonce: this.lastNonce }] }).catch(() => {});
    try { this.port.postMessage({ type: 'stop' }); this.port.disconnect(); } catch { /* Already disconnected. */ }
  }
  async tab(allowStart = false) {
    this.assert(); const tab = await chrome.tabs.get(this.tabId); this.assert();
    if (!tab.active) throw new Error('Task tab is inactive.');
    if (allowStart && !this.attached && isStartPage(tab.url)) return tab;
    if (!/^https?:/.test(tab.url || '')) throw new Error('Task tab is inaccessible.');
    webUrl(tab.url);
    if (!await chrome.permissions.contains({ origins: [`${new URL(tab.url).origin}/*`] })) throw new Error('Site access is not granted.');
    return tab;
  }
  async dom(command) {
    await this.tab();
    await this.ensureAttached();
    const results = await chrome.scripting.executeScript({ target: { tabId: this.tabId }, func: browserTool, args: [command], injectImmediately: true });
    this.assert(); const result = results[0]?.result;
    if (!result || result.error) throw new Error(result?.error || 'Page script unavailable.');
    if (result.prepared) throw new PreparedError(result.reason);
    if (result.covered) throw new CoveredError(result.reason || 'Target covered; no input dispatched.');
    if (result.stale) throw new StaleError(result.reason || 'Page changed.');
    return result;
  }
  async snapshot() {
    const tab = await this.tab(true);
    if (isStartPage(tab.url)) return { noPage: true, url: 'New or blank tab (no page inspected)', text: 'No website is open. Navigate to the HTTP(S) website requested by the user, then continue the task.', elements: [], tabUrl: tab.url };
    const data = await this.dom({ type: 'snapshot' });
    this.lastNonce = data.nonce;
    if ((await this.tab()).url !== tab.url) throw new StaleError('Navigation during snapshot.');
    return { ...data, tabUrl: tab.url };
  }
  async fresh(data, action) {
    if ((await this.tab(data.noPage === true)).url !== data.tabUrl) throw new StaleError('Page navigated.');
    if (data.noPage) return { fresh: true, noPage: true };
    const semantic = !!action && !action.type.startsWith('point') && !['vision', 'done'].includes(action.type);
    return this.dom({ type: 'check', nonce: data.nonce, revision: data.revision, semantic, action });
  }
  async cdp(method, params = {}) { await this.tab(); await this.ensureAttached(); return this.request('cdp', { method, params }); }
  async capture(data) {
    if (data.noPage) throw new Error('Screenshots require an ordinary HTTP(S) website.');
    const check = await this.fresh(data);
    if (check.opaque) throw new Error('Screenshots blocked: visible opaque or transformed frame cannot be inspected safely.');
    if (check.viewport.scale !== 1) throw new Error('Reset pinch zoom before using vision.');
    const metrics = await this.cdp('Page.getLayoutMetrics');
    const v = metrics.cssVisualViewport;
    if (!v || Math.abs(v.clientWidth - data.viewport.width) > 2 || Math.abs(v.clientHeight - data.viewport.height) > 2) throw new StaleError('Viewport changed.');
    const scale = Math.min(1, 1024 / Math.max(v.clientWidth, v.clientHeight));
    const result = await this.cdp('Page.captureScreenshot', { format: 'jpeg', quality: 55, fromSurface: true, captureBeyondViewport: false, clip: { x: v.pageX, y: v.pageY, width: v.clientWidth, height: v.clientHeight, scale } });
    await this.fresh(data);
    if (!result.data || result.data.length > 1500000) throw new Error('Screenshot exceeded bounded image size.');
    const bytes = Uint8Array.from(atob(result.data), c => c.charCodeAt(0));
    const bitmap = await createImageBitmap(new Blob([bytes], { type: 'image/jpeg' }));
    const { width, height } = bitmap; bitmap.close();
    this.assert();
    return { data: result.data, width, height, cssWidth: v.clientWidth, cssHeight: v.clientHeight };
  }
  async pause(ms) {
    this.assert();
    await new Promise((resolve, reject) => {
      const abort = () => { clearTimeout(timer); reject(new Error('Run stopped.')); };
      const timer = setTimeout(() => { this.signal.removeEventListener('abort', abort); resolve(); }, ms);
      this.signal.addEventListener('abort', abort, { once: true });
    }); this.assert();
  }
  async ready() {
    if (isStartPage((await this.tab(true)).url)) return;
    const end = Date.now() + 15000; let previous = '', since = 0;
    while (Date.now() < end) {
      const tab = await this.tab();
      let ready = false;
      try { ready = (await this.dom({ type: 'probe' })).ready; } catch (error) { if (/Sensitive|CAPTCHA|bound/.test(error.message)) throw error; }
      if (!ready || previous !== tab.url) { previous = tab.url; since = ready ? Date.now() : 0; }
      else if (!since) since = Date.now();
      else if (Date.now() - since >= 400) return;
      await this.pause(150);
    }
    throw new Error('Page readiness timeout.');
  }
  async mouse(type, point, extra = {}) { return this.cdp('Input.dispatchMouseEvent', { type, ...point, ...extra }); }
  async click(point, data, action) {
    await this.mouse('mouseMoved', point);
    await this.fresh(data, action);
    if (action.type === 'click') {
      const checked = await this.dom({ type: 'act', nonce: data.nonce, revision: data.revision, action, checkOnly: true });
      if (!checked.point || checked.point.x !== point.x || checked.point.y !== point.y) throw new StaleError('Target changed after pointer movement; no click dispatched.');
    }
    await this.mouse('mousePressed', point, { button: 'left', clickCount: 1 });
    try { await this.mouse('mouseReleased', point, { button: 'left', clickCount: 1 }); }
    catch (error) { this.close(); throw error; }
  }
  async key(key, modifiers = 0) {
    const codes = { Enter: 13, Tab: 9, Escape: 27, ArrowUp: 38, ArrowDown: 40, ArrowLeft: 37, ArrowRight: 39, Space: 32, Backspace: 8, Delete: 46, Home: 36, End: 35, a: 65 };
    const params = { key: key === 'Space' ? ' ' : key, code: key === 'a' ? 'KeyA' : key, windowsVirtualKeyCode: codes[key], modifiers };
    await this.cdp('Input.dispatchKeyEvent', { type: 'keyDown', ...params, ...(['Enter', 'Space'].includes(key) && !modifiers ? { text: key === 'Enter' ? '\r' : ' ' } : {}) });
    await this.cdp('Input.dispatchKeyEvent', { type: 'keyUp', ...params });
  }
  async type(value) {
    await this.key('a', navigator.platform.includes('Mac') ? 4 : 2);
    await this.cdp('Input.insertText', { text: value });
  }
  async execute(action, data) {
    validatePageAction(validateAction(action, data.elements, data.image), data);
    if (!['wait', 'waitFor'].includes(action.type)) await this.fresh(data, action);
    if (action.type === 'wait') { await this.pause(action.milliseconds); return 'Wait completed.'; }
    if (action.type === 'waitFor') {
      const end = Date.now() + action.milliseconds;
      while (Date.now() < end) {
        if ((await this.dom({ type: 'waitProbe', text: action.text, state: action.state })).matched) return 'UI state observed.';
        await this.pause(150);
      }
      throw new StaleError('UI-state wait timed out; observe instead of repeating input.');
    }
    if (action.type === 'navigate') {
      webUrl(action.url);
      await chrome.tabs.update(this.tabId, { url: action.url });
      if (data.noPage) {
        const end = Date.now() + 15000;
        while (isStartPage((await this.tab(true)).url)) {
          if (Date.now() >= end) throw new Error('Website navigation did not commit within 15 seconds.');
          await this.pause(100);
        }
      }
      return 'Navigation requested.';
    }
    if (action.type === 'back' || action.type === 'forward') { await chrome.tabs[action.type === 'back' ? 'goBack' : 'goForward'](this.tabId); return 'History navigation requested.'; }
    let result, point, to;
    if (action.type.startsWith('point')) {
      const current = await this.capture(data);
      if (current.data !== data.image.data) throw new StaleError('Screenshot pixels changed; discarded coordinate decision.');
      point = imagePoint(data.image, action.x, action.y);
      if (action.type === 'pointDrag') to = imagePoint(data.image, action.toX, action.toY);
      result = await this.dom({ type: 'point', nonce: data.nonce, revision: data.revision, action, recovery: data.coveredRecovery === true, ...point, ...(to ? { toX: to.x, toY: to.y } : {}) });
    } else {
      result = await this.dom({ type: 'act', nonce: data.nonce, revision: data.revision, action });
      point = result.point; to = result.to;
    }
    if (result.navigateUrl) { webUrl(result.navigateUrl); await chrome.tabs.update(this.tabId, { url: result.navigateUrl }); return 'Link navigation requested in task tab.'; }
    if (result.downloadUrl) return JSON.stringify(await downloadFile(result.downloadUrl, this.signal));
    if (result.result) return result.result;
    if (['click', 'pointClick'].includes(action.type)) await this.click(point, data, action);
    else if (['hover', 'pointHover'].includes(action.type)) await this.mouse('mouseMoved', point);
    else if (['fill', 'pointType'].includes(action.type)) { await this.fresh(data, action); await this.type(action.value); }
    else if (action.type === 'key') { await this.fresh(data, action); await this.key(action.key); }
    else if (['drag', 'pointDrag'].includes(action.type)) {
      await this.mouse('mouseMoved', point);
      await this.fresh(data, action);
      await this.mouse('mousePressed', point, { button: 'left', clickCount: 1 });
      try {
        for (let i = 1; i <= 12; i++) await this.mouse('mouseMoved', { x: point.x + (to.x - point.x) * i / 12, y: point.y + (to.y - point.y) * i / 12 }, { button: 'left', buttons: 1 });
        await this.mouse('mouseReleased', to, { button: 'left', clickCount: 1 });
      } catch (error) { this.close(); throw error; }
    } else if (action.type === 'pointScroll') {
      const deltaY = ['up', 'top'].includes(action.direction) ? -1 : 1;
      await this.mouse('mouseWheel', point, { deltaX: 0, deltaY: deltaY * data.viewport.height * (['top', 'bottom'].includes(action.direction) ? 4 : 0.75) });
    } else throw new Error('Unsupported dispatch.');
    return `${action.type} dispatched; inspect next snapshot to verify.`;
  }
}
