// Serialized into the task tab's isolated world. No credentials or model code enter this function.
export function browserTool(command) {
  try {
    const key = '__advancedBrowserPilot';
    if (command.type === 'cleanup') {
      const state = globalThis[key];
      if (state?.nonce === command.nonce) {
        state.observers.forEach(o => o.disconnect());
        state.listeners.forEach(([target, fn]) => target.removeEventListener('scroll', fn, true));
        delete globalThis[key];
      }
      return { cleaned: true };
    }
    const secret = /password|passwd|secret|token|csrf|xsrf|api.?key|credit.?card|card.?number|passport|social.?security|one.?time|bank|medical|patient|(?:^|[^a-z0-9])(?:cvv|cvc|ssn|otp|iban)(?=$|[^a-z0-9])/i;
    const clean = value => String(value || '').replace(/\bBearer\s+\S+/gi, '[redacted]').replace(/\b[A-Za-z0-9_-]{32,}\b/g, '[redacted]').replace(/\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b/g, '[email]').replace(/\b(?:\d[ -]?){13,19}\b/g, '[number]');
    const safeUrl = raw => { try { const u = new URL(raw, location.href); return ['http:', 'https:'].includes(u.protocol) && !u.username && !u.password ? u.origin + u.pathname : ''; } catch { return ''; } };
    const visible = el => { const r = el.getBoundingClientRect(), s = el.ownerDocument.defaultView.getComputedStyle(el); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
    const sensitive = el => ['password', 'file', 'hidden'].includes(el.type) || secret.test([el.name, el.id, el.autocomplete, el.getAttribute('aria-label'), el.getAttribute('placeholder'), ...Array.from(el.labels || [], l => l.textContent)].join(' '));
    const label = el => clean(el.getAttribute('aria-label') || Array.from(el.labels || [], l => { const c = l.cloneNode(true); c.querySelectorAll('input,textarea,select,[contenteditable]').forEach(n => n.remove()); return c.textContent; }).join(' ') || (!el.isContentEditable && !el.matches('input,textarea,select') && el.innerText) || el.getAttribute('placeholder') || el.title || el.name || el.tagName.toLowerCase()).trim().slice(0, 160);
    const fingerprint = el => JSON.stringify([el.tagName, el.type, label(el), el.getAttribute('href'), el.form?.action, el.form?.method, el.disabled]);
    const roots = [], nodes = [], frames = [];
    let opaque = false, tooLarge = false;
    function walk(root, offset = { x: 0, y: 0 }, depth = 0) {
      if (depth > 8) { opaque = true; return; }
      roots.push(root);
      for (const el of root.querySelectorAll('*')) {
        if (nodes.length >= 12000) { tooLarge = true; return; }
        nodes.push({ el, offset });
        if (el.shadowRoot) walk(el.shadowRoot, offset, depth + 1);
        if (el.matches('iframe,frame') && visible(el)) {
          try {
            const doc = el.contentDocument;
            const r = el.getBoundingClientRect();
            const style = el.ownerDocument.defaultView.getComputedStyle(el);
            if (!doc?.documentElement || style.transform !== 'none' || Math.abs(r.width - el.offsetWidth) > 2) { opaque = true; continue; }
            frames.push(el);
            walk(doc, { x: offset.x + r.x + el.clientLeft, y: offset.y + r.y + el.clientTop }, depth + 1);
          } catch { opaque = true; }
        }
      }
    }
    walk(document);
    const blocked = roots.some(r => r.nodeType === 9 && /\/(login|signin|sign-in|checkout|payment|banking|medical|patient)(\/|$)/i.test(r.location.pathname)) || nodes.some(({ el }) => visible(el) && ((el.matches('input,textarea,[contenteditable]') && sensitive(el) && el.type !== 'file' && el.type !== 'hidden') || /captcha|recaptcha|hcaptcha/i.test([el.id, el.getAttribute('src'), el.getAttribute('aria-label')].join(' '))));
    if (blocked || tooLarge) throw new Error(blocked ? 'Sensitive page or CAPTCHA detected; automation blocked.' : 'Page exceeds safe inspection bound.');
    const viewport = () => ({ width: innerWidth, height: innerHeight, x: scrollX, y: scrollY, scale: visualViewport?.scale || 1 });
    const rect = entry => { const r = entry.el.getBoundingClientRect(); return { x: r.x + entry.offset.x, y: r.y + entry.offset.y, width: r.width, height: r.height }; };
    function hit(x, y, root = document, depth = 0) {
      if (depth > 8) return null;
      let el = root.elementFromPoint(x, y);
      while (el?.shadowRoot) { const next = el.shadowRoot.elementFromPoint(x, y); if (!next || next === el) break; el = next; }
      if (el?.matches('iframe,frame')) {
        const r = el.getBoundingClientRect();
        if (!el.contentDocument || !frames.includes(el)) throw new Error('Opaque frame input is blocked.');
        return hit(x - r.x - el.clientLeft, y - r.y - el.clientTop, el.contentDocument, depth + 1);
      }
      return el;
    }
    const safeTarget = el => {
      if (!el || !visible(el) || el.disabled || el.closest('[inert]') || sensitive(el)) throw new Error('Target unavailable or sensitive.');
      const form = el.form || el.closest('form');
      if (form) {
        for (const f of form.elements) {
          if (f.type === 'hidden' && /^(csrf|xsrf|sxsrf|csrfmiddlewaretoken|_csrf|_token|__requestverificationtoken|csrf_token|xsrf_token)$/i.test(f.name)) continue;
          if ((f.type === 'hidden' ? secret.test([f.name, f.id].join(' ')) : sensitive(f)) && !(f.type === 'file' && !f.files?.length)) throw new Error('Form contains sensitive fields.');
        }
        const u = new URL(el.getAttribute('formaction') || form.action, el.ownerDocument.location.href);
        if (u.origin !== el.ownerDocument.location.origin || !['http:', 'https:'].includes(u.protocol)) throw new Error('Cross-origin form submissions are blocked.');
        if (!['', '_self'].includes(el.getAttribute('formtarget') || form.target || '')) throw new Error('Forms opening other targets are blocked.');
      }
      return el;
    };
    if (command.type === 'probe') return { ready: document.readyState !== 'loading', opaque, viewport: viewport() };
    if (command.type === 'snapshot') {
      globalThis[key]?.observers?.forEach(o => o.disconnect());
      globalThis[key]?.listeners?.forEach(([target, fn]) => target.removeEventListener('scroll', fn, true));
      const state = { nonce: crypto.randomUUID(), url: location.href, revision: 0, refs: new Map(), observers: [], listeners: [], viewport: viewport(), covered: globalThis[key]?.covered };
      const bump = () => { state.revision++; };
      for (const root of roots) {
        const observer = new MutationObserver(bump);
        observer.observe(root, { subtree: true, childList: true, attributes: true, characterData: true });
        state.observers.push(observer);
        root.addEventListener('scroll', bump, true);
        state.listeners.push([root, bump]);
      }
      const elements = [];
      for (const entry of nodes) {
        const { el } = entry;
        const scrollable = el.scrollHeight > el.clientHeight + 4 && /(auto|scroll)/.test(el.ownerDocument.defaultView.getComputedStyle(el).overflowY);
        if ((!el.matches('a[href],button,input,textarea,select,[role="button"],[role="tab"],[contenteditable="true"],[draggable="true"]') && !scrollable) || !visible(el) || sensitive(el) || el.disabled || elements.length >= 160) continue;
        const id = `e${elements.length + 1}`;
        state.refs.set(id, { ...entry, fingerprint: fingerprint(el), rect: rect(entry) });
        elements.push({ id, tag: el.tagName.toLowerCase(), label: label(el), type: el.type || '', scrollable, rect: rect(entry), ...(el.matches('a[href]') ? { href: safeUrl(el.href), download: el.hasAttribute('download') } : {}), ...(el.matches('select') ? { options: Array.from(el.options).slice(0, 40).map(o => ({ value: clean(o.value), label: clean(o.text) })) } : {}) });
      }
      const chunks = [];
      let size = 0;
      for (const root of roots) {
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
        let n;
        while ((n = walker.nextNode()) && size < 7000) {
          const p = n.parentElement;
          if (!p || p.closest('script,style,noscript,input,textarea,select,[contenteditable],[hidden],[aria-hidden="true"]') || !visible(p)) continue;
          const text = clean(n.textContent.trim());
          if (text) { chunks.push(text); size += text.length; }
        }
      }
      globalThis[key] = state;
      return { nonce: state.nonce, revision: 0, url: safeUrl(location.href), title: clean(document.title), text: chunks.join(' ').slice(0, 7000), elements, opaqueFrames: opaque, viewport: viewport() };
    }
    if (command.type === 'waitProbe') {
      const text = nodes.filter(({ el }) => visible(el) && !el.matches('input,textarea,select,[contenteditable]')).some(({ el }) => Array.from(el.childNodes).some(n => n.nodeType === 3 && n.textContent.includes(command.text)));
      return { matched: command.state === 'visible' ? text : !text };
    }
    const state = globalThis[key];
    if (!state || state.nonce !== command.nonce || state.url !== location.href) return { stale: true, reason: 'Page changed: document identity.' };
    const semantic = command.type === 'act' || command.semantic === true;
    if (!semantic && state.revision !== command.revision) return { stale: true, reason: 'Page changed: DOM mutation or nested scroll.' };
    if (!semantic && JSON.stringify(viewport()) !== JSON.stringify(state.viewport)) return { stale: true, reason: 'Page changed: viewport.' };
    const relevant = semantic ? [command.action?.element, command.action?.target].filter(Boolean).map(id => state.refs.get(id)) : state.refs.values();
    for (const ref of relevant) {
      if (!ref || !ref.el.isConnected || fingerprint(ref.el) !== ref.fingerprint || !visible(ref.el) || JSON.stringify(rect(ref)) !== JSON.stringify(ref.rect)) return { stale: true, reason: 'Page changed: referenced element geometry or identity.' };
    }
    if (command.type === 'check') return { fresh: true, opaque, viewport: viewport() };
    const action = command.action;
    const inModal = el => el?.closest('dialog, [role="dialog"], [aria-modal="true"]');
    function equivalentLink(el, target) {
      const link = el?.matches('a[href]') ? el : null;
      const overlay = target?.closest('a[href]');
      const parent = link?.parentElement;
      return !!(link && overlay && parent && !['BODY', 'HTML'].includes(parent.tagName)
        && (overlay.parentElement === parent || overlay.parentElement?.parentElement === parent)
        && link.ownerDocument === overlay.ownerDocument && link.href === overlay.href && safeUrl(link.href)
        && !link.hasAttribute('download') && !overlay.hasAttribute('download')
        && ['', '_self', '_blank'].includes(link.target) && ['', '_self', '_blank'].includes(overlay.target)
        && !inModal(link) && !inModal(overlay)
        && !link.ownerDocument.querySelector('dialog[open], [aria-modal="true"]'));
    }
    if (command.type === 'point') {
      if (opaque) throw new Error('Vision and coordinate input require inspectable frames.');
      const el = safeTarget(hit(command.x, command.y));
      if (command.recovery) {
        const covered = state.covered;
        if (!covered || covered.url !== location.href || !covered.el.isConnected || fingerprint(covered.el) !== covered.fingerprint) throw new Error('Covered target changed; visual recovery stopped without input.');
        if (action.type !== 'pointClick' || covered.type !== 'click' || !(el === covered.el || covered.el.contains(el) || equivalentLink(covered.el, el))) throw new Error('Visual recovery must hit the original target or its exact-destination card link; overlay input blocked.');
      }
      if (command.toX !== undefined) safeTarget(hit(command.toX, command.toY));
      if (action.type === 'pointType' && !(el.matches('textarea,input') && !['checkbox', 'radio', 'submit', 'button'].includes(el.type) || el.isContentEditable)) throw new Error('Point typing requires an editable field.');
      const link = el.closest('a[href]');
      if (link && action.type === 'pointClick') return linkResult(link);
      if (action.type === 'pointType') { el.focus({ preventScroll: true }); return { point: { x: command.x, y: command.y }, editable: true }; }
      return { point: { x: command.x, y: command.y } };
    }
    function linkResult(link) {
      if (!safeUrl(link.href)) throw new Error('Unsupported link URL.');
      if (!['', '_self', '_blank'].includes(link.target)) throw new Error('Named target frames unsupported.');
      return link.hasAttribute('download') || action.type === 'download' ? { downloadUrl: link.href } : { navigateUrl: link.href };
    }
    if (action.type === 'scroll') {
      const y = action.direction === 'top' ? -scrollY : action.direction === 'bottom' ? document.documentElement.scrollHeight : innerHeight * 0.8 * (action.direction === 'up' ? -1 : 1);
      scrollBy({ top: y, behavior: 'instant' }); return { result: 'Page scrolled.' };
    }
    const ref = state.refs.get(action.element);
    const el = safeTarget(ref?.el);
    const r = rect(ref), x = r.x + r.width / 2, y = r.y + r.height / 2;
    if (x < 0 || y < 0 || x >= innerWidth || y >= innerHeight) {
      el.scrollIntoView({ block: 'center', inline: 'center', behavior: 'instant' });
      return { prepared: true, reason: 'Scrolled target into view; re-observe before input.' };
    }
    const target = hit(x, y);
    if (target !== el && !el.contains(target)) {
      if (action.type === 'click' && equivalentLink(el, target)) { safeTarget(target.closest('a[href]')); return linkResult(el); }
      state.covered = { el, fingerprint: fingerprint(el), url: location.href, type: action.type };
      return { covered: true, reason: 'Target is covered; inspect the overlay. No input dispatched.' };
    }
    if (['click', 'download'].includes(action.type) && el.closest('a[href]')) return linkResult(el.closest('a[href]'));
    if (action.type === 'download') throw new Error('Download requires a direct HTTP(S) link.');
    if (action.type === 'select') {
      if (!el.matches('select') || !Array.from(el.options).some(o => o.value === action.value)) throw new Error('Invalid option.');
      el.value = action.value; el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); return { result: 'Option selected.' };
    }
    if (action.type === 'submit') {
      if (!el.form) throw new Error('Target has no form.');
      el.form.requestSubmit(['submit', 'image'].includes(el.type) ? el : undefined); return { result: 'Submission requested; verify confirmation.' };
    }
    if (action.type === 'scrollElement') {
      el.scrollBy({ top: action.direction === 'top' ? -el.scrollTop : action.direction === 'bottom' ? el.scrollHeight : el.clientHeight * 0.8 * (action.direction === 'up' ? -1 : 1), behavior: 'instant' }); return { result: 'Nested region scrolled.' };
    }
    if (['fill', 'key'].includes(action.type)) {
      if (action.type === 'fill' && (!(el.matches('input,textarea') || el.isContentEditable) || el.readOnly || ['checkbox', 'radio', 'submit', 'button'].includes(el.type))) throw new Error('Target is not editable.');
      el.focus({ preventScroll: true });
    }
    let to;
    if (action.type === 'drag') {
      const end = state.refs.get(action.target); safeTarget(end?.el);
      const b = rect(end); to = { x: b.x + b.width / 2, y: b.y + b.height / 2 };
      const h = hit(to.x, to.y);
      if (to.x < 0 || to.y < 0 || to.x >= innerWidth || to.y >= innerHeight || (h !== end.el && !end.el.contains(h))) return { stale: true, reason: 'Drag destination is not reachable.' };
    }
    return { point: { x, y }, to };
  } catch (error) { return { error: error.message || 'Page inspection failed.' }; }
}
