import { isStartPage } from './core.js';
let owner;
async function attach(session) {
  const tab = await chrome.tabs.get(session.tabId);
  if (!tab.active || tab.windowId !== session.windowId || !/^https?:/.test(tab.url || '')) throw new Error('Debugger attachment requires the active HTTP(S) task tab.');
  const targets = await chrome.debugger.getTargets();
  if (session.stopped) throw new Error('Run stopped before attachment.');
  if (targets.some(t => t.tabId === tab.id && t.attached)) throw new Error('Another debugger already owns this tab. Close it yourself before retrying.');
  session.attaching = chrome.debugger.attach({ tabId: tab.id }, '1.3');
  await session.attaching;
  session.attached = true;
  if (session.stopped) { await release(session); throw new Error('Run stopped during attachment.'); }
}
const methods = new Set(['Page.captureScreenshot', 'Page.getLayoutMetrics', 'Input.dispatchMouseEvent', 'Input.dispatchKeyEvent', 'Input.insertText']);
async function initialize() {
  await chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
}
initialize().catch(console.error);
chrome.runtime.onInstalled.addListener(() => initialize().catch(console.error));
chrome.runtime.onStartup.addListener(() => initialize().catch(console.error));
async function release(session) {
  session.stopped = true;
  if (session.attaching) await session.attaching.catch(() => {});
  if (session.attached) {
    session.attached = false;
    try { await chrome.debugger.detach({ tabId: session.tabId }); } catch { /* Tab closed or debugger detached externally. */ }
  }
  if (owner === session) { owner = undefined; await chrome.alarms.clear('run-deadline'); }
}
chrome.alarms.onAlarm.addListener(alarm => { if (alarm.name === 'run-deadline' && owner) { owner.port.postMessage({ stopped: 'Five-minute deadline reached.' }); void release(owner); } });
chrome.debugger.onDetach.addListener((source, reason) => {
  if (owner && source.tabId === owner.tabId) {
    const session = owner; session.attached = false;
    try { session.port.postMessage({ stopped: `Debugger detached: ${reason}` }); } catch { /* Panel closed. */ }
    void release(session);
  }
});
chrome.tabs.onActivated.addListener(info => { if (owner && info.windowId === owner.windowId && info.tabId !== owner.tabId) { try { owner.port.postMessage({ stopped: 'Task tab is no longer active.' }); } catch {} void release(owner); } });
chrome.tabs.onRemoved.addListener(id => { if (owner?.tabId === id) void release(owner); });
chrome.runtime.onConnect.addListener(port => {
  if (port.name !== 'advanced-run' || port.sender?.id !== chrome.runtime.id) return;
  let session;
  let disconnected = false;
  let queue = Promise.resolve();
  const reply = message => { try { port.postMessage(message); } catch { /* Panel gone. */ } };
  port.onDisconnect.addListener(() => { disconnected = true; if (session) void release(session); });
  port.onMessage.addListener(message => {
    if (message.type === 'stop') { if (session) void release(session); return; }
    queue = queue.then(async () => {
      try {
        if (message.type === 'acquire') {
          if (owner || session) throw new Error('Another run owns automation.');
          const tab = await chrome.tabs.get(message.tabId);
          if (disconnected) throw new Error('Panel closed before attachment.');
          if (!tab.active || (!/^https?:/.test(tab.url || '') && !isStartPage(tab.url))) throw new Error('Select an active website or new/blank task tab.');
          session = { port, tabId: tab.id, windowId: tab.windowId, stopped: false, attached: false };
          owner = session;
          if (disconnected || session.stopped) throw new Error('Run stopped before attachment.');
          if (!isStartPage(tab.url)) await attach(session);
          await chrome.alarms.create('run-deadline', { when: Date.now() + 300000 });
          reply({ id: message.id, result: { acquired: true, attached: session.attached } });
          return;
        }
        if (!session || owner !== session || session.stopped) throw new Error('No run ownership.');
        if (message.type === 'attach') {
          if (!session.attached) await attach(session);
          reply({ id: message.id, result: { attached: true } });
          return;
        }
        if (!session.attached) throw new Error('No debugger ownership.');
        const tab = await chrome.tabs.get(session.tabId);
        if (!tab.active || tab.windowId !== session.windowId || !/^https?:/.test(tab.url || '')) throw new Error('Task tab is inactive or inaccessible.');
        if (message.type !== 'cdp' || !methods.has(message.method)) throw new Error('CDP command not allowlisted.');
        const result = await chrome.debugger.sendCommand({ tabId: session.tabId }, message.method, message.params || {});
        if (session.stopped) throw new Error('Run stopped.');
        reply({ id: message.id, result });
      } catch (error) {
        reply({ id: message.id, error: error.message });
        if (session) await release(session);
      }
    });
  });
});
