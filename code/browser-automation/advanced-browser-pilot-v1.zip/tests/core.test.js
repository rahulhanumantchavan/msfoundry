import test from 'node:test';
import assert from 'node:assert/strict';
import { configFrom, validateAction, validatePageAction, isStartPage, nextAction, MAX_ACTIONS, RUN_TIMEOUT } from '../src/core.js';
import { imagePoint } from '../src/driver.js';
const elements = [{ id: 'e1' }, { id: 'e2' }];
const image = { width: 512, height: 384, cssWidth: 1280, cssHeight: 960, data: 'ZmFrZQ==' };
test('new-tab startup is narrowly allowed and no-page actions are navigation-only', () => {
  for (const url of ['chrome://newtab/', 'chrome://newtab', 'edge://newtab/', 'about:blank']) assert.equal(isStartPage(url), true);
  for (const url of ['chrome://settings/', 'edge://history/', 'chrome-extension://id/page', 'file:///secret', 'chrome://newtab/other', 'https://example.com', '']) assert.equal(isStartPage(url), false);
  for (const type of ['vision', 'wait', 'waitFor', 'back', 'forward', 'click', 'pointClick', 'download']) assert.throws(() => validatePageAction({ type }, { noPage: true }), /Only navigate/);
  assert.equal(validatePageAction({ type: 'navigate' }, { noPage: true }).type, 'navigate');
  assert.equal(validatePageAction({ type: 'done' }, { noPage: true }).type, 'done');
  assert.throws(() => validateAction({ type: 'navigate', url: 'chrome://settings' }), /HTTP/);
});
test('independent Azure configuration validates resource roots and rejects credential destinations', () => {
  assert.equal(configFrom({ endpoint: 'https://test.openai.azure.com/openai/v1/', deployment: 'vision', key: 'fake' }).endpoint, 'https://test.openai.azure.com');
  for (const endpoint of ['http://test.openai.azure.com', 'https://example.com', 'https://test.openai.azure.com.evil.com', 'https://test.openai.azure.com/path', 'https://user:pass@test.openai.azure.com']) assert.throws(() => configFrom({ endpoint, deployment: 'vision', key: 'fake' }));
});
test('action allowlist, strict fields, coordinates and keyboard reject executable or stale commands', () => {
  for (const a of [{ type: 'evaluate', code: 'alert(1)' }, { type: 'click', element: 'e1', script: 'bad' }, { type: 'click', element: 'missing' }, { type: 'key', element: 'e1', key: 'F12' }, { type: 'pointClick', x: NaN, y: 1 }, { type: 'pointClick', x: 512, y: 1 }, { type: 'pointDrag', x: 2, y: 3, toX: -1, toY: 5 }, { type: 'waitFor', text: '', state: 'visible', milliseconds: 1000 }]) assert.throws(() => validateAction(a, elements, image));
  assert.throws(() => validateAction({ type: 'pointClick', x: 2, y: 3 }, elements));
  assert.equal(validateAction({ type: 'drag', element: 'e1', target: 'e2' }, elements).type, 'drag');
  assert.deepEqual(imagePoint(image, 128, 96), { x: 320, y: 240 });
  assert.equal(MAX_ACTIONS, 30); assert.equal(RUN_TIMEOUT, 300000);
});
test('vision request uses in-memory image_url, low detail and exact API usage', async () => {
  let body, totals = 0;
  const fetcher = async (url, options) => {
    assert.equal(url, 'https://test.openai.azure.com/openai/v1/chat/completions');
    assert.equal(options.redirect, 'error'); assert.equal(options.headers['api-key'], 'fake'); body = JSON.parse(options.body);
    return { ok: true, json: async () => ({ choices: [{ message: { content: '{"type":"pointClick","x":100,"y":100}' } }], usage: { prompt_tokens: 99, completion_tokens: 8, total_tokens: 107 } }) };
  };
  await nextAction({ endpoint: 'https://test.openai.azure.com', deployment: 'vision', key: 'fake' }, 'click fixture', { elements, image }, [], undefined, fetcher, event => { if (event.usage) totals += event.usage.total_tokens; });
  const content = body.messages[2].content;
  assert.equal(content[1].image_url.detail, 'low'); assert.equal(content[1].image_url.url, 'data:image/jpeg;base64,ZmFrZQ==');
  assert.ok(!content[0].text.includes(image.data)); assert.ok(!content[0].text.includes('fake'));
  assert.equal(totals, 107); assert.equal(body.max_completion_tokens, 1800);
});
