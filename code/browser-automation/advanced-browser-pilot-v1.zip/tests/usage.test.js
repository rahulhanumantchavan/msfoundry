import test from 'node:test';
import assert from 'node:assert/strict';
import { createUsageTracker, nextAction, summarizeResults } from '../src/core.js';

const config = { endpoint: 'https://test.openai.azure.com', deployment: 'test', key: 'fake' };
const snapshot = { elements: [] };
const response = (content, usage) => async () => ({ ok: true, json: async () => ({ choices: [{ message: { content } }], usage }) });

test('accumulates API usage from actions and summaries; fresh tracker resets counts', async () => {
  let totals;
  const tracker = createUsageTracker(value => { totals = value; });
  await nextAction(config, '', snapshot, [], undefined, response('{"type":"done","message":"ok"}', { prompt_tokens: 100, completion_tokens: 20, total_tokens: 120 }), tracker.record);
  await summarizeResults(config, '', snapshot, [], '', undefined, response('{"summary":"ok"}', { prompt_tokens: 200, completion_tokens: 30, total_tokens: 230 }), tracker.record);
  assert.deepEqual(totals, { input: 300, output: 50, total: 350, requests: 2, pending: 0, missing: 0 });
  const fresh = createUsageTracker(value => { totals = value; });
  fresh.record({ type: 'start' });
  assert.deepEqual(totals, { input: 0, output: 0, total: 0, requests: 1, pending: 1, missing: 0 });
});

test('invalid model output still counts reported tokens exactly once', async () => {
  let totals;
  const tracker = createUsageTracker(value => { totals = value; });
  await assert.rejects(nextAction(config, '', snapshot, [], undefined, response('bad JSON', { prompt_tokens: 10, completion_tokens: 2, total_tokens: 12 }), tracker.record));
  assert.equal(totals.total, 12);
  assert.equal(totals.missing, 0);
  assert.equal(totals.pending, 0);
});

test('missing, malformed, failed and aborted requests mark totals incomplete', async () => {
  let totals;
  const tracker = createUsageTracker(value => { totals = value; });
  for (const usage of [undefined, { prompt_tokens: -1, completion_tokens: 1, total_tokens: 0 }, { prompt_tokens: 10 }]) {
    await nextAction(config, '', snapshot, [], undefined, response('{"type":"done","message":"ok"}', usage), tracker.record);
  }
  await assert.rejects(nextAction(config, '', snapshot, [], undefined, async () => ({ ok: false, status: 429 }), tracker.record));
  await assert.rejects(nextAction(config, '', snapshot, [], AbortSignal.abort(), async () => { throw new DOMException('Aborted', 'AbortError'); }, tracker.record));
  assert.deepEqual(totals, { input: 0, output: 0, total: 0, requests: 5, pending: 0, missing: 5 });
});
