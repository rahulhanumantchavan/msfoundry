import test from 'node:test';
import assert from 'node:assert/strict';
import { Driver, StaleError, CoveredError } from '../src/driver.js';
import { TargetResolutionError, NoProgressError, validateAction } from '../src/core.js';
import { runTask } from '../src/runner.js';

const config = { endpoint: 'https://fixture.openai.azure.com', deployment: 'fixture', key: 'fixture-only' };
const click = { type: 'click', element: 'e1' };
const done = { type: 'done', message: 'Observed fixture.' };
function harness(t, decisions, { execute, fresh, capture, snapshot } = {}) {
  const state = { calls: [], inputs: [], images: [], snapshots: [], progress: 0, closed: false, usage: null };
  t.mock.method(globalThis, 'fetch', async (_url, options) => {
    const body = JSON.parse(options.body);
    const content = body.messages[2].content;
    const evidence = JSON.parse(content[0].text.split('\n').slice(1).join('\n'));
    state.calls.push({ image: content.length > 1, evidence });
    const decision = decisions[state.calls.length - 1];
    if (!decision) throw new Error('Unexpected model request');
    if (decision instanceof Error) throw decision;
    return { ok: true, json: async () => ({ choices: [{ message: { content: JSON.stringify(decision) } }], usage: { prompt_tokens: 10, completion_tokens: 2, total_tokens: 12 } }) };
  });
  const oldChrome = globalThis.chrome;
  globalThis.chrome = { runtime: { connect: () => ({ onMessage: { addListener() {} }, onDisconnect: { addListener() {} } }) } };
  t.after(() => { globalThis.chrome = oldChrome; });
  for (const method of ['acquire', 'ready', 'assert']) t.mock.method(Driver.prototype, method, () => {});
  t.mock.method(Driver.prototype, 'close', () => { state.closed = true; });
  t.mock.method(Driver.prototype, 'snapshot', async () => {
    const data = { nonce: `n${state.snapshots.length}`, revision: 0, tabUrl: 'https://fixture.test/', url: 'https://fixture.test/', text: 'Fixture', elements: [{ id: 'e1', label: 'Button', tag: 'button' }], progress: state.progress, viewport: { width: 100, height: 100 } };
    snapshot?.(state, data); state.snapshots.push(data); return data;
  });
  t.mock.method(Driver.prototype, 'fresh', async (data, action) => fresh?.(state, data, action));
  t.mock.method(Driver.prototype, 'capture', async data => {
    if (capture) return capture(state, data);
    const image = { data: 'ZmFrZQ==', width: 100, height: 100, cssWidth: 100, cssHeight: 100 };
    state.images.push(image); return image;
  });
  t.mock.method(Driver.prototype, 'execute', async (action, data) => {
    state.inputs.push(action); return execute ? execute(state, action, data) : 'Dispatched; inspect evidence.';
  });
  state.run = () => runTask({ tabId: 1, task: 'Inspect fixture', config, consent: true, signal: new AbortController().signal, onUsage: usage => { state.usage = usage; } });
  return state;
}

test('unknown references are typed only after all safety/schema validation', () => {
  assert.throws(() => validateAction({ type: 'click', element: 'missing' }), TargetResolutionError);
  assert.throws(() => validateAction({ type: 'drag', element: 'e1', target: 'missing' }, [{ id: 'e1' }]), TargetResolutionError);
  assert.throws(() => validateAction({ type: 'key', element: 'missing', key: 'F12' }), e => !(e instanceof TargetResolutionError));
});
for (const failure of ['stale', 'unknown', 'covered', 'waitFor']) {
  test(`${failure}: first two failures remain DOM, third triggers fresh image and accounts every response`, async t => {
    const action = failure === 'unknown' ? { ...click, element: 'missing' } : failure === 'waitFor' ? { type: 'waitFor', text: 'Saved', state: 'visible', milliseconds: 100 } : click;
    const errors = { stale: StaleError, covered: CoveredError, waitFor: NoProgressError };
    const state = harness(t, [action, action, action, done], { execute() { throw new errors[failure]('Fixture target unavailable'); } });
    const result = await state.run();
    assert.deepEqual(state.calls.map(c => c.image), [false, false, false, true]);
    assert.equal(result.recoveries, 3); assert.equal(result.visionFallbacks, 1);
    assert.equal(state.usage.total, 48); assert.equal(state.usage.requests, 4); assert.equal(state.usage.pending, 0);
    assert.equal(state.images[0].data, ''); assert.ok(state.snapshots.every(s => !s.image)); assert.ok(state.closed);
    if (failure === 'covered') assert.equal(state.calls[3].evidence.snapshot.coveredRecovery, true);
    assert.ok(!JSON.stringify(result.history).includes('ZmFrZQ=='));
  });
}
for (const count of [1, 2]) {
  test(`${count} target failures followed by done need no image`, async t => {
    const state = harness(t, [...Array(count).fill({ ...click, element: 'missing' }), done]);
    const result = await state.run();
    assert.equal(result.recoveries, count); assert.equal(result.visionFallbacks, 0);
    assert.ok(state.calls.every(c => !c.image));
  });
}
test('stale capture attempts exhaust the shared image budget without an extra model call', async t => {
  const state = harness(t, [{ type: 'vision', reason: 'Inspect' }], {
    capture() { throw new StaleError('Viewport changed during capture'); }
  });
  await assert.rejects(state.run(), /vision fallback limit/);
  assert.equal(state.calls.length, 1); assert.equal(state.snapshots.length, 3); assert.ok(state.closed);
});
test('three ordinary waits with unchanged evidence escalate before next decision', async t => {
  const wait = { type: 'wait', milliseconds: 100 };
  const state = harness(t, [wait, wait, wait, done]);
  const result = await state.run();
  assert.deepEqual(state.calls.map(c => c.image), [false, false, false, true]);
  assert.equal(result.actions, 1); assert.equal(result.recoveries, 3);
});
for (const type of ['click', 'submit', 'fill']) {
  test(`unchanged ${type} is dispatched once, not replayed on repeated exact decisions`, async t => {
    const action = { type, element: 'e1', ...(type === 'fill' ? { value: 'ordinary fixture' } : {}) };
    const state = harness(t, [action, action, action, done]);
    const result = await state.run();
    assert.equal(state.inputs.length, 1); assert.equal(result.recoveries, 3);
    assert.deepEqual(state.calls.map(c => c.image), [false, false, false, true]);
  });
}
test('observable progress resets attempts, permits later click and ignores nonce churn', async t => {
  let failures = 0;
  const state = harness(t, [click, click, click, click, click, done], {
    execute(state) { if (++failures !== 3) throw new StaleError('Changed target'); state.progress++; return 'Click dispatched'; }
  });
  const result = await state.run();
  assert.equal(result.recoveries, 4); assert.equal(result.visionFallbacks, 0);
  assert.ok(state.calls.every(c => !c.image));
});
test('image failures consume at most two fresh images and clean both on failure', async t => {
  const unknown = { ...click, element: 'missing' };
  const state = harness(t, Array(5).fill(unknown));
  await assert.rejects(state.run(), /vision fallback limit/);
  assert.deepEqual(state.calls.map(c => c.image), [false, false, false, true, true]);
  assert.equal(state.images.length, 2); assert.ok(state.images.every(i => i.data === ''));
  assert.equal(state.usage.total, 60); assert.equal(state.usage.pending, 0); assert.ok(state.closed);
});
test('explicit vision requests share the same two-image budget', async t => {
  const state = harness(t, Array(3).fill({ type: 'vision', reason: 'Inspect' }));
  await assert.rejects(state.run(), /vision fallback limit/);
  assert.deepEqual(state.calls.map(c => c.image), [false, true, true]);
});
test('stale coordinate decisions request new images and never execute old coordinates', async t => {
  const state = harness(t, [{ type: 'vision', reason: 'Canvas' }, { type: 'pointClick', x: 10, y: 10 }, done], {
    fresh(_state, _data, action) { if (action.type === 'pointClick') throw new StaleError('Pixels changed'); }
  });
  await state.run();
  assert.equal(state.inputs.length, 0); assert.equal(state.images.length, 2);
  assert.deepEqual(state.calls.map(c => c.image), [false, true, true]);
});
test('coordinates cannot replay an unconfirmed DOM click', async t => {
  const state = harness(t, [click, click, click, { type: 'pointClick', x: 10, y: 10 }, done]);
  await state.run(); assert.equal(state.inputs.length, 1);
});
for (const message of ['Site access is not granted.', 'Sensitive page or CAPTCHA detected', 'overlay input blocked', 'HTTP 429', 'Invalid action schema']) {
  test(`nonrecoverable ${message} stops without screenshot`, async t => {
    const state = harness(t, [click], { execute() { throw new Error(message); } });
    await assert.rejects(state.run(), e => e.message === message);
    assert.equal(state.calls.length, 1); assert.equal(state.images.length, 0); assert.ok(state.closed);
  });
}
test('post-input verification failure is terminal, not a recoverable stale decision', async () => {
  const driver = Object.create(Driver.prototype);
  let typed = 0;
  driver.fresh = async () => {};
  driver.type = async () => { typed++; };
  driver.dom = async command => {
    if (command.type === 'edited') throw new StaleError('Navigated after typing');
    return { point: { x: 1, y: 1 } };
  };
  await assert.rejects(driver.execute({ type: 'fill', element: 'e1', value: 'Fixture' }, { elements: [{ id: 'e1' }] }), error => !(error instanceof StaleError) && /input was dispatched/.test(error.message));
  assert.equal(typed, 1);
});
test('coordinate verification clears its comparison image and rejects pixel changes before input', async () => {
  const driver = Object.create(Driver.prototype);
  driver.fresh = async () => {};
  const comparison = { data: 'changed' };
  driver.capture = async () => comparison;
  driver.dom = async () => { throw new Error('Unexpected input'); };
  await assert.rejects(driver.execute({ type: 'pointClick', x: 1, y: 1 }, { elements: [], image: { width: 10, height: 10, data: 'original' } }), StaleError);
  assert.equal(comparison.data, '');
});
test('HTTP/model transport failure on image decision cleans image and marks usage incomplete', async t => {
  const state = harness(t, [{ type: 'vision', reason: 'Inspect' }, new Error('HTTP 429')]);
  await assert.rejects(state.run(), /HTTP 429/);
  assert.equal(state.images[0].data, ''); assert.equal(state.usage.total, 12);
  assert.equal(state.usage.pending, 0); assert.equal(state.usage.missing, 1);
});
