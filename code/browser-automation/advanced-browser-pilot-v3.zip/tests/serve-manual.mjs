import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';

const page = await readFile(new URL('./manual-vision.html', import.meta.url));
const server = createServer((request, response) => {
  if (request.url !== '/' && request.url !== '/manual-vision.html') {
    response.writeHead(404).end('Not found');
    return;
  }
  response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  response.end(page);
});
server.on('error', error => { console.error(error.message); process.exitCode = 1; });
server.listen(0, '127.0.0.1', () => {
  console.log(`Open http://127.0.0.1:${server.address().port}/manual-vision.html`);
  console.log('Press Ctrl+C to stop. Only the manual fixture page is served.');
});
