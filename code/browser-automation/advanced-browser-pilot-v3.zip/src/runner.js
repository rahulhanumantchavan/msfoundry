import { Driver, StaleError, CoveredError, PreparedError, AutocompleteError } from './driver.js';
import { MAX_ACTIONS, RUN_TIMEOUT, DOMAttemptError, NoProgressError, configFrom, nextAction, summarizeResults, wantsSummary, createUsageTracker, actionDescription, actionProgress } from './core.js';

const sideEffects = new Set(['click', 'submit', 'download', 'key', 'drag', 'pointClick', 'pointDrag', 'pointType']);
const evidenceKey = data => JSON.stringify([data.tabUrl, data.progress, data.title, data.text, data.elements, data.viewport]);
const actionKey = (action, data) => JSON.stringify({ ...action, ...Object.fromEntries(['element', 'target'].filter(key => key in action).map(key => {
  const { id, rect, ...identity } = data.elements.find(e => e.id === action[key]) || {};
  return [key, identity];
})) });
export async function runTask({ tabId, task, config, consent, signal, onProgress = () => {}, onUsage = () => {}, onResult = () => {} }) {
  if (consent !== true) throw new Error('Explicit run consent is required before inspection or screenshots.');
  config = configFrom(config);
  if (!task?.trim() || task.length > 4000) throw new Error('Enter a task of at most 4000 characters.');
  const combined = AbortSignal.any([signal, AbortSignal.timeout(RUN_TIMEOUT)]);
  const driver = new Driver(tabId, combined);
  const usage = createUsageTracker(onUsage);
  const history = [];
  let actions = 0, preparations = 0, recoveries = 0, consecutiveRecoveries = 0, visionFallbacks = 0, vision = false, coveredRecovery = false;
  let pendingObservation, imageAttempt = false;
  const dispatched = new Set();
  const remember = entry => { history.push(entry); if (history.length > 60) history.shift(); };
  const failedAttempt = error => {
    recoveries++;
    consecutiveRecoveries++;
    remember({ action: 'recovery', result: `${error.message} Inspect fresh evidence; do not replay dispatched input.` });
    onProgress(`DOM attempt unsuccessful (${consecutiveRecoveries}/3). Re-observing before deciding.`);
    if (consecutiveRecoveries >= 3 || imageAttempt) {
      if (visionFallbacks >= 2) throw new Error('Screenshot vision fallback limit reached; stopped without replaying input.');
      vision = true;
      consecutiveRecoveries = 0;
    }
  };
  const recover = async error => {
    if (error instanceof AutocompleteError) {
      actions++;
      onProgress(error.message);
      history.push({ action: 'dismiss autocomplete', result: 'Escape sent only to the field filled by this run. Intended click was NOT dispatched. Inspect fresh references before deciding the next action.' });
      vision = false; coveredRecovery = false;
      await driver.ready(); return;
    }
    if (error instanceof PreparedError) {
      if (++preparations > 2) throw new Error('Target repeatedly needed scrolling; stopped before input.');
      onProgress('Target scrolled into view. Refreshing references before input; no stale-recovery budget used.');
      await driver.ready(); return;
    }
    if (!(error instanceof DOMAttemptError)) throw error;
    if (error instanceof CoveredError) {
      coveredRecovery = true;
      remember({ action: 'covered target', result: 'No input dispatched. Do not click an overlay or a different target. Use an exposed point on the original click target, an appropriate current DOM dialog-dismiss control, or done explaining the obstruction.' });
    }
    failedAttempt(error);
    await driver.ready();
  };
  try {
    await driver.acquire();
    await driver.ready();
    while (true) {
      driver.assert();
      onProgress(`Inspecting task page · ${actions}/${MAX_ACTIONS} actions used.`);
      let data;
      imageAttempt = false;
      try {
        data = await driver.snapshot();
        if (pendingObservation) {
          const previous = pendingObservation; pendingObservation = undefined;
          if (previous.key !== evidenceKey(data)) {
            consecutiveRecoveries = 0; preparations = 0; dispatched.clear(); coveredRecovery = false;
          } else {
            imageAttempt = previous.image;
            failedAttempt(new NoProgressError('No observable progress after the previous action.'));
            imageAttempt = false;
          }
        }
        if (coveredRecovery) data.coveredRecovery = true;
        if (vision) {
          if (visionFallbacks >= 2) throw new Error('Screenshot vision fallback limit reached; stopped without replaying input.');
          if (actions >= MAX_ACTIONS) throw new Error('30-action limit reached. Review the page before another run.');
          actions++; visionFallbacks++; imageAttempt = true; vision = false;
          onProgress(`Capturing a fresh viewport image (${visionFallbacks}/2) under this run’s consent…`);
          data.image = await driver.capture(data);
        }
        const { tabUrl, progress, ...modelData } = data;
        onProgress(data.image ? 'Asking Azure using DOM and viewport image…' : 'Asking Azure using DOM evidence…');
        const action = await nextAction(config, task, modelData, history, AbortSignal.any([driver.signal, AbortSignal.timeout(30000)]), fetch, usage.record);
        await driver.fresh(data, action);
        if (action.type === 'done') {
          let report = action.message;
          let note = 'Automation model report; verify against the page.';
          if (wantsSummary(task)) {
            onProgress('Writing results from observed evidence…');
            try {
              const { image, ...textData } = modelData;
              report = await summarizeResults(config, task, textData, history, report, AbortSignal.any([driver.signal, AbortSignal.timeout(30000)]), fetch, usage.record);
              note = 'AI-generated summary from bounded page evidence; not independently verified.';
            } catch (error) {
              driver.assert();
              if (error instanceof StaleError) throw error;
              note = `Summary unavailable: ${error.message} Automation report retained.`;
            }
            await driver.fresh(data);
          }
          onResult({ report, note, source: data.url, actions });
          return { report, actions, history, recoveries, visionFallbacks };
        }
        const waiting = ['wait', 'waitFor'].includes(action.type);
        if (!waiting && actions >= MAX_ACTIONS) throw new Error('30-action limit reached. Review the page before another run.');
        if (action.type === 'vision') {
          if (visionFallbacks >= 2) throw new Error('Screenshot vision fallback limit reached; stopped without replaying input.');
          vision = true;
          remember({ action: 'vision', result: 'A fresh screenshot will accompany the next observation.' });
          continue;
        }
        const key = actionKey(action, data);
        if (dispatched.has(key) || (action.type.startsWith('point') && sideEffects.has(action.type) && dispatched.size)) {
          throw new NoProgressError('Repeated dispatched action blocked until observable progress; no input replayed.');
        }
        onProgress(actionProgress(action, data.elements));
        const result = await driver.execute(action, data);
        if (!waiting) actions++;
        if (sideEffects.has(action.type) || ['fill', 'select'].includes(action.type)) dispatched.add(key);
        remember({ action: actionDescription(action), result });
        pendingObservation = { key: evidenceKey(data), image: imageAttempt };
        await driver.ready();
      } catch (error) { await recover(error); }
      finally { if (data?.image) { data.image.data = ''; delete data.image; } }
    }
  } finally { driver.close(); }
}
