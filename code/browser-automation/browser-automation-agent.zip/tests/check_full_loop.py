"""Full agent loop against the REAL Azure deployment and a simulated browser.

This is the closest thing to a real run without driving Chrome: the live model
sees genuine screenshots, decides which browser tool to call, and the fake
extension executes it. Proves vision + tools + the LangGraph loop work together
end to end with your Azure configuration.
"""

from __future__ import annotations

import asyncio
import base64
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import cv2
import numpy as np

from server.agent.runner import AgentRunner
from server.config import get_settings
from server.protocol import BrowserAction, SessionStatus
from server.sessions.session import BrowserBridgeError, Session


def render_page(state: str) -> str:
    """Draw a simple two-state page the model can reason about visually."""
    img = np.full((900, 1440, 3), 252, np.uint8)
    cv2.rectangle(img, (0, 0), (1440, 70), (240, 240, 240), -1)
    cv2.putText(img, "Demo Shop", (30, 48), cv2.FONT_HERSHEY_SIMPLEX, 1.1, (40, 40, 40), 2)

    if state == "home":
        cv2.putText(img, "Welcome!", (80, 220), cv2.FONT_HERSHEY_SIMPLEX, 1.6, (30, 30, 30), 3)
        # A single obvious green button the model must click.
        cv2.rectangle(img, (80, 300), (520, 390), (60, 160, 70), -1)
        cv2.putText(img, "View Basket", (120, 358), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255, 255, 255), 3)
    else:
        cv2.putText(img, "Your Basket", (80, 220), cv2.FONT_HERSHEY_SIMPLEX, 1.6, (30, 30, 30), 3)
        cv2.putText(img, "Total: 42 items", (80, 320), cv2.FONT_HERSHEY_SIMPLEX, 1.3, (20, 20, 20), 3)

    ok, buf = cv2.imencode(".png", img)
    assert ok
    return base64.b64encode(buf.tobytes()).decode()


class SimulatedBrowser(Session):
    """Session whose RPC layer renders a fake page instead of using Chrome."""

    def __init__(self) -> None:
        super().__init__("full-loop", "LOOP01")
        self.page = "home"
        self.calls: list[tuple[str, dict[str, Any]]] = []

    @property
    def extension_connected(self) -> bool:  # type: ignore[override]
        return True

    async def call(self, action, params=None, *, timeout=45.0):  # type: ignore[override]
        name = action.value if isinstance(action, BrowserAction) else str(action)
        params = params or {}
        self.calls.append((name, params))
        if self.stop_requested:
            raise BrowserBridgeError("task stopped by user")

        if name == "screenshot":
            return {
                "image": render_page(self.page),
                "url": f"https://demo.shop/{self.page}",
                "title": "Demo Shop - Basket" if self.page == "basket" else "Demo Shop",
                "device_pixel_ratio": 1.0,
                "viewport": {"width": 1440, "height": 900},
            }
        if name == "click":
            # The green button occupies roughly x 80-520, y 300-390.
            x, y = float(params.get("x", -1)), float(params.get("y", -1))
            if 60 <= x <= 540 and 285 <= y <= 405:
                self.page = "basket"
                return {"message": "clicked the View Basket button"}
            return {"message": f"clicked empty space at ({x:.0f},{y:.0f})"}
        if name == "get_tree":
            if self.page == "home":
                nodes = [
                    {
                        "role": "button", "name": "View Basket", "tag": "button",
                        "selector": "#basket",
                        "rect": {"x": 80, "y": 300, "w": 440, "h": 90, "cx": 300, "cy": 345},
                    }
                ]
            else:
                nodes = []
            return {"url": f"https://demo.shop/{self.page}", "nodes": nodes}
        if name == "get_page_info":
            return {
                "url": f"https://demo.shop/{self.page}",
                "title": "Demo Shop",
                "text": "Your Basket Total: 42 items" if self.page == "basket" else "Welcome! View Basket",
                "width": 1440, "height": 900, "scrollY": 0, "scrollHeight": 900,
                "readyState": "complete",
            }
        return {"message": f"{name} ok"}

    async def send_control(self, signal, payload=None):  # type: ignore[override]
        return None


async def main() -> int:
    settings = get_settings()
    if not settings.azure_configured:
        print("Azure is not configured - set AZURE_OPENAI_API_KEY in .env")
        return 1
    print(f"model: {settings.azure_openai_deployment} "
          f"({'v1' if settings.uses_v1_endpoint else 'classic'})\n")

    session = SimulatedBrowser()
    runner = AgentRunner(settings)

    prompt = (
        "You are on a shop page. Click the green 'View Basket' button, then "
        "tell me how many items the basket contains."
    )
    print(f"task: {prompt}\n")
    await runner.run_task(session, prompt, vision_mode="hybrid", max_steps=12)

    print("\n--- transcript ---")
    for event in session.event_log:
        kind, payload = event["event"], event["payload"]
        if kind == "tool_call":
            print(f"  [tool] {payload.get('tool')}({payload.get('args')})")
        elif kind == "tool_result":
            print(f"  [result] {str(payload.get('result'))[:120]}")
        elif kind in ("agent_message", "agent_thinking"):
            print(f"  [{payload.get('role', 'assistant')}] {str(payload.get('content'))[:260]}")
        elif kind == "error":
            print(f"  [ERROR] {str(payload.get('message'))[:300]}")

    actions = [c[0] for c in session.calls]
    final = [
        e for e in session.event_log
        if e["event"] == "agent_message" and e["payload"].get("role") == "assistant"
    ]
    answer = final[-1]["payload"]["content"] if final else ""

    print(f"\nstatus      : {session.status.value}")
    print(f"page state  : {session.page}")
    print(f"tool calls  : {actions}")

    errors = [e for e in session.event_log if e["event"] == "error"]
    if errors:
        print("\nFULL LOOP FAILED:", errors[-1]["payload"].get("message", "")[:300])
        return 1
    assert session.status is SessionStatus.DONE, session.status
    assert session.page == "basket", "the agent never clicked the button"
    assert "42" in answer, f"agent did not report the basket contents: {answer[:200]!r}"

    print("\nFULL LOOP PASSED - the live model saw the page, clicked it and read the result")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
