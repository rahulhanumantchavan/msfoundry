"""Verify the UI recovers when the extension is paired to an older session.

Reproduces the reported failure: Streamlit mints a fresh pairing code (e.g.
after a page refresh) while the extension is still attached to a previous one,
leaving the UI stuck on "Chrome extension is not connected".

Runs the server in-process and drives the real Streamlit app over its agent API.
"""

from __future__ import annotations

import asyncio
import json
import subprocess
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# The UI contains non-cp1252 glyphs; force UTF-8 so printing never crashes.
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import requests
import uvicorn
import websockets

API_PORT = 8777
UI_PORT = 8778
BASE = f"http://127.0.0.1:{API_PORT}"
UI = f"http://127.0.0.1:{UI_PORT}"
ROOT = Path(__file__).resolve().parent.parent


def start_api() -> uvicorn.Server:
    from server.api.app import app

    config = uvicorn.Config(app, host="127.0.0.1", port=API_PORT, log_level="warning")
    server = uvicorn.Server(config)
    threading.Thread(target=server.run, daemon=True).start()
    for _ in range(100):
        try:
            requests.get(f"{BASE}/health", timeout=1)
            return server
        except requests.RequestException:
            time.sleep(0.1)
    raise RuntimeError("API did not start")


def start_ui() -> subprocess.Popen:
    proc = subprocess.Popen(
        [
            sys.executable, "-m", "streamlit", "run", str(ROOT / "ui" / "app.py"),
            "--server.port", str(UI_PORT),
            "--server.headless", "true",
            "--server.enableAgentApi", "true",
        ],
        cwd=str(ROOT),
        env={**__import__("os").environ, "SERVER_PUBLIC_URL": BASE},
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    for _ in range(200):
        try:
            if requests.get(f"{UI}/_stcore/health", timeout=1).text.strip() == "ok":
                return proc
        except requests.RequestException:
            time.sleep(0.2)
    proc.terminate()
    raise RuntimeError("UI did not start")


def interact(payload: dict) -> dict:
    response = requests.post(
        f"{UI}/_stcore/agent/interact", json=payload, timeout=90
    )
    response.raise_for_status()
    return response.json()


def sidebar_text(tree: dict) -> list[str]:
    out: list[str] = []
    for node in tree["children"]:
        if node.get("type") != "sidebar":
            continue
        for child in node.get("children", []):
            props = child.get("props", {})
            text = f"{props.get('body', '')}{props.get('label', '')}"
            if text:
                out.append(f"[{child['type']}] {text}")
    return out


def find_action(doc: dict, label: str) -> str | None:
    for action in doc.get("actions", []):
        if action.get("label") == label:
            return action["key"]
    return None


async def main() -> int:
    ext_ready = asyncio.Event()
    release = asyncio.Event()
    paired_session: dict = {}

    pairing = requests.post(f"{BASE}/api/pairing", timeout=10).json()
    print(f"extension pairs with {pairing['pairing_code']} -> {pairing['session_id']}")

    async def hold_extension() -> None:
        async with websockets.connect(f"ws://127.0.0.1:{API_PORT}/ws/extension") as ws:
            await ws.send(
                json.dumps(
                    {
                        "type": "hello",
                        "pairing_code": pairing["pairing_code"],
                        "extension_version": "1.0.0",
                    }
                )
            )
            welcome = json.loads(await ws.recv())
            paired_session["id"] = welcome["session_id"]
            ext_ready.set()
            await release.wait()

    task = asyncio.create_task(hold_extension())
    await asyncio.wait_for(ext_ready.wait(), timeout=15)
    print(f"extension connected -> {paired_session['id']}")

    # The UI (fresh state, as after a refresh) must adopt it with no clicks.
    doc = await asyncio.to_thread(interact, {})
    lines = sidebar_text(doc["tree"])
    print("\nlanding sidebar:")
    for line in lines:
        print("  ", line)

    assert find_action(doc, "Use this connection") is None, (
        "adoption should be automatic now, not a button"
    )

    joined = " ".join(lines)
    assert "Browser connected" in joined, (
        "UI did not adopt the live extension automatically"
    )
    assert "not detected" not in joined
    print("\n-> UI adopted the live session automatically and reports it connected")

    status = requests.get(
        f"{BASE}/api/sessions/{paired_session['id']}", timeout=10
    ).json()
    assert status["extension_connected"] is True, status
    print(f"-> server agrees: session {paired_session['id']} is connected")

    release.set()
    await asyncio.wait_for(task, timeout=10)
    print("\nUI ADOPTION CHECK PASSED")
    return 0


if __name__ == "__main__":
    api = start_api()
    ui = start_ui()
    try:
        code = asyncio.run(main())
    finally:
        ui.terminate()
        ui.wait(timeout=10)
        api.should_exit = True
        time.sleep(1)
    raise SystemExit(code)
