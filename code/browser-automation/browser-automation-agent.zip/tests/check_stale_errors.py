"""Show where a displayed error came from: live failure or replayed log.

The UI replays the server's buffered event log on load, so an error from an
earlier run keeps reappearing even after the underlying bug is fixed.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import requests

BASE = "http://127.0.0.1:8000"


def main() -> int:
    sessions = requests.get(f"{BASE}/api/sessions", timeout=10).json()["sessions"]
    if not sessions:
        print("no sessions on the server")
        return 0

    for session in sessions:
        sid = session["session_id"]
        print(f"session {sid}")
        print(f"  status      : {session['status']}")
        print(f"  last_error  : {session['last_error']}")
        print(f"  steps       : {session['steps_taken']}")

        events = requests.get(
            f"{BASE}/api/sessions/{sid}/events", timeout=10
        ).json()["events"]
        errors = [
            (i, e["payload"].get("message", ""))
            for i, e in enumerate(events)
            if e["event"] == "error"
        ]
        print(f"  log entries : {len(events)}  (errors: {len(errors)})")
        for index, message in errors:
            print(f"    [{index}] {message[:140]}")

        if errors and not session["last_error"]:
            print(
                "  -> these errors are STALE: the session has no current error.\n"
                "     Press 'Clear' in the UI to drop the replayed log."
            )
        print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
