"""Drive a real task against the live, connected Chrome extension.

Requires a running server with an extension already paired. Exercises the
whole path: Azure OpenAI -> agent -> browser tool -> CDP -> screenshot ->
OpenCV -> UI events.

    python tests/check_live_task.py ["your prompt"]
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import requests

BASE = "http://127.0.0.1:8000"
DEFAULT_PROMPT = (
    "Take a screenshot and tell me the exact title of the page you can see. "
    "Do not navigate anywhere. Answer in one sentence."
)


def main(prompt: str) -> int:
    health = requests.get(f"{BASE}/health", timeout=10).json()
    print(f"server: azure={health['azure_configured']} "
          f"deployment={health['deployment']} mode={health['api_mode']}")
    if not health["azure_configured"]:
        print("Azure is not configured - set AZURE_OPENAI_API_KEY in .env")
        return 1

    live = requests.get(f"{BASE}/api/sessions/active/connected", timeout=10).json()
    sessions = live["sessions"]
    if not sessions:
        print("No extension is connected. Pair it in the extension popup first.")
        return 1

    session_id = sessions[0]["session_id"]
    print(f"session: {session_id} (code {sessions[0]['pairing_code']})\n")

    start = requests.post(
        f"{BASE}/api/task/start",
        json={"session_id": session_id, "prompt": prompt},
        timeout=30,
    )
    print(f"task/start -> {start.status_code} {start.text[:120]}\n")
    if start.status_code != 200:
        return 1

    cursor = 0
    deadline = time.time() + 180
    final_status = None
    saw_screenshot = False
    errors: list[str] = []

    while time.time() < deadline:
        batch = requests.get(
            f"{BASE}/api/sessions/{session_id}/events",
            params={"since": cursor},
            timeout=15,
        ).json()
        cursor = batch["cursor"]
        for event in batch["events"]:
            kind, payload = event["event"], event["payload"]
            if kind == "screenshot":
                saw_screenshot = True
                print(f"  [screenshot] {payload.get('title')} "
                      f"({len(payload.get('image', ''))} chars)")
            elif kind == "tool_call":
                print(f"  [tool] {payload.get('tool')}({payload.get('args')})")
            elif kind == "tool_result":
                print(f"  [result] {str(payload.get('result'))[:140]}")
            elif kind in ("agent_message", "agent_thinking"):
                role = payload.get("role", "assistant")
                print(f"  [{role}] {str(payload.get('content'))[:300]}")
            elif kind == "error":
                errors.append(str(payload.get("message")))
                print(f"  [ERROR] {str(payload.get('message'))[:400]}")
            elif kind == "status":
                final_status = payload.get("status")

        status = requests.get(
            f"{BASE}/api/sessions/{session_id}", timeout=10
        ).json()
        final_status = status["status"]
        if final_status in ("done", "error", "idle") and cursor > 2:
            break
        time.sleep(1.5)

    print(f"\nfinal status  : {final_status}")
    print(f"screenshot    : {saw_screenshot}")
    print(f"errors        : {errors[:2] if errors else 'none'}")

    if errors:
        print("\nLIVE TASK FAILED")
        return 1
    if final_status != "done":
        print(f"\nLIVE TASK DID NOT COMPLETE (status={final_status})")
        return 1
    print("\nLIVE TASK PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else DEFAULT_PROMPT))
