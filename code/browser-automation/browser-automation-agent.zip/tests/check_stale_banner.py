"""A past error must not stick to the UI banner after a later run succeeds.

Reproduces the reported symptom: the page kept showing
``Unsupported parameter: 'temperature'`` even though the server reported
``last_error: null`` and the most recent task finished successfully.
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import requests
import uvicorn
import websockets

API_PORT = 8783
UI_PORT = 8784
BASE = f"http://127.0.0.1:{API_PORT}"
UI = f"http://127.0.0.1:{UI_PORT}"
ROOT = Path(__file__).resolve().parent.parent

STALE = "OpenAIInvalidRequestError: Error code: 400 - Unsupported parameter: 'temperature'"


def start_api() -> uvicorn.Server:
    from server.api.app import app

    config = uvicorn.Config(app, host="127.0.0.1", port=API_PORT, log_level="warning")
    server = uvicorn.Server(config)
    threading.Thread(target=server.run, daemon=True).start()
    for _ in range(100):
        try:
            requests.get(f"{BASE}/health", timeout=1)
            return server
        except requests.RequestException:
            time.sleep(0.1)
    raise RuntimeError("API did not start")


def start_ui() -> subprocess.Popen:
    proc = subprocess.Popen(
        [
            sys.executable, "-m", "streamlit", "run", str(ROOT / "ui" / "app.py"),
            "--server.port", str(UI_PORT),
            "--server.headless", "true",
            "--server.enableAgentApi", "true",
        ],
        cwd=str(ROOT),
        env={**os.environ, "SERVER_PUBLIC_URL": BASE},
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    for _ in range(200):
        try:
            if requests.get(f"{UI}/_stcore/health", timeout=1).text.strip() == "ok":
                return proc
        except requests.RequestException:
            time.sleep(0.2)
    proc.terminate()
    raise RuntimeError("UI did not start")


def interact(payload: dict) -> dict:
    response = requests.post(f"{UI}/_stcore/agent/interact", json=payload, timeout=120)
    response.raise_for_status()
    doc = response.json()
    for _ in range(4):
        if "tree" in doc:
            return doc
        if doc.get("error", {}).get("code") != "wait_timed_out":
            raise AssertionError(f"agent API error: {doc.get('error')}")
        response = requests.post(
            f"{UI}/_stcore/agent/interact",
            json={"session_id": doc["session_id"]},
            timeout=120,
        )
        response.raise_for_status()
        doc = response.json()
    raise AssertionError(f"app never settled: {doc.get('error')}")


def banner_text(tree: dict) -> str:
    """Collect only st.error banners (not transcript entries)."""
    found: list[str] = []

    def walk(node: dict) -> None:
        if node.get("type") == "error":
            found.append(str(node.get("props", {}).get("body", "")))
        for child in node.get("children", []):
            walk(child)

    walk(tree)
    return " ".join(found)


async def main() -> int:
    from server.protocol import SessionStatus, StreamEvent
    from server.sessions import get_session_manager

    # A session that failed earlier, then succeeded - exactly the user's state.
    ticket = get_session_manager().create_pairing()
    session = get_session_manager().get(ticket.session_id)
    assert session is not None

    ready = asyncio.Event()
    release = asyncio.Event()

    async def connect() -> None:
        async with websockets.connect(f"ws://127.0.0.1:{API_PORT}/ws/extension") as ws:
            await ws.send(
                json.dumps(
                    {
                        "type": "hello",
                        "pairing_code": ticket.code,
                        "extension_version": "1.0.0",
                    }
                )
            )
            json.loads(await ws.recv())
            ready.set()
            await release.wait()

    task = asyncio.create_task(connect())
    await asyncio.wait_for(ready.wait(), timeout=15)

    # Old failure still sitting in the replayed log...
    await session.broadcast(StreamEvent.ERROR, {"message": STALE})
    # ...but the latest run finished cleanly.
    session.finish_task(SessionStatus.DONE, None)
    await session.broadcast_status()
    print(f"server last_error: {session.last_error!r} (status {session.status.value})")

    # The UI adopts the live session automatically - no pairing click needed.
    doc = await asyncio.to_thread(interact, {})
    banner = banner_text(doc["tree"])
    print(f"error banners on page: {banner[:160]!r}")

    release.set()
    await asyncio.wait_for(task, timeout=10)

    assert "temperature" not in banner, (
        "STALE ERROR still shown in the banner after a successful run"
    )
    print("\nSTALE BANNER CHECK PASSED (old error is not shown)")
    return 0


if __name__ == "__main__":
    api = start_api()
    ui = start_ui()
    try:
        code = asyncio.run(main())
    finally:
        ui.terminate()
        ui.wait(timeout=10)
        api.should_exit = True
        time.sleep(1)
    raise SystemExit(code)
