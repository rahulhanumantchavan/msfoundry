"""The poll cursor must never skip frames when the log prunes itself.

Regression guard for "the live browser view stops updating".

The event log keeps only the newest screenshot payload. When that pruning
*removed* the old entry, every later frame shifted down one index - and the UI
polls with ``since=<cursor>``. The cursor therefore pointed past frames that
had never been delivered, so new screenshots were silently skipped and the
image froze while the chat kept moving.

Frames now carry a monotonic ``seq`` and the cursor tracks that instead.
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from server.protocol import StreamEvent  # noqa: E402
from server.sessions.session import Session  # noqa: E402


def poll(session: Session, since: int) -> tuple[list[dict], int]:
    """Mirror /api/sessions/{id}/events exactly."""
    log = session.event_log
    fresh = [f for f in log if int(f.get("seq") or 0) > since]
    cursor = int(log[-1].get("seq") or 0) if log else since
    return fresh, cursor


async def main() -> int:
    session = Session("cursor-test", pairing_code="")

    # Interleave screenshots with other traffic, polling as the UI does.
    cursor = 0
    seen_images: list[str] = []
    seen_events: list[str] = []

    for step in range(1, 6):
        await session.broadcast(StreamEvent.TOOL_CALL, {"name": f"click-{step}"})
        await session.broadcast(
            StreamEvent.SCREENSHOT, {"image": f"image-{step}", "url": f"u{step}"}
        )
        await session.broadcast(StreamEvent.TOOL_RESULT, {"ok": True})

        events, cursor = poll(session, cursor)
        for frame in events:
            seen_events.append(frame["event"])
            if frame["event"] == StreamEvent.SCREENSHOT.value:
                image = (frame.get("payload") or {}).get("image")
                if image:
                    seen_images.append(image)

    print(f"frames delivered: {len(seen_events)}")
    print(f"images delivered: {seen_images}")

    expected = [f"image-{i}" for i in range(1, 6)]
    assert seen_images == expected, (
        f"UI would have missed screenshots: got {seen_images}, want {expected}"
    )

    tool_calls = [e for e in seen_events if e == StreamEvent.TOOL_CALL.value]
    assert len(tool_calls) == 5, f"tool calls were skipped too: {len(tool_calls)}"
    print("every screenshot and tool call reached the UI")

    # Only the newest screenshot keeps its payload, so memory stays bounded.
    stored = [
        f for f in session.event_log
        if f["event"] == StreamEvent.SCREENSHOT.value
        and (f.get("payload") or {}).get("image")
    ]
    assert len(stored) == 1, f"expected 1 retained image, found {len(stored)}"
    assert stored[0]["payload"]["image"] == "image-5", stored[0]["payload"]["image"]
    print("log retains exactly one image payload (the newest)")

    # A late client replaying from scratch must still get the current frame.
    replay, _ = poll(session, 0)
    images = [
        (f.get("payload") or {}).get("image")
        for f in replay
        if f["event"] == StreamEvent.SCREENSHOT.value
    ]
    assert "image-5" in images, images
    print("a late-joining client still receives the current screenshot")

    # Sequence numbers must be strictly increasing across the whole log.
    seqs = [f["seq"] for f in session.event_log]
    assert seqs == sorted(seqs) and len(set(seqs)) == len(seqs), seqs
    print(f"sequence numbers are monotonic (1..{seqs[-1]})")

    await check_slow_poll()
    print("\nEVENT CURSOR CHECK PASSED")
    return 0


async def check_slow_poll() -> None:
    """The failing case: several frames land between two UI polls.

    The agent emits a screenshot plus a few text frames per action, while the
    UI polls about once a second. With an index cursor the pruned screenshot
    shifted the log and the cursor ran ahead, so most frames were never
    delivered - the view froze while the transcript kept moving.
    """
    print("\n-- frames arriving faster than the UI polls --")
    session = Session("slow-poll", pairing_code="")
    cursor = 0
    images: list[str] = []
    tool_calls = 0

    for step in range(1, 6):
        await session.broadcast(StreamEvent.SCREENSHOT, {"image": f"image-{step}"})
        await session.broadcast(StreamEvent.TOOL_CALL, {"name": f"act-{step}"})
        await session.broadcast(StreamEvent.TOOL_RESULT, {"ok": True})
        await session.broadcast(StreamEvent.AGENT_THINKING, {"text": "..."})
        if step % 2 == 0:  # the UI only gets to poll every other action
            events, cursor = poll(session, cursor)
            for frame in events:
                if frame["event"] == StreamEvent.SCREENSHOT.value:
                    if (frame.get("payload") or {}).get("image"):
                        images.append(frame["payload"]["image"])
                elif frame["event"] == StreamEvent.TOOL_CALL.value:
                    tool_calls += 1

    events, cursor = poll(session, cursor)
    for frame in events:
        if frame["event"] == StreamEvent.SCREENSHOT.value:
            if (frame.get("payload") or {}).get("image"):
                images.append(frame["payload"]["image"])
        elif frame["event"] == StreamEvent.TOOL_CALL.value:
            tool_calls += 1

    print(f"  tool calls delivered: {tool_calls}/5")
    print(f"  newest image delivered: {images[-1] if images else None}")
    assert tool_calls == 5, f"UI missed tool calls: {tool_calls}/5"
    # Older screenshots are legitimately pruned, but the latest must arrive -
    # that is what keeps the live view moving.
    assert images and images[-1] == "image-5", images


if __name__ == "__main__":
    try:
        raise SystemExit(asyncio.run(main()))
    except AssertionError as exc:
        print(f"\nFAILED: {exc}")
        raise SystemExit(1) from exc
