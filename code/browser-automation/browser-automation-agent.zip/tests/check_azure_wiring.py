"""Verify Azure endpoint detection builds a client that hits the right URL."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from server.agent.runner import build_llm
from server.config import Settings

V1 = "https://rahulhchavan-secondproj-resource.services.ai.azure.com/openai/v1"
CLASSIC = "https://my-resource.openai.azure.com/"

CASES = [
    ("v1 endpoint (auto)", V1, "auto", "gpt-6-astra", True),
    ("v1 endpoint, trailing slash", V1 + "/", "auto", "gpt-6-astra", True),
    ("classic endpoint (auto)", CLASSIC, "auto", "gpt-4o", False),
    ("classic forced to v1", CLASSIC, "v1", "gpt-4o", True),
    ("v1 forced to classic", V1, "classic", "gpt-6-astra", False),
]

failures: list[str] = []

for label, endpoint, mode, deployment, expect_v1 in CASES:
    settings = Settings(
        AZURE_OPENAI_ENDPOINT=endpoint,
        AZURE_OPENAI_API_KEY="test-key",
        AZURE_OPENAI_DEPLOYMENT=deployment,
        AZURE_OPENAI_API_MODE=mode,
    )
    detected = settings.uses_v1_endpoint
    llm = build_llm(settings)
    base = str(llm.root_client.base_url)
    kind = type(llm).__name__

    status = "ok" if detected == expect_v1 else "MISMATCH"
    if detected != expect_v1:
        failures.append(f"{label}: expected v1={expect_v1}, got {detected}")
    print(f"[{status}] {label}")
    print(f"        client : {kind}")
    print(f"        base   : {base}")

    if detected:
        # The OpenAI-compatible surface must post to <base>/chat/completions
        # with no deployment segment injected.
        if "/openai/deployments/" in base:
            failures.append(f"{label}: v1 client has a deployment path: {base}")
        # The base must be exactly the configured endpoint. An explicit
        # mode override is allowed to point anywhere, so only compare paths.
        if base.rstrip("/") != endpoint.rstrip("/"):
            failures.append(
                f"{label}: v1 base {base!r} does not match endpoint {endpoint!r}"
            )
        print(f"        call   : {base.rstrip('/')}/chat/completions")
        print(f"        model  : {llm.model_name}")
    else:
        if "/openai/deployments/" not in base:
            failures.append(f"{label}: classic client missing deployment path: {base}")
        print(f"        call   : {base}chat/completions?api-version=...")
    print()

print(f"total cases: {len(CASES)}")
if failures:
    print("\nFAILURES:")
    for failure in failures:
        print(" -", failure)
    raise SystemExit(1)
print("AZURE WIRING CHECK PASSED")
