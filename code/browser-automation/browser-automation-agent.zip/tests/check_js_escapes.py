"""Catch escape-sequence bugs inside injected-JavaScript template literals.

Code sent to the page is built inside a JS template literal, so a single
backslash escape (``\n``) is consumed when the string is constructed and the
page receives a raw newline. Inside a regex that produces
``SyntaxError: Invalid regular expression``. Such escapes must be doubled.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parent.parent
TARGET = ROOT / "extension" / "lib" / "automation.js"

source = TARGET.read_text(encoding="utf-8-sig")

# Grab every `...` template literal (the injected page scripts).
blocks = re.findall(r"`([^`]*)`", source, re.S)
print(f"template literals scanned: {len(blocks)}")

# A single backslash followed by n/r/t/u inside an injected block is suspect.
single_escape = re.compile(r"(?<!\\)\\(?![\\])[nrtu]")

problems: list[str] = []
for index, block in enumerate(blocks):
    if "document" not in block and "window" not in block:
        continue  # not an injected page script
    for match in single_escape.finditer(block):
        line_start = block.rfind("\n", 0, match.start()) + 1
        line_end = block.find("\n", match.start())
        line = block[line_start : line_end if line_end != -1 else len(block)]
        problems.append(f"block {index}: {match.group()!r} in: {line.strip()[:110]}")

if problems:
    print("\nESCAPE PROBLEMS FOUND:")
    for problem in problems:
        print(" -", problem)
    raise SystemExit(1)

print("no single-backslash escapes inside injected scripts")
print("JS ESCAPE CHECK PASSED")
