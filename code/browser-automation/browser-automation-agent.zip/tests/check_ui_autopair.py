"""Verify the UI notices an extension that connects *after* the page is shown.

The UI creates its session automatically and the extension is woken on demand,
so the page must pick up the connection on its own poll - without the user
touching anything.
"""

from __future__ import annotations

import asyncio
import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import requests
import uvicorn
import websockets

API_PORT = 8779
UI_PORT = 8780
BASE = f"http://127.0.0.1:{API_PORT}"
UI = f"http://127.0.0.1:{UI_PORT}"
ROOT = Path(__file__).resolve().parent.parent


def start_api() -> uvicorn.Server:
    from server.api.app import app

    config = uvicorn.Config(app, host="127.0.0.1", port=API_PORT, log_level="warning")
    server = uvicorn.Server(config)
    threading.Thread(target=server.run, daemon=True).start()
    for _ in range(100):
        try:
            requests.get(f"{BASE}/health", timeout=1)
            return server
        except requests.RequestException:
            time.sleep(0.1)
    raise RuntimeError("API did not start")


def start_ui() -> subprocess.Popen:
    proc = subprocess.Popen(
        [
            sys.executable, "-m", "streamlit", "run", str(ROOT / "ui" / "app.py"),
            "--server.port", str(UI_PORT),
            "--server.headless", "true",
            "--server.enableAgentApi", "true",
        ],
        cwd=str(ROOT),
        env={**os.environ, "SERVER_PUBLIC_URL": BASE},
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    for _ in range(200):
        try:
            if requests.get(f"{UI}/_stcore/health", timeout=1).text.strip() == "ok":
                return proc
        except requests.RequestException:
            time.sleep(0.2)
    proc.terminate()
    raise RuntimeError("UI did not start")


def interact(payload: dict) -> dict:
    """POST to the agent API, retrying the documented ``wait_timed_out`` case.

    A page that is actively polling may not settle within the API's 30s
    budget; the protocol says to re-send with only ``session_id`` to keep
    waiting rather than restarting the interaction.
    """
    response = requests.post(f"{UI}/_stcore/agent/interact", json=payload, timeout=120)
    response.raise_for_status()
    doc = response.json()
    for _ in range(4):
        if "tree" in doc:
            return doc
        if doc.get("error", {}).get("code") != "wait_timed_out":
            raise AssertionError(f"agent API error: {doc.get('error')}")
        response = requests.post(
            f"{UI}/_stcore/agent/interact",
            json={"session_id": doc["session_id"]},
            timeout=120,
        )
        response.raise_for_status()
        doc = response.json()
    raise AssertionError(f"app never settled: {doc.get('error')}")


def all_text(tree: dict) -> str:
    parts: list[str] = []

    def walk(node: dict) -> None:
        props = node.get("props", {})
        parts.append(f"{props.get('body', '')}{props.get('label', '')}")
        for child in node.get("children", []):
            walk(child)

    walk(tree)
    return " ".join(p for p in parts if p)


def find_action(doc: dict, label: str) -> str | None:
    for action in doc.get("actions", []):
        if action.get("label") == label:
            return action["key"]
    return None


async def main() -> int:
    # 1. Open the UI - the session is created automatically, no pairing step.
    doc = await asyncio.to_thread(interact, {})
    ui_session = doc["session_id"]
    text = all_text(doc["tree"])
    assert find_action(doc, "Create pairing code") is None, (
        "pairing button should be gone - connection is automatic now"
    )
    assert "not detected" in text or "not reachable" in text, text[:300]
    print("UI auto-created a session and shows the idle state")

    live = requests.get(f"{BASE}/api/sessions", timeout=10).json()["sessions"]
    target = [s for s in live if not s["extension_connected"]][-1]
    code = requests.get(
        f"{BASE}/api/sessions/{target['session_id']}", timeout=10
    ).json()["pairing_code"]
    print(f"auto-issued code {code} -> session {target['session_id']}")

    # 2. NOW the extension connects - exactly what the user does.
    ready = asyncio.Event()
    release = asyncio.Event()

    async def connect_extension() -> None:
        async with websockets.connect(f"ws://127.0.0.1:{API_PORT}/ws/extension") as ws:
            await ws.send(
                json.dumps(
                    {"type": "hello", "pairing_code": code, "extension_version": "1.0.0"}
                )
            )
            json.loads(await ws.recv())
            ready.set()
            await release.wait()

    task = asyncio.create_task(connect_extension())
    await asyncio.wait_for(ready.wait(), timeout=15)
    print("extension paired on the server")

    # 3. The page must pick this up on its own poll, with no new user input.
    detected = False
    for attempt in range(8):
        doc = await asyncio.to_thread(interact, {"session_id": ui_session})
        text = all_text(doc["tree"])
        if "Browser connected" in text:
            detected = True
            print(f"UI reported the connection (poll {attempt + 1})")
            break
        await asyncio.sleep(1.5)

    release.set()
    await asyncio.wait_for(task, timeout=10)

    assert detected, (
        "UI never noticed the extension - it is stuck on the idle state"
    )
    assert "not detected" not in text, text[:300]
    print("\nUI AUTOPAIR CHECK PASSED")
    return 0


if __name__ == "__main__":
    api = start_api()
    ui = start_ui()
    try:
        code_ = asyncio.run(main())
    finally:
        ui.terminate()
        ui.wait(timeout=10)
        api.should_exit = True
        time.sleep(1)
    raise SystemExit(code_)
