"""Pair with a *running* server using a code minted by the live UI.

Proves the real deployment path end to end: UI -> server -> extension socket,
across process boundaries (unlike test_bridge.py which runs in-process).

    python tests/check_live_pairing.py <PAIRING_CODE> [session_id]
"""

from __future__ import annotations

import asyncio
import base64
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import cv2
import numpy as np
import requests
import websockets

BASE = "http://127.0.0.1:8000"
WS = "ws://127.0.0.1:8000"


def fake_png() -> str:
    img = np.full((900, 1440, 3), 248, np.uint8)
    cv2.putText(img, "Live pairing OK", (80, 460), cv2.FONT_HERSHEY_SIMPLEX, 2, (40, 40, 40), 4)
    ok, buf = cv2.imencode(".png", img)
    assert ok
    return base64.b64encode(buf.tobytes()).decode()


async def main(code: str) -> int:
    async with websockets.connect(f"{WS}/ws/extension") as ws:
        await ws.send(
            json.dumps(
                {
                    "type": "hello",
                    "pairing_code": code,
                    "extension_version": "1.0.0",
                    "capabilities": ["screenshot", "navigate"],
                }
            )
        )
        welcome = json.loads(await ws.recv())
        if welcome.get("type") != "welcome":
            print("handshake REJECTED:", welcome)
            return 1
        session_id = welcome["session_id"]
        print(f"paired -> session {session_id}")

        status = requests.get(f"{BASE}/api/sessions/{session_id}", timeout=10).json()
        print("extension_connected:", status["extension_connected"])
        assert status["extension_connected"], "server did not register the extension"

        # Answer one screenshot command to prove the RPC path is live.
        async def responder() -> None:
            shot = fake_png()
            while True:
                frame = json.loads(await ws.recv())
                if frame.get("type") != "command":
                    continue
                print("  command received:", frame["action"])
                await ws.send(
                    json.dumps(
                        {
                            "type": "result",
                            "id": frame["id"],
                            "ok": True,
                            "data": {
                                "image": shot,
                                "url": "https://example.com/",
                                "title": "Live Test",
                                "device_pixel_ratio": 1.0,
                                "viewport": {"width": 1440, "height": 900},
                            },
                        }
                    )
                )

        task = asyncio.create_task(responder())
        # Starting a task must now fail on Azure config, not on the bridge -
        # that proves pairing and dispatch are healthy.
        resp = requests.post(
            f"{BASE}/api/task/start",
            json={"session_id": session_id, "prompt": "say hello"},
            timeout=20,
        )
        print("task/start ->", resp.status_code, resp.text[:160])
        assert resp.status_code == 200, "bridge rejected a paired session"

        await asyncio.sleep(3.0)
        task.cancel()

        events = requests.get(
            f"{BASE}/api/sessions/{session_id}/events", timeout=10
        ).json()["events"]
        kinds = [e.get("event") for e in events]
        print("ui events:", kinds)

        errors = [
            e["payload"].get("message", "")
            for e in events
            if e.get("event") == "error"
        ]
        if errors:
            print("expected config error:", errors[-1][:120])
            assert "Azure" in errors[-1], f"unexpected failure: {errors[-1]}"

        print("\nLIVE PAIRING CHECK PASSED")
        return 0


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        raise SystemExit(2)
    raise SystemExit(asyncio.run(main(sys.argv[1])))
