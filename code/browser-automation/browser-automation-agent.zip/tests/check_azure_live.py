"""Live Azure OpenAI capability probe.

Confirms the configured deployment can do the three things the browser agent
depends on: plain chat, **vision** (image input) and **tool calling**.

    python tests/check_azure_live.py
"""

from __future__ import annotations

import base64
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import cv2
import numpy as np
from langchain_core.messages import HumanMessage
from langchain_core.tools import tool

from server.agent.runner import build_llm
from server.config import get_settings


def sample_image_b64() -> str:
    """A screenshot-like image with a word the model must read back."""
    img = np.full((600, 900, 3), 250, np.uint8)
    cv2.rectangle(img, (120, 220), (780, 330), (255, 255, 255), -1)
    cv2.rectangle(img, (120, 220), (780, 330), (150, 150, 150), 3)
    cv2.putText(img, "PINEAPPLE", (160, 300), cv2.FONT_HERSHEY_SIMPLEX, 2.2, (30, 30, 30), 5)
    ok, buf = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), 90])
    assert ok
    return base64.b64encode(buf.tobytes()).decode()


@tool
def click(x: int, y: int) -> str:
    """Click the page at the given viewport coordinates."""
    return f"clicked {x},{y}"


def main() -> int:
    settings = get_settings()
    print(f"deployment : {settings.azure_openai_deployment}")
    print(f"endpoint   : {settings.azure_openai_endpoint}")
    print(f"mode       : {'v1' if settings.uses_v1_endpoint else 'classic'}")
    print(f"temperature: {settings.azure_openai_temperature}\n")

    llm = build_llm(settings)
    failures: list[str] = []

    # 1. plain chat
    try:
        reply = llm.invoke([("human", "Reply with exactly: OK")])
        print(f"[chat]   {reply.content[:60]!r}")
    except Exception as exc:  # noqa: BLE001
        failures.append(f"chat: {exc}")
        print(f"[chat]   FAILED: {exc}")

    # 2. vision - the agent attaches a screenshot to every turn
    try:
        message = HumanMessage(
            content=[
                {
                    "type": "text",
                    "text": "What single word is written in this image? Reply with just that word.",
                },
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/jpeg;base64,{sample_image_b64()}"},
                },
            ]
        )
        reply = llm.invoke([message])
        text = str(reply.content)
        print(f"[vision] {text[:80]!r}")
        if "PINEAPPLE" not in text.upper():
            failures.append(f"vision: model did not read the image (got {text[:60]!r})")
    except Exception as exc:  # noqa: BLE001
        failures.append(f"vision: {exc}")
        print(f"[vision] FAILED: {exc}")

    # 3. tool calling - every browser action is a tool call
    try:
        bound = llm.bind_tools([click])
        reply = bound.invoke(
            [("human", "Click the button at coordinates x=100, y=250 using the tool.")]
        )
        calls = getattr(reply, "tool_calls", []) or []
        print(f"[tools]  {[(c['name'], c['args']) for c in calls]}")
        if not calls:
            failures.append("tools: model returned no tool call")
    except Exception as exc:  # noqa: BLE001
        failures.append(f"tools: {exc}")
        print(f"[tools]  FAILED: {exc}")

    if failures:
        print("\nFAILURES:")
        for failure in failures:
            print(" -", failure)
        return 1
    print("\nAZURE LIVE CHECK PASSED (chat + vision + tools)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
