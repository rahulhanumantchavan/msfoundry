"""Screenshots must reach the UI after every action.

Regression guard for "the live browser view is not updating".

This drives the real `BrowserToolkit` against a stubbed extension and consumes
frames exactly the way the Streamlit poll loop does, including the case that
actually broke: several frames landing between two polls.
"""

from __future__ import annotations

import asyncio
import base64
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from server.agent.browser_tools import BrowserToolkit  # noqa: E402
from server.config import get_settings  # noqa: E402
from server.protocol import StreamEvent  # noqa: E402
from server.sessions.session import Session  # noqa: E402
from server.vision.pipeline import VisionPipeline  # noqa: E402

def _tiny_png() -> str:
    """A real 8x8 PNG, built so the vision pipeline can actually decode it."""
    import io

    import numpy as np
    from PIL import Image

    array = np.zeros((8, 8, 3), dtype=np.uint8)
    array[:4, :, 0] = 255  # top half red, bottom half black
    buffer = io.BytesIO()
    Image.fromarray(array).save(buffer, format="PNG")
    return base64.b64encode(buffer.getvalue()).decode()


PNG_B64 = _tiny_png()


class StubSession(Session):
    """A session whose extension always answers, so no browser is needed."""

    async def call(
        self,
        action: Any,
        params: dict[str, Any] | None = None,
        *,
        timeout: float = 45.0,
    ) -> dict[str, Any]:
        name = action.value if hasattr(action, "value") else str(action)
        if name == "screenshot":
            return {
                "image": PNG_B64,
                "device_pixel_ratio": 1.0,
                "url": "https://example.com",
                "title": "Example",
                "viewport": {"width": 8, "height": 8},
                "ts": 0,
            }
        return {"message": "ok", "url": "https://example.com"}


def poll(session: Session, since: int) -> tuple[list[dict], int]:
    """Mirror /api/sessions/{id}/events."""
    log = session.event_log
    fresh = [f for f in log if int(f.get("seq") or 0) > since]
    cursor = int(log[-1].get("seq") or 0) if log else since
    return fresh, cursor


def images_in(frames: list[dict]) -> list[str]:
    return [
        f["payload"]["image"]
        for f in frames
        if f.get("event") == StreamEvent.SCREENSHOT.value
        and (f.get("payload") or {}).get("image")
    ]


async def run(poll_every: int, actions: int = 6) -> tuple[int, str | None]:
    """Act `actions` times, polling every `poll_every` actions."""
    settings = get_settings()
    session = StubSession("live-view", pairing_code="")
    vision = VisionPipeline(
        max_width=settings.vision_max_width,
        enhance_contrast=settings.vision_enhance_contrast,
        denoise=settings.vision_denoise,
        jpeg_quality=settings.vision_jpeg_quality,
    )
    toolkit = BrowserToolkit(session, settings, vision)

    cursor = 0
    received: list[str] = []
    for i in range(1, actions + 1):
        await toolkit.navigate("https://example.com")
        await session.broadcast(StreamEvent.TOOL_CALL, {"tool": "navigate"})
        await session.broadcast(StreamEvent.TOOL_RESULT, {"ok": True})
        if i % poll_every == 0:
            frames, cursor = poll(session, cursor)
            received.extend(images_in(frames))

    frames, cursor = poll(session, cursor)
    received.extend(images_in(frames))
    return len(received), (received[-1][:22] if received else None)


async def main() -> int:
    # Fast poller: the UI sees every frame.
    count, newest = await run(poll_every=1)
    print(f"poll after every action   -> {count} screenshots, newest={newest}")
    assert count == 6, f"expected 6 screenshots, got {count}"
    assert newest and newest.startswith("data:image"), newest

    # Slow poller: this is the case that froze the view. Older frames are
    # legitimately pruned, but the UI must always end up with a current image.
    count, newest = await run(poll_every=3)
    print(f"poll every third action   -> {count} screenshots, newest={newest}")
    assert count >= 2, f"UI starved of screenshots: {count}"
    assert newest and newest.startswith("data:image"), newest

    # A single poll at the very end must still deliver the live frame.
    count, newest = await run(poll_every=99)
    print(f"one poll at the end       -> {count} screenshots, newest={newest}")
    assert count >= 1, "UI received no screenshot at all"
    assert newest and newest.startswith("data:image"), newest

    print("\nLIVE VIEW CHECK PASSED")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(asyncio.run(main()))
    except AssertionError as exc:
        print(f"\nFAILED: {exc}")
        raise SystemExit(1) from exc
