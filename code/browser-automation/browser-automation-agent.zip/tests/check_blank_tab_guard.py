"""The agent tab starts blank, so `about:blank` must be controllable.

Regression guard for the reported failure: `about:` was treated as a protected
prefix, which made `about:blank` look like a privileged page. That had two
visible effects:

  * `tabIsUsable()` always said no, so every action created *another* tab
    (the user saw five blank tabs),
  * `attach()` threw "cannot control a protected page", so the agent reported
    that it could not open Google.

Real `about:` pages (about:settings, about:config) must stay protected.
"""

from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
AUTOMATION = ROOT / "extension" / "lib" / "automation.js"

CASES = [
    # (url, expected isProtectedUrl)
    ("about:blank", False),
    ("about:blank#frag", False),
    ("about:newtab", False),
    ("https://www.google.com", False),
    ("http://localhost:8501/", False),
    ("about:settings", True),
    ("about:config", True),
    ("chrome://extensions", True),
    ("chrome-extension://abc/page.html", True),
    ("devtools://devtools/bundled/inspector.html", True),
    ("https://chromewebstore.google.com/detail/x", True),
    ("", True),
    (None, True),
]


def main() -> int:
    source = AUTOMATION.read_text(encoding="utf-8")

    # Lift the guard region (both constants and both functions) out of the ES
    # module in one piece so it can run under node.
    region = re.search(
        r"const PROTECTED_PREFIXES = \[.*?\n\}\n(?=\nconst sleep)",
        source,
        re.S,
    )
    assert region, "could not locate the URL guards in automation.js"
    guards = region.group(0).replace("export function", "function")
    assert "isBlankUrl" in guards and "isProtectedUrl" in guards, guards[:200]

    harness = (
        guards
        + "\nconst CASES = "
        + json.dumps([list(case) for case in CASES])
        + ";\n"
        + """
        let failures = 0;
        for (const [url, expected] of CASES) {
          const actual = isProtectedUrl(url);
          const ok = actual === expected;
          if (!ok) failures += 1;
          console.log(
            `${ok ? 'ok  ' : 'FAIL'}  isProtectedUrl(${JSON.stringify(url)}) = ${actual} (want ${expected})`
          );
        }
        console.log(failures === 0 ? 'ALL_OK' : `FAILURES=${failures}`);
        """
    )

    result = subprocess.run(
        ["node", "--input-type=module", "-e", harness],
        capture_output=True,
        text=True,
        cwd=str(ROOT),
    )
    print(result.stdout.strip())
    if result.returncode != 0:
        print(result.stderr.strip())
        return 1
    if "ALL_OK" not in result.stdout:
        print("\nFAILED: blank-tab guard is wrong")
        return 1

    # The agent tab is created blank, so creation and the usability check must
    # agree - otherwise every action spawns a fresh tab.
    background = (ROOT / "extension" / "background.js").read_text(encoding="utf-8")
    assert "chrome.tabs.create({ url: 'about:blank'" in background, (
        "agent tab is no longer created blank - revisit this guard"
    )
    assert "tab.pendingUrl" in background, (
        "tabIsUsable must tolerate a tab whose navigation is still pending"
    )
    print("agent tab creation and the usability check agree on about:blank")

    print("\nBLANK TAB GUARD PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
