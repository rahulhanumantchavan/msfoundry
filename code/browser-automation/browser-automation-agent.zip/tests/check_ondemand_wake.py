"""On-demand wake: the extension stays dormant until the agent needs it.

Simulates the full chain without Chrome:

    UI relay (SSE)  ->  wake signal  ->  extension connects  ->  command runs

Also covers the failure mode that matters most: a task started with no relay
and no extension must fail fast with an actionable message instead of hanging.

Run with the server up:  python run_server.py
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

import httpx
import websockets

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

BASE = "http://127.0.0.1:8000"
WS = "ws://127.0.0.1:8000/ws/extension"


async def fake_extension(session_id: str, pairing_code: str, ready: asyncio.Event,
                         log: list[str]) -> None:
    """Stand in for the service worker: connect, answer one command, leave."""
    async with websockets.connect(WS) as ws:
        await ws.send(json.dumps({
            "type": "hello",
            "pairing_code": pairing_code,
            "session_id": session_id,
            "extension_version": "test",
        }))
        welcome = json.loads(await ws.recv())
        assert welcome["type"] == "welcome", welcome
        log.append("extension connected")
        ready.set()

        frame = json.loads(await asyncio.wait_for(ws.recv(), timeout=20))
        assert frame["type"] == "command", frame
        log.append(f"command received: {frame['action']}")
        await ws.send(json.dumps({
            "type": "result",
            "id": frame["id"],
            "ok": True,
            "data": {"tabId": 4242, "url": "about:blank", "title": "Agent tab"},
        }))
        await asyncio.sleep(0.4)


async def relay(session_id: str, woken: asyncio.Event, log: list[str]) -> None:
    """Stand in for the UI tab's content script."""
    url = f"{BASE}/api/sessions/{session_id}/relay"
    async with httpx.AsyncClient(timeout=None) as client:
        async with client.stream("GET", url) as response:
            assert response.status_code == 200, response.status_code
            async for line in response.aiter_lines():
                if not line.startswith("data: "):
                    continue
                frame = json.loads(line[6:])
                if frame["signal"] == "config":
                    log.append("relay configured")
                elif frame["signal"] == "wake":
                    log.append("wake signal received")
                    woken.set()
                    return


async def wait_dormant(client: httpx.AsyncClient, session_id: str) -> dict:
    """Poll until the extension socket is really gone (close is async)."""
    status: dict = {}
    for _ in range(20):
        status = (await client.get(f"/api/sessions/{session_id}")).json()
        if not status["extension_connected"]:
            return status
        await asyncio.sleep(0.25)
    return status


async def check_default_session_is_stable() -> str:
    """The UI and the extension must land on the same session every time."""
    async with httpx.AsyncClient(base_url=BASE, timeout=20.0) as client:
        first = (await client.get("/api/session/default")).json()
        second = (await client.get("/api/session/default")).json()
    assert first["session_id"] == second["session_id"], (first, second)
    assert first["pairing_code"] == second["pairing_code"], (first, second)
    print(f"default session is stable: {first['session_id']}")
    return first["session_id"]


async def main() -> int:
    log: list[str] = []

    await check_default_session_is_stable()

    async with httpx.AsyncClient(base_url=BASE, timeout=40.0) as client:
        pairing = (await client.post("/api/pairing")).json()
        session_id = pairing["session_id"]
        code = pairing["pairing_code"]
        print(f"session {session_id}")

        # --- 1. no relay, no extension -> fail fast ----------------------
        response = await client.post(
            "/api/task/start",
            json={"session_id": session_id, "prompt": "do something"},
        )
        assert response.status_code == 409, response.status_code
        assert "Chrome" in response.json()["detail"]
        print("no-relay guard -> rejected with a clear message")

        status = (await client.get(f"/api/sessions/{session_id}")).json()
        assert status["relay_connected"] is False
        assert status["extension_connected"] is False
        print("dormant: relay=False extension=False")

        # --- 2. relay attaches, extension still dormant ------------------
        woken = asyncio.Event()
        relay_task = asyncio.create_task(relay(session_id, woken, log))
        await asyncio.sleep(1.0)

        status = (await client.get(f"/api/sessions/{session_id}")).json()
        assert status["relay_connected"] is True, status
        assert status["extension_connected"] is False, status
        print("relay attached, extension still asleep (zero idle footprint)")

        # --- 3. a browser action wakes the extension ---------------------
        ready = asyncio.Event()
        ext_log: list[str] = []

        async def wake_watcher() -> None:
            await woken.wait()
            # The real content script does chrome.runtime.sendMessage here.
            await fake_extension(session_id, code, ready, ext_log)

        ext_task = asyncio.create_task(wake_watcher())

        tab = await client.post(
            f"/api/sessions/{session_id}/tab", params={"action": "open"}
        )
        assert tab.status_code == 200, (tab.status_code, tab.text)
        assert tab.json()["agent_tab_id"] == 4242, tab.json()
        print("agent tab opened on demand ->", tab.json()["agent_tab_id"])

        await asyncio.wait_for(ext_task, timeout=20)
        relay_task.cancel()

        log.extend(ext_log)
        print("sequence:", " -> ".join(log))
        assert "wake signal received" in log
        assert "extension connected" in log

        status = (await client.get(f"/api/sessions/{session_id}")).json()
        assert status["agent_tab_id"] == 4242, status
        print("agent tab id persisted in session status")

    await check_rewake_cycles()
    print("\nON-DEMAND WAKE TESTS PASSED")
    return 0


async def check_rewake_cycles(cycles: int = 3) -> None:
    """Release must leave the session wakeable, not permanently stale.

    Regression guard: an early build latched the socket into a 'rejected'
    state after one release, so the agent could never reach Chrome again.
    """
    print(f"\n-- {cycles} wake/release cycles on the default session --")
    async with httpx.AsyncClient(base_url=BASE, timeout=40.0) as client:
        default = (await client.get("/api/session/default")).json()
        sid, code = default["session_id"], default["pairing_code"]

        wakes: asyncio.Queue[dict] = asyncio.Queue()

        async def pump() -> None:
            async with httpx.AsyncClient(timeout=None) as stream_client:
                url = f"{BASE}/api/sessions/{sid}/relay"
                async with stream_client.stream("GET", url) as response:
                    async for line in response.aiter_lines():
                        if line.startswith("data: "):
                            frame = json.loads(line[6:])
                            if frame["signal"] == "wake":
                                wakes.put_nowait(frame)

        relay_task = asyncio.create_task(pump())
        await asyncio.sleep(1.0)

        # A leftover extension would make ensure_extension() short-circuit and
        # send no wake, so start from a genuinely dormant session.
        if (await client.get(f"/api/sessions/{sid}")).json()["extension_connected"]:
            await client.post(f"/api/sessions/{sid}/disconnect")
            await wait_dormant(client, sid)
            print("  (cleared a leftover extension first)")

        async def extension(label: str) -> None:
            async with websockets.connect(WS) as ws:
                await ws.send(json.dumps({
                    "type": "hello", "pairing_code": code, "session_id": sid,
                }))
                assert json.loads(await ws.recv())["type"] == "welcome"
                try:
                    frame = json.loads(await asyncio.wait_for(ws.recv(), timeout=8))
                    if frame.get("signal") == "release":
                        print(f"  [{label}] release received -> dormant")
                except TimeoutError:
                    pass

        try:
            for cycle in range(1, cycles + 1):
                connect = asyncio.create_task(client.post(f"/api/sessions/{sid}/connect"))
                await asyncio.wait_for(wakes.get(), timeout=10)
                ext = asyncio.create_task(extension(f"cycle{cycle}"))
                response = await connect
                assert response.status_code == 200, response.text

                await client.post(f"/api/sessions/{sid}/disconnect")
                await asyncio.wait_for(ext, timeout=12)

                status = await wait_dormant(client, sid)
                assert not status["extension_connected"], status
                assert status["relay_connected"], status
                print(f"  cycle {cycle}: woke, worked, released, still wakeable")
        finally:
            relay_task.cancel()


if __name__ == "__main__":
    try:
        raise SystemExit(asyncio.run(main()))
    except AssertionError as exc:
        print(f"\nFAILED: {exc}")
        raise SystemExit(1) from exc
