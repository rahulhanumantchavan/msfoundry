"""Integration check: pairing, RPC bridge, screenshot fan-out and UI stream.

Simulates the Chrome extension with a plain WebSocket client so the whole
server path can be validated without a real browser.

The FastAPI app is started *in this process* so the test can reach the same
SessionManager singleton the WebSocket handlers use.

    python tests/test_bridge.py
"""

from __future__ import annotations

import asyncio
import base64
import json
import sys
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import cv2
import numpy as np
import requests
import uvicorn
import websockets

PORT = 8765
BASE = f"http://127.0.0.1:{PORT}"
WS = f"ws://127.0.0.1:{PORT}"


class ServerThread:
    """Runs uvicorn in a background thread sharing this process's modules."""

    def __init__(self) -> None:
        from server.api.app import app

        config = uvicorn.Config(
            app, host="127.0.0.1", port=PORT, log_level="warning", loop="asyncio"
        )
        self.server = uvicorn.Server(config)
        self.thread = threading.Thread(target=self.server.run, daemon=True)

    def start(self) -> None:
        self.thread.start()
        for _ in range(100):
            try:
                requests.get(f"{BASE}/health", timeout=1)
                return
            except requests.RequestException:
                threading.Event().wait(0.1)
        raise RuntimeError("server did not start")

    def stop(self) -> None:
        self.server.should_exit = True
        self.thread.join(timeout=5)


def make_screenshot(w: int = 2560, h: int = 1600) -> str:
    img = np.full((h, w, 3), 245, np.uint8)
    cv2.rectangle(img, (600, 400), (1960, 560), (255, 255, 255), -1)
    cv2.rectangle(img, (600, 400), (1960, 560), (180, 180, 180), 3)
    cv2.putText(img, "Search", (640, 505), cv2.FONT_HERSHEY_SIMPLEX, 2, (90, 90, 90), 3)
    ok, buf = cv2.imencode(".png", img)
    assert ok
    return base64.b64encode(buf.tobytes()).decode()


async def fake_extension(code: str, received: list[dict]) -> None:
    """Minimal extension stand-in that answers every command."""
    async with websockets.connect(f"{WS}/ws/extension") as ws:
        await ws.send(
            json.dumps(
                {
                    "type": "hello",
                    "pairing_code": code,
                    "extension_version": "1.0.0-test",
                    "capabilities": ["navigate", "click", "screenshot"],
                }
            )
        )
        welcome = json.loads(await ws.recv())
        assert welcome["type"] == "welcome", welcome
        print(f"  extension paired -> session {welcome['session_id']}")

        shot = make_screenshot()
        while True:
            frame = json.loads(await ws.recv())
            if frame.get("type") != "command":
                continue
            received.append(frame)
            action = frame["action"]
            if action == "screenshot":
                data = {
                    "image": shot,
                    "url": "https://example.com/",
                    "title": "Example Domain",
                    "device_pixel_ratio": 2.0,
                    "viewport": {"width": 1280, "height": 800},
                }
            elif action == "navigate":
                data = {"url": frame["params"]["url"], "message": "loaded"}
            elif action == "click":
                data = {"message": f"clicked {frame['params']}"}
            else:
                data = {"message": f"{action} ok"}
            await ws.send(
                json.dumps(
                    {"type": "result", "id": frame["id"], "ok": True, "data": data}
                )
            )


async def ui_listener(session_id: str, events: list[dict], stop: asyncio.Event) -> None:
    async with websockets.connect(f"{WS}/ws/ui/{session_id}") as ws:
        while not stop.is_set():
            try:
                frame = json.loads(await asyncio.wait_for(ws.recv(), timeout=0.5))
            except TimeoutError:
                continue
            events.append(frame)


async def main() -> int:
    health = requests.get(f"{BASE}/health", timeout=10).json()
    print("health:", health)

    pairing = requests.post(f"{BASE}/api/pairing", timeout=10).json()
    code, session_id = pairing["pairing_code"], pairing["session_id"]
    print(f"pairing code {code} / session {session_id}")

    commands: list[dict] = []
    ui_events: list[dict] = []
    stop = asyncio.Event()

    ext = asyncio.create_task(fake_extension(code, commands))
    ui = asyncio.create_task(ui_listener(session_id, ui_events, stop))
    await asyncio.sleep(1.0)

    status = requests.get(f"{BASE}/api/sessions/{session_id}", timeout=10).json()
    print("extension_connected:", status["extension_connected"])
    assert status["extension_connected"], "extension failed to pair"

    # Drive the bridge directly (no LLM needed) to prove RPC + vision work.
    from server.agent.browser_tools import BrowserToolkit
    from server.config import get_settings
    from server.sessions import get_session_manager
    from server.vision import VisionPipeline

    session = get_session_manager().get(session_id)
    assert session is not None
    toolkit = BrowserToolkit(session, get_settings(), VisionPipeline())

    print("navigate ->", await toolkit.navigate("example.com"))
    print("click    ->", await toolkit.click(x=640, y=240))
    print("shot     ->", await toolkit.screenshot())

    assert toolkit.latest is not None, "no screenshot cached"
    shot = toolkit.latest
    print(
        f"  processed {shot.raw_width}x{shot.raw_height} -> "
        f"{shot.width}x{shot.height} scale={shot.scale} "
        f"css={shot.css_width}x{shot.css_height}"
    )

    # A model point on a 1280-wide image of a 2x-DPR 1280css viewport must map
    # back to the same CSS coordinate.
    assert shot.to_css_point(640, 240) == (640, 240), shot.to_css_point(640, 240)

    # Scheme guard: javascript:/data: must never be wrapped into https://.
    for hostile in ("javascript:alert(1)", "data:text/html,<h1>x", "chrome://settings"):
        bad = await toolkit.navigate(hostile)
        assert bad.startswith("ERROR"), f"{hostile} was not blocked: {bad}"
    print("scheme guard -> blocked javascript:, data:, chrome:")

    # Scheme-less input must still work.
    assert BrowserToolkit.normalize_url("example.com") == "https://example.com"
    assert BrowserToolkit.normalize_url("http://a.io") == "http://a.io"

    # Domain blocklist.
    blocked_settings = get_settings().model_copy(update={"blocked_domains": "evil.com"})
    guarded = BrowserToolkit(session, blocked_settings, VisionPipeline())
    denied = await guarded.navigate("https://sub.evil.com/x")
    assert denied.startswith("ERROR"), denied
    print("domain guard ->", denied)

    await asyncio.sleep(0.8)
    stop.set()
    await asyncio.sleep(0.3)
    ext.cancel()
    ui.cancel()

    actions = [c["action"] for c in commands]
    kinds = [e.get("event") for e in ui_events]
    print("commands received by extension:", actions)
    print("ui events:", kinds)

    assert "navigate" in actions and "click" in actions and "screenshot" in actions
    assert "screenshot" in kinds, "UI never received a screenshot frame"

    shots = [e for e in ui_events if e.get("event") == "screenshot"]
    assert shots[-1]["payload"]["image"].startswith("data:image/jpeg;base64,")
    print(f"UI screenshot payload bytes: {len(shots[-1]['payload']['image'])}")

    print("\nALL BRIDGE TESTS PASSED")
    return 0


if __name__ == "__main__":
    server = ServerThread()
    server.start()
    try:
        code = asyncio.run(main())
    finally:
        server.stop()
    raise SystemExit(code)
