"""Verify the generated tool schemas are valid for LLM function calling."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from server.agent.browser_tools import BrowserToolkit
from server.config import get_settings
from server.sessions.session import Session
from server.vision import VisionPipeline

toolkit = BrowserToolkit(Session("s", "c"), get_settings(), VisionPipeline())
tools = toolkit.build_tools()

problems: list[str] = []
for tool in tools:
    schema = tool.args_schema
    if hasattr(schema, "model_json_schema"):
        schema = schema.model_json_schema()
    props = list((schema or {}).get("properties", {}))
    required = (schema or {}).get("required", [])
    if not tool.description:
        problems.append(f"{tool.name}: missing description")
    # Every tool must expose a schema the model can fill in.
    if schema is None:
        problems.append(f"{tool.name}: no args schema")
    if tool.name in ("click", "type_text", "scroll", "ask_user", "navigate"):
        print(f"{tool.name:14} args={props} required={required}")

print()
print(f"total tools: {len(tools)}")
print(f"all have coroutines: {all(t.coroutine is not None for t in tools)}")

# Pure-vision mode must hide the accessibility tree.
from server.agent.runner import AgentRunner  # noqa: E402

runner = AgentRunner(get_settings())
vision_names = {t.name for t in runner.toolkit_for(Session("v", "c"), "vision").build_tools()}
print(f"vision-mode tool count (pre-filter): {len(vision_names)}")

if problems:
    print("\nPROBLEMS:")
    for p in problems:
        print(" -", p)
    raise SystemExit(1)
print("\nSCHEMA CHECK PASSED")
