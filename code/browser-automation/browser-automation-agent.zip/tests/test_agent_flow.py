"""End-to-end agent test using a scripted fake LLM (no Azure calls).

Verifies that the LangGraph/DeepAgents wiring, the browser toolkit, the
screenshot middleware and the UI event stream all cooperate for a realistic
multi-step task.
"""

from __future__ import annotations

import asyncio
import base64
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import cv2
import numpy as np
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage
from langchain_core.outputs import ChatGeneration, ChatResult

from server.agent.runner import AgentRunner
from server.config import get_settings
from server.protocol import BrowserAction, SessionStatus
from server.sessions.session import Session


def screenshot_b64(w: int = 1600, h: int = 1000) -> str:
    img = np.full((h, w, 3), 250, np.uint8)
    cv2.rectangle(img, (400, 300), (1200, 360), (255, 255, 255), -1)
    cv2.rectangle(img, (400, 300), (1200, 360), (170, 170, 170), 2)
    cv2.putText(img, "Search...", (420, 342), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (120, 120, 120), 2)
    ok, buf = cv2.imencode(".png", img)
    assert ok
    return base64.b64encode(buf.tobytes()).decode()


class FakeSession(Session):
    """Session whose RPC layer answers locally instead of over a socket."""

    def __init__(self) -> None:
        super().__init__("test-session", "TEST01")
        self.calls: list[tuple[str, dict[str, Any]]] = []
        self._shot = screenshot_b64()

    @property
    def extension_connected(self) -> bool:  # type: ignore[override]
        return True

    async def call(self, action, params=None, *, timeout=45.0):  # type: ignore[override]
        name = action.value if isinstance(action, BrowserAction) else str(action)
        self.calls.append((name, params or {}))
        if self.stop_requested:
            from server.sessions.session import BrowserBridgeError

            raise BrowserBridgeError("task stopped by user")
        if name == "screenshot":
            return {
                "image": self._shot,
                "url": "https://example.com/search",
                "title": "Example Search",
                "device_pixel_ratio": 1.0,
                "viewport": {"width": 1600, "height": 1000},
            }
        if name == "get_tree":
            return {
                "url": "https://example.com/search",
                "title": "Example Search",
                "nodes": [
                    {
                        "role": "searchbox",
                        "name": "Search",
                        "tag": "input",
                        "selector": "#q",
                        "rect": {"x": 400, "y": 300, "w": 800, "h": 60, "cx": 800, "cy": 330},
                    }
                ],
            }
        return {"message": f"{name} ok", "url": "https://example.com/search"}

    async def send_control(self, signal, payload=None):  # type: ignore[override]
        return None


class ScriptedModel(BaseChatModel):
    """A real BaseChatModel that replays a fixed sequence of turns.

    DeepAgents resolves anything that is not a BaseChatModel as a provider
    string, so the fake must inherit from the base class rather than merely
    duck-type ``ainvoke``.
    """

    script: list[AIMessage] = []
    state: dict = {}

    @property
    def _llm_type(self) -> str:
        return "scripted-test-model"

    def bind_tools(self, tools, **kwargs):  # noqa: ANN001, ANN003
        return self

    def _next(self, messages) -> ChatResult:  # noqa: ANN001
        # Confirm the screenshot middleware really attached an image block.
        for message in messages:
            content = getattr(message, "content", None)
            if isinstance(content, list) and any(
                isinstance(b, dict) and b.get("type") == "image_url" for b in content
            ):
                self.state["saw_image"] = True
        index = self.state.get("index", 0)
        message = self.script[min(index, len(self.script) - 1)]
        self.state["index"] = index + 1
        # Each turn must be a distinct object: LangGraph assigns message ids.
        return ChatResult(generations=[ChatGeneration(message=message.model_copy())])

    def _generate(self, messages, stop=None, run_manager=None, **kwargs) -> ChatResult:  # noqa: ANN001, ANN003
        return self._next(messages)

    async def _agenerate(self, messages, stop=None, run_manager=None, **kwargs) -> ChatResult:  # noqa: ANN001, ANN003
        return self._next(messages)


async def main() -> int:
    settings = get_settings()
    session = FakeSession()

    script = [
        AIMessage(
            content="I'll open the site first.",
            tool_calls=[
                {"name": "navigate", "args": {"url": "example.com"}, "id": "c1"}
            ],
        ),
        AIMessage(
            content="Now I'll inspect the page structure.",
            tool_calls=[{"name": "get_tree", "args": {}, "id": "c2"}],
        ),
        AIMessage(
            content="Typing the query into the search box.",
            tool_calls=[
                {
                    "name": "type_text",
                    "args": {"text": "browser agent", "selector": "#q", "press_enter": True},
                    "id": "c3",
                }
            ],
        ),
        AIMessage(content="Done - I searched for 'browser agent' on example.com."),
    ]
    model = ScriptedModel(script=script, state={"index": 0, "saw_image": False})

    runner = AgentRunner(settings)
    # Inject the scripted model in place of Azure OpenAI.
    import server.agent.runner as runner_module

    original = runner_module.build_llm
    runner_module.build_llm = lambda _s: model  # type: ignore[assignment]
    try:
        await runner.run_task(session, "search for browser agent", vision_mode="hybrid")
    finally:
        runner_module.build_llm = original

    actions = [c[0] for c in session.calls]
    print("browser calls:", actions)
    print("model turns:", model.state["index"])
    print("image attached to model context:", model.state["saw_image"])
    print("final status:", session.status.value)

    events = [e.get("event") for e in session.event_log]
    print("ui events:", events)

    assert "navigate" in actions, "navigate was never dispatched"
    assert "get_tree" in actions, "get_tree was never dispatched"
    assert "type" in actions, "type was never dispatched"
    assert model.state["saw_image"], "screenshot middleware did not attach an image"
    assert session.status is SessionStatus.DONE, session.status
    assert "tool_call" in events and "screenshot" in events

    final = [
        e for e in session.event_log
        if e.get("event") == "agent_message"
        and e["payload"].get("role") == "assistant"
    ]
    assert final, "no final assistant message was broadcast"
    print("final message:", final[-1]["payload"]["content"][:80])

    # --- stop control ----------------------------------------------------
    session2 = FakeSession()
    await session2.stop()
    from server.agent.browser_tools import BrowserToolkit
    from server.vision import VisionPipeline

    toolkit = BrowserToolkit(session2, settings, VisionPipeline())
    stopped = await toolkit.navigate("example.com")
    assert stopped.startswith("ERROR"), stopped
    print("stop guard ->", stopped)

    print("\nALL AGENT FLOW TESTS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
