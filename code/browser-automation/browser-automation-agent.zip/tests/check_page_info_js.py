"""Verify the injected getPageInfo() script is valid JavaScript.

Reproduces the real failure seen on Gmail:
``get_page_info -> ERROR: SyntaxError: Invalid regular expression: missing /``

The expression is built inside a template literal, so the escaping must
survive one round of JS string interpolation before the page evaluates it.
"""

from __future__ import annotations

import re
import subprocess
import sys
import tempfile
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parent.parent
AUTOMATION = ROOT / "extension" / "lib" / "automation.js"

source = AUTOMATION.read_text(encoding="utf-8-sig")

# Extract the template literal passed to this.evaluate() inside getPageInfo.
match = re.search(
    r"async getPageInfo\(\)\s*\{.*?return this\.evaluate\(`(.*?)`\);",
    source,
    re.S,
)
if not match:
    print("could not locate getPageInfo's injected script")
    raise SystemExit(1)

raw = match.group(1)
print("extracted injected script:")
print("  " + raw.strip().splitlines()[0][:80] + " ...")

# Simulate what JS does to a template literal: resolve the escape sequences.
# Doubled backslashes collapse to one, which is what the page must receive.
page_script = raw.encode("utf-8").decode("unicode_escape")

with tempfile.NamedTemporaryFile(
    "w", suffix=".js", delete=False, encoding="utf-8"
) as handle:
    # Wrap in a function so `return` is legal and nothing executes.
    handle.write(f"function __probe() {{ return {page_script} }}\n")
    temp_path = handle.name

try:
    result = subprocess.run(
        ["node", "--check", temp_path], capture_output=True, text=True
    )
    if result.returncode != 0:
        print("\nINVALID JAVASCRIPT after interpolation:")
        print(result.stderr[:900])
        raise SystemExit(1)
    print("\ninjected script parses as valid JavaScript")
finally:
    Path(temp_path).unlink(missing_ok=True)

# The regex must still be a regex, not a literal newline.
if "/\\n{3,}/g" not in page_script and "/\n{3,}/g" in page_script:
    print("regex contains a raw newline - escaping is still wrong")
    raise SystemExit(1)

print("PAGE INFO JS CHECK PASSED")
