"""Entry point for the FastAPI server.

    python run_server.py [--host 0.0.0.0] [--port 8000] [--reload]
"""

from __future__ import annotations

import argparse
from pathlib import Path

import uvicorn

from server.config import get_settings


def main() -> None:
    settings = get_settings()
    parser = argparse.ArgumentParser(description="AI Browser Agent server")
    parser.add_argument("--host", default=settings.server_host)
    parser.add_argument("--port", type=int, default=settings.server_port)
    parser.add_argument("--reload", action="store_true", help="auto-reload on edits")
    parser.add_argument("--log-level", default="info")
    args = parser.parse_args()

    if settings.azure_configured:
        mode = "v1 (OpenAI-compatible)" if settings.uses_v1_endpoint else "classic"
        print(f"Azure OpenAI: {settings.azure_openai_endpoint}")
        print(f"  deployment: {settings.azure_openai_deployment}  [{mode}]\n")
    else:
        missing = []
        if not settings.azure_openai_endpoint:
            missing.append("AZURE_OPENAI_ENDPOINT")
        if not settings.azure_openai_api_key:
            missing.append("AZURE_OPENAI_API_KEY")
        print(
            "WARNING: Azure OpenAI is not configured - the bridge and UI will\n"
            "         run, but starting a task will fail.\n"
            f"         Missing in .env: {', '.join(missing)}\n"
            f"         Edit: {Path(__file__).resolve().parent / '.env'}\n"
        )

    print(f"AI Browser Agent server -> http://{args.host}:{args.port}")
    print(f"  extension WebSocket:  ws://{args.host}:{args.port}/ws/extension")
    print(f"  UI WebSocket:         ws://{args.host}:{args.port}/ws/ui/<session_id>\n")

    uvicorn.run(
        "server.api.app:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        log_level=args.log_level,
    )


if __name__ == "__main__":
    main()
