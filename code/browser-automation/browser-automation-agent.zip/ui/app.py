"""Streamlit control surface for the AI Browser Agent.

Layout
------
* Sidebar  - server connection, pairing code, vision mode, session controls.
* Left     - chat transcript (user prompts, agent reasoning, tool calls).
* Right    - live screenshot of the controlled tab with the current status.

The UI polls ``/api/sessions/{id}/events`` with a cursor and replays the same
frames the server broadcasts on the UI WebSocket, so it stays in sync without
owning a socket across Streamlit reruns.
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

import streamlit as st
import streamlit.components.v1 as components

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from ui.client import ServerClient  # noqa: E402

DEFAULT_SERVER = os.getenv("SERVER_PUBLIC_URL", "http://127.0.0.1:8000")
POLL_SECONDS = 1.0

st.set_page_config(
    page_title="AI Browser Agent",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

STYLE = """
<style>
  .block-container { padding-top: 2.2rem; padding-bottom: 3rem; }
  .pair-code {
    font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
    font-size: 2rem; font-weight: 700; letter-spacing: .35rem;
    text-align: center; padding: .6rem; border-radius: .6rem;
    background: rgba(37, 99, 235, .12); color: #2563eb;
    border: 1px solid rgba(37, 99, 235, .35);
  }
  .status-chip {
    display: inline-block; padding: .22rem .7rem; border-radius: 999px;
    font-size: .76rem; font-weight: 600;
  }
  .s-running { background: rgba(22,163,74,.16); color: #16a34a; }
  .s-idle    { background: rgba(100,116,139,.18); color: #64748b; }
  .s-paused  { background: rgba(245,158,11,.18); color: #d97706; }
  .s-error   { background: rgba(220,38,38,.16); color: #dc2626; }
  .s-done    { background: rgba(37,99,235,.16); color: #2563eb; }
  .s-awaiting_human { background: rgba(168,85,247,.16); color: #a855f7; }
  .tool-call {
    font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
    font-size: .78rem; background: rgba(148,163,184,.12);
    border-left: 3px solid #2563eb; padding: .45rem .7rem;
    border-radius: .3rem; margin: .25rem 0; white-space: pre-wrap;
    word-break: break-word;
  }
  .tool-err { border-left-color: #dc2626; }
  .shot-meta { font-size: .76rem; color: #64748b; word-break: break-all; }
</style>
"""
st.markdown(STYLE, unsafe_allow_html=True)


# --------------------------------------------------------------------------- #
# State
# --------------------------------------------------------------------------- #
def init_state() -> None:
    defaults = {
        "server_url": DEFAULT_SERVER,
        "session_id": None,
        "pairing_code": None,
        "cursor": 0,
        "messages": [],       # chat transcript
        "activity": [],       # tool calls / results
        "screenshot": None,   # latest data URL
        "shot_meta": {},
        "status": {},
        "pending_question": None,
        "vision_mode": "hybrid",
        "max_steps": 40,
        "last_error": None,
    }
    for key, value in defaults.items():
        st.session_state.setdefault(key, value)


init_state()
client = ServerClient(st.session_state.server_url)

_SECRET_HINTS = (
    "password", "passcode", "otp", "2fa", "mfa", "code", "pin",
    "secret", "token", "cvv", "credential",
)


def _looks_secret(question: str) -> bool:
    """Mask the answer field when the agent is asking for something sensitive."""
    lowered = (question or "").lower()
    return any(hint in lowered for hint in _SECRET_HINTS)


def ensure_session() -> None:
    """Make sure a session exists before the page renders.

    There is no pairing step any more: the UI owns the session and the
    extension is woken on demand, so the session must exist from the first
    paint. A live extension on an older session is adopted rather than
    stranded (a page refresh resets Streamlit but not the extension socket).
    """
    if st.session_state.session_id:
        return
    try:
        # An extension that is already attached wins: it may have been woken
        # against an earlier session, and stranding it would leave the agent
        # with no browser.
        for live in client.connected_sessions():
            st.session_state.session_id = live["session_id"]
            st.session_state.pairing_code = live.get("pairing_code") or ""
            st.session_state.cursor = 0
            return
    except Exception:  # noqa: BLE001 - adoption is best-effort
        pass
    try:
        # Otherwise use the single well-known session, so reloading the page or
        # opening a second tab reuses it instead of creating an orphan.
        default = client.default_session()
        st.session_state.session_id = default["session_id"]
        st.session_state.pairing_code = default["pairing_code"]
        st.session_state.cursor = 0
    except Exception as exc:  # noqa: BLE001 - shown to the operator
        st.session_state.last_error = f"Could not reach the server: {exc}"


def _render_hidden_html(html: str) -> None:
    """Run a snippet of HTML/JS in an invisible component iframe.

    ``st.components.v1.html`` is deprecated in favour of ``st.iframe``, but the
    two disagree about zero heights: the old API accepts 0, the new one rejects
    it and wants a positive value (or "content").
    """
    renderer = getattr(st, "iframe", None)
    if renderer is not None:
        renderer(html, height=1)
    else:
        components.html(html, height=0)


def announce_to_extension() -> None:
    """Tell the extension's relay content script which session to serve.

    The component runs in an iframe, so it posts the details to the top frame
    where the content script listens. This is what lets the server wake a
    dormant service worker on demand.
    """
    session_id = st.session_state.session_id
    if not session_id:
        return
    _render_hidden_html(
        f"""
        <script>
          const detail = {{
            __browserAgent: true,
            sessionId: {json.dumps(session_id)},
            serverUrl: {json.dumps(st.session_state.server_url)}
          }};
          // Re-announce on every rerun; the relay ignores duplicates.
          window.parent.postMessage(detail, '*');
          window.top.postMessage(detail, '*');
        </script>
        """
    )


def refresh_status() -> None:
    """Fetch authoritative session status directly.

    The event log only carries *changes*, so a freshly adopted session would
    otherwise render as "waiting" until the next broadcast. Polling the status
    endpoint makes the first paint correct.
    """
    session_id = st.session_state.session_id
    if not session_id:
        return
    try:
        st.session_state.status = client.session_status(session_id)
    except RuntimeError:
        pass


def ingest_events() -> bool:
    """Pull new frames from the server and fold them into session state.

    Returns ``True`` when anything was consumed, so the caller knows whether
    the page needs to re-render.
    """
    session_id = st.session_state.session_id
    if not session_id:
        return False
    try:
        batch = client.events(session_id, st.session_state.cursor)
    except RuntimeError as exc:
        st.session_state.last_error = str(exc)
        return False

    st.session_state.cursor = batch.get("cursor", st.session_state.cursor)
    events = batch.get("events", [])
    for frame in events:
        event = frame.get("event")
        payload = frame.get("payload") or {}

        if event == "screenshot":
            # Superseded frames are blanked server-side to save memory; keep
            # showing the newest real image rather than clearing the view.
            image = payload.get("image")
            if image:
                st.session_state.screenshot = image
                st.session_state.shot_meta = {
                    "url": payload.get("url"),
                    "title": payload.get("title"),
                    "annotated": payload.get("annotated"),
                }
        elif event == "agent_message":
            st.session_state.messages.append(
                {"role": payload.get("role", "assistant"), "content": payload.get("content", "")}
            )
        elif event == "agent_thinking":
            st.session_state.activity.append(
                {"kind": "thinking", "text": payload.get("content", "")}
            )
        elif event == "tool_call":
            st.session_state.activity.append(
                {"kind": "call", "tool": payload.get("tool"), "args": payload.get("args", {})}
            )
        elif event == "tool_result":
            st.session_state.activity.append(
                {
                    "kind": "result",
                    "tool": payload.get("tool"),
                    "text": payload.get("result", ""),
                    "ok": payload.get("ok", True),
                }
            )
        elif event == "status":
            # Merge rather than replace: refresh_status() may already hold a
            # newer snapshot than this replayed log frame.
            st.session_state.status = {**st.session_state.status, **payload}
            st.session_state.pending_question = payload.get("pending_question")
        elif event == "error":
            # Keep errors in the transcript so history stays honest, but do not
            # latch them into the banner - the banner reflects the server's
            # *current* state (see sync_error below).
            st.session_state.activity.append(
                {"kind": "result", "tool": "error", "text": payload.get("message", ""), "ok": False}
            )
        elif event == "human_input_request":
            st.session_state.pending_question = payload.get("question")

    return bool(events)


def sync_error() -> None:
    """Make the error banner mirror the server's authoritative state.

    The event log is replayed on every load, so an error from an earlier run
    would otherwise stick to the banner forever - even after the underlying
    problem was fixed and later runs succeeded.
    """
    st.session_state.last_error = (st.session_state.status or {}).get("last_error")

# --------------------------------------------------------------------------- #
# Sidebar: connection, pairing and controls
# --------------------------------------------------------------------------- #
# A session must exist before anything renders: the extension is woken on
# demand against this id, so there is no explicit pairing step.
ensure_session()
# The relay announcement must run on every rerun so the content script keeps
# its stream alive across Streamlit's page rebuilds.
announce_to_extension()
# Pull authoritative status before anything renders, so the sidebar and the
# main view agree on whether the extension is attached.
refresh_status()

with st.sidebar:
    st.markdown("### ◆ AI Browser Agent")

    server_url = st.text_input(
        "Server URL", value=st.session_state.server_url, help="FastAPI base URL"
    )
    if server_url != st.session_state.server_url:
        st.session_state.server_url = server_url
        client = ServerClient(server_url)

    # --- server health ---------------------------------------------------
    try:
        health = client.health()
        azure_ok = health.get("azure_configured")
        st.success(f"Server online · {health.get('sessions', 0)} session(s)")
        if azure_ok:
            st.caption(
                f"Azure deployment `{health.get('deployment')}` "
                f"· {health.get('api_mode', 'auto')} endpoint"
            )
        elif not health.get("api_key_set"):
            st.error(
                "**Azure API key missing.** Add `AZURE_OPENAI_API_KEY=<your-key>` "
                "to the `.env` file in the project root, then restart the server."
            )
        elif not health.get("endpoint_set"):
            st.error("**Azure endpoint missing.** Set `AZURE_OPENAI_ENDPOINT` in `.env`.")
        else:
            st.error("Azure OpenAI is not configured - set it in `.env`.")
    except RuntimeError as exc:
        st.error(f"Server unreachable: {exc}")
    except Exception:
        st.error("Server unreachable - is `run_server.py` running?")

    st.divider()

    # --- browser ---------------------------------------------------------
    st.markdown("#### Browser")
    status = st.session_state.status
    relay_ok = bool(status.get("relay_connected"))
    ext_ok = bool(status.get("extension_connected"))

    if ext_ok:
        st.success("Browser connected · agent in control")
    elif relay_ok:
        st.info("Chrome detected · idle until the agent needs it")
    else:
        st.warning("Chrome extension not detected in this browser.")
        st.caption(
            "Open this page in the Chrome window where the **AI Browser "
            "Agent** extension is installed, then reload."
        )

    tab_id = status.get("agent_tab_id")
    st.caption(
        f"Agent tab `#{tab_id}`" if tab_id is not None else "No agent tab open yet"
    )

    col_a, col_b = st.columns(2)
    with col_a:
        if st.button(
            "Open tab", width='stretch', disabled=not relay_ok and not ext_ok,
            help="Open (or focus) the dedicated tab the agent works in.",
        ):
            try:
                client.agent_tab(st.session_state.session_id, "open")
                st.rerun()
            except Exception as exc:  # noqa: BLE001 - surfaced to the operator
                st.error(str(exc))
    with col_b:
        if st.button(
            "Release", width='stretch', disabled=not ext_ok,
            help="Hand the browser back and let the extension go idle.",
        ):
            try:
                client.disconnect_extension(st.session_state.session_id)
                st.rerun()
            except Exception as exc:  # noqa: BLE001
                st.error(str(exc))

    with st.expander("Session details"):
        st.caption(f"Session `{st.session_state.session_id}`")
        if st.session_state.pairing_code:
            st.caption(f"Pairing code `{st.session_state.pairing_code}`")
        if st.button("New session", width='stretch'):
            for key in ("session_id", "pairing_code", "screenshot", "pending_question"):
                st.session_state[key] = None
            st.session_state.update(
                cursor=0, messages=[], activity=[], status={}, shot_meta={}
            )
            st.rerun()

    st.divider()

    # --- agent settings --------------------------------------------------
    st.markdown("#### Agent settings")
    st.session_state.vision_mode = st.radio(
        "Vision mode",
        options=["hybrid", "vision"],
        index=0 if st.session_state.vision_mode == "hybrid" else 1,
        help=(
            "hybrid = screenshot + accessibility tree (recommended). "
            "vision = screenshot only, click purely by coordinates."
        ),
        horizontal=True,
    )
    st.session_state.max_steps = st.slider(
        "Max browser actions", min_value=5, max_value=120,
        value=st.session_state.max_steps, step=5,
    )

    st.divider()
    st.caption(
        "The extension stays idle until the agent needs the browser. Press "
        "**Take over** on the in-page badge to grab the wheel at any time."
    )

# --------------------------------------------------------------------------- #
# Main layout
# --------------------------------------------------------------------------- #
if st.session_state.session_id is None:
    st.title("AI Browser Agent")
    st.markdown(
        """
Drive your own Chrome browser with an AI agent.

**Getting started**
1. Start the server (`python run_server.py`).
2. Open this page in the Chrome window that has the extension installed.
3. Type a task below - the agent opens its own tab and takes it from there.
"""
    )
    st.error(
        st.session_state.last_error
        or "Cannot reach the server - is `run_server.py` running?",
        icon="🔌",
    )
    st.stop()

ingest_events()
# Replayed log frames can be older than the snapshot fetched above, so take
# the authoritative reading last.
refresh_status()
sync_error()

status = st.session_state.status
state_name = status.get("status", "idle")
is_running = state_name in ("running", "paused", "awaiting_human", "stopping")
paused = bool(status.get("paused"))
connected = bool(status.get("extension_connected"))

# --- header ---------------------------------------------------------------
head_l, head_r = st.columns([3, 2])
with head_l:
    st.markdown(
        f"## Browser Agent "
        f"<span class='status-chip s-{state_name}'>{state_name.replace('_', ' ')}</span>",
        unsafe_allow_html=True,
    )
with head_r:
    c1, c2, c3 = st.columns(3)
    with c1:
        if st.button(
            "Resume" if paused else "Pause",
            width='stretch',
            disabled=not is_running,
        ):
            try:
                client.resume(st.session_state.session_id) if paused else client.pause(
                    st.session_state.session_id
                )
                st.rerun()
            except Exception as exc:  # noqa: BLE001
                st.error(str(exc))
    with c2:
        if st.button("Stop", width='stretch', disabled=not is_running):
            try:
                client.stop(st.session_state.session_id)
                st.rerun()
            except Exception as exc:  # noqa: BLE001
                st.error(str(exc))
    with c3:
        if st.button("Clear", width='stretch'):
            try:
                client.clear(st.session_state.session_id)
            except Exception:  # noqa: BLE001 - clearing locally is still useful
                pass
            st.session_state.update(
                messages=[], activity=[], cursor=0, screenshot=None,
                shot_meta={}, pending_question=None, last_error=None,
            )
            st.rerun()

if st.session_state.last_error:
    st.error(st.session_state.last_error, icon="⚠️")

if not connected and not status.get("relay_connected"):
    st.warning(
        "Chrome is not reachable. Open this page in the Chrome window that has "
        "the **AI Browser Agent** extension installed, then reload.",
        icon="🔌",
    )

left, right = st.columns([1, 1], gap="large")

# --- chat + activity ------------------------------------------------------
with left:
    st.markdown("#### Conversation")
    chat_box = st.container(height=430, border=True)
    with chat_box:
        if not st.session_state.messages:
            st.caption("No messages yet - describe a task below to begin.")
        for message in st.session_state.messages:
            role = message["role"]
            avatar = {"user": "🧑", "assistant": "🤖", "system": "⚙️"}.get(role, "🤖")
            with st.chat_message("user" if role == "user" else "assistant", avatar=avatar):
                st.markdown(message["content"])

    with st.expander(f"Agent activity ({len(st.session_state.activity)})", expanded=False):
        if not st.session_state.activity:
            st.caption("Tool calls will appear here as the agent works.")
        for item in st.session_state.activity[-60:]:
            if item["kind"] == "thinking":
                st.markdown(f"*{item['text']}*")
            elif item["kind"] == "call":
                args = ", ".join(f"{k}={v!r}" for k, v in (item.get("args") or {}).items())
                st.markdown(
                    f"<div class='tool-call'>▶ {item['tool']}({args})</div>",
                    unsafe_allow_html=True,
                )
            else:
                css = "tool-call" if item.get("ok", True) else "tool-call tool-err"
                st.markdown(
                    f"<div class='{css}'>◀ {item['text'][:600]}</div>",
                    unsafe_allow_html=True,
                )

# --- live browser view ----------------------------------------------------
with right:
    st.markdown("#### Live browser view")
    view = st.container(height=430, border=True)
    with view:
        if st.session_state.screenshot:
            st.image(st.session_state.screenshot, width='stretch')
            meta = st.session_state.shot_meta
            st.markdown(
                f"<div class='shot-meta'>{meta.get('title') or ''}<br>{meta.get('url') or ''}"
                f"{' · annotated' if meta.get('annotated') else ''}</div>",
                unsafe_allow_html=True,
            )
        else:
            st.caption(
                "The controlled tab will appear here once the agent takes its "
                "first screenshot."
            )

    m1, m2, m3 = st.columns(3)
    m1.metric("Actions", status.get("steps_taken", 0))
    if connected:
        browser_state = "active"
    else:
        browser_state = "idle" if status.get("relay_connected") else "offline"
    m2.metric("Browser", browser_state)
    m3.metric("Mode", st.session_state.vision_mode)

# --------------------------------------------------------------------------- #
# Human-in-the-loop prompt
# --------------------------------------------------------------------------- #
if st.session_state.pending_question:
    st.info(f"**The agent needs your input:** {st.session_state.pending_question}", icon="❓")
    with st.form("human_reply", clear_on_submit=True):
        answer = st.text_input(
            "Your answer",
            key="human_answer",
            type="password" if _looks_secret(st.session_state.pending_question) else "default",
        )
        if st.form_submit_button("Send to agent", type="primary") and answer:
            try:
                client.reply(st.session_state.session_id, answer)
                st.session_state.pending_question = None
                st.rerun()
            except Exception as exc:  # noqa: BLE001
                st.error(str(exc))

# --------------------------------------------------------------------------- #
# Task input
# --------------------------------------------------------------------------- #
# A dormant extension is the normal resting state - the agent wakes it on its
# first browser action, so only a missing relay should block input.
can_start = connected or bool(status.get("relay_connected"))
prompt = st.chat_input(
    "Describe what the agent should do in your browser…",
    disabled=not can_start or is_running,
)
if prompt:
    st.session_state.last_error = None
    try:
        client.start_task(
            st.session_state.session_id,
            prompt,
            vision_mode=st.session_state.vision_mode,
            max_steps=st.session_state.max_steps,
        )
        st.rerun()
    except Exception as exc:  # noqa: BLE001
        st.error(f"Could not start the task: {exc}")

# --------------------------------------------------------------------------- #
# Auto-refresh while work is in flight
# --------------------------------------------------------------------------- #
# A stable key keeps Streamlit from orphaning the fragment across full-app
# reruns ("the fragment ... does not exist anymore" warnings).
@st.fragment(run_every=POLL_SECONDS, key="agent_status_poller")
def _auto_refresh() -> None:
    """Re-run the page on a timer while there is something to watch.

    A ``sleep`` + ``st.rerun()`` loop would keep the script permanently
    running, which pins a CPU and never lets the app reach a settled state.
    A fragment with ``run_every`` schedules the rerun instead, so the page
    idles between polls.

    Polling while *not* connected is essential: the extension pairs
    asynchronously, so without it the page would sit on "not connected"
    forever even after the socket is established.
    """
    session_id = st.session_state.session_id
    if not session_id:
        return
    try:
        latest = client.session_status(session_id)
    except Exception:  # noqa: BLE001 - transient server hiccup, retry next tick
        return

    # Only a *change* may trigger a full rerun. Rerunning unconditionally
    # would re-arm this fragment immediately and spin forever, so the page
    # would never reach a settled state.
    previous = st.session_state.status or {}

    # Consume the frames here rather than only testing for them: a rerun that
    # re-fetched them would double the latency of the live view, and two
    # screenshots of the same page produce an identical status payload, so
    # status equality alone can never detect a new frame.
    new_events = ingest_events()

    if latest != previous or new_events:
        st.session_state.status = latest
        st.rerun()


_auto_refresh()
