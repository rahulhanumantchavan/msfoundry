"""Thin HTTP client the Streamlit app uses to talk to the FastAPI server.

Streamlit reruns the whole script on every interaction, which makes a
long-lived WebSocket awkward to own. Instead the UI polls the server's buffered
event log (``/api/sessions/{id}/events``) with a cursor - the server keeps the
same frames it broadcasts over ``/ws/ui``, so nothing is lost and the UI stays
stateless and reconnect-safe.
"""

from __future__ import annotations

from typing import Any

import requests


class ServerClient:
    """Small, explicit wrapper over the server's REST surface."""

    def __init__(self, base_url: str, timeout: float = 20.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    # -- plumbing ---------------------------------------------------------
    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        response = requests.request(
            method, self._url(path), timeout=self.timeout, **kwargs
        )
        if response.status_code >= 400:
            detail = response.text
            try:
                detail = response.json().get("detail", detail)
            except ValueError:
                pass
            raise RuntimeError(f"{response.status_code}: {detail}")
        if not response.content:
            return {}
        return response.json()

    # -- endpoints --------------------------------------------------------
    def health(self) -> dict[str, Any]:
        return self._request("GET", "/health")

    def create_pairing(self, session_id: str | None = None) -> dict[str, Any]:
        params = {"session_id": session_id} if session_id else None
        return self._request("POST", "/api/pairing", params=params)

    def default_session(self) -> dict[str, Any]:
        """The shared local session the UI and extension both attach to."""
        return self._request("GET", "/api/session/default")

    def session_status(self, session_id: str) -> dict[str, Any]:
        return self._request("GET", f"/api/sessions/{session_id}")

    def connected_sessions(self) -> list[dict[str, Any]]:
        """Sessions that already have a live extension attached."""
        return self._request("GET", "/api/sessions/active/connected").get(
            "sessions", []
        )

    def connect_extension(self, session_id: str) -> dict[str, Any]:
        """Wake the extension and wait for its socket (UI "Connect")."""
        return self._request("POST", f"/api/sessions/{session_id}/connect")

    def disconnect_extension(self, session_id: str) -> dict[str, Any]:
        """Release browser control and let the extension go dormant."""
        return self._request("POST", f"/api/sessions/{session_id}/disconnect")

    def agent_tab(self, session_id: str, action: str = "open") -> dict[str, Any]:
        """Open, focus or close the agent's dedicated tab."""
        return self._request(
            "POST", f"/api/sessions/{session_id}/tab", params={"action": action}
        )

    def events(self, session_id: str, since: int = 0) -> dict[str, Any]:
        return self._request(
            "GET", f"/api/sessions/{session_id}/events", params={"since": since}
        )

    def start_task(
        self,
        session_id: str,
        prompt: str,
        *,
        vision_mode: str | None = None,
        max_steps: int | None = None,
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            "/api/task/start",
            json={
                "session_id": session_id,
                "prompt": prompt,
                "vision_mode": vision_mode,
                "max_steps": max_steps,
            },
        )

    def pause(self, session_id: str) -> dict[str, Any]:
        return self._request("POST", "/api/task/pause", params={"session_id": session_id})

    def resume(self, session_id: str) -> dict[str, Any]:
        return self._request(
            "POST", "/api/task/resume", params={"session_id": session_id}
        )

    def stop(self, session_id: str) -> dict[str, Any]:
        return self._request("POST", "/api/task/stop", params={"session_id": session_id})

    def reply(self, session_id: str, reply: str) -> dict[str, Any]:
        return self._request(
            "POST", "/api/task/reply", json={"session_id": session_id, "reply": reply}
        )

    def clear(self, session_id: str) -> dict[str, Any]:
        return self._request("POST", f"/api/sessions/{session_id}/clear")
