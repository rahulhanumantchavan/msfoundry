/**
 * MV3 service worker: the extension's control plane.
 *
 * Responsibilities
 *  - Own the WebSocket connection to the central server.
 *  - Dispatch inbound `command` frames to the AutomationEngine and reply with
 *    `result` frames.
 *  - Track the "controlled tab" and keep its visual overlay in sync.
 *  - Expose state + actions (connect, disconnect, pause, stop, takeover) to
 *    the popup via chrome.runtime messaging.
 *  - Survive service-worker eviction by persisting config in chrome.storage
 *    and reviving the socket from an alarm.
 */

import { AgentSocket } from './lib/ws-client.js';
import { AutomationEngine, isProtectedUrl } from './lib/automation.js';

const DEFAULTS = {
  serverUrl: 'ws://127.0.0.1:8000/ws/extension',
  pairingCode: '',
  sessionId: '',
  // On-demand: the UI tab wakes us when the agent needs the browser, so we
  // never hold a socket open in the background.
  autoConnect: false,
  tabMode: 'dedicated'
};

const state = {
  connectionState: 'disconnected',
  sessionId: null,
  controlledTabId: null,
  agentTabId: null,
  paused: false,
  busy: false,
  lastError: null,
  lastAction: null,
  actionCount: 0
};

let config = { ...DEFAULTS };

const engine = new AutomationEngine({
  onEvent: (name, payload) => {
    if (name === 'detached') {
      // The debugger went away (tab closed, DevTools opened, user cancelled).
      if (state.controlledTabId !== null) {
        setOverlay(state.controlledTabId, { active: false }).catch(() => {});
      }
      state.controlledTabId = null;
      socket.sendEvent('error', {
        message: `browser control ended: ${payload.reason || 'detached'}`
      });
      broadcastState();
    }
  }
});

// --------------------------------------------------------------------- //
// Configuration persistence
// --------------------------------------------------------------------- //
async function loadConfig() {
  const stored = await chrome.storage.local.get(DEFAULTS);
  config = { ...DEFAULTS, ...stored };
  return config;
}

async function saveConfig(patch) {
  config = { ...config, ...patch };
  await chrome.storage.local.set(config);
  return config;
}

// --------------------------------------------------------------------- //
// Socket
// --------------------------------------------------------------------- //
const socket = new AgentSocket({
  getUrl: () => config.serverUrl,
  getPairingCode: () => config.pairingCode,
  getSessionId: () => config.sessionId,
  onCommand: (frame) => handleCommand(frame),
  onControl: (frame) => handleControl(frame),
  onState: (connectionState, detail) => {
    state.connectionState = connectionState;
    if (connectionState === 'paired') {
      state.sessionId = detail.sessionId || null;
      state.lastError = null;
      // Keep the worker alive only while it is actually connected.
      chrome.alarms.create('keepalive', { periodInMinutes: 0.5 });
    }
    if (connectionState === 'disconnected' && !config.autoConnect) {
      chrome.alarms.clear('keepalive').catch(() => {});
    }
    if (connectionState === 'stale') {
      // Stale credentials (restarted server / reloaded extension). Drop them
      // so the next wake from the UI starts clean instead of re-failing.
      state.sessionId = null;
      state.lastError = null;
      saveConfig({ autoConnect: false, sessionId: '', pairingCode: '' }).catch(
        () => {}
      );
      chrome.alarms.clear('keepalive').catch(() => {});
    }
    if (connectionState === 'error' || connectionState === 'rejected') {
      state.lastError = detail.message || 'connection error';
    }
    updateBadge();
    broadcastState();
  }
});

function updateBadge() {
  const map = {
    paired: { text: 'ON', color: '#16a34a' },
    connecting: { text: '...', color: '#f59e0b' },
    disconnected: { text: '', color: '#64748b' },
    error: { text: '!', color: '#dc2626' },
    rejected: { text: '!', color: '#dc2626' }
  };
  const badge = map[state.connectionState] || map.disconnected;
  const text = state.paused && state.connectionState === 'paused' ? '||' : badge.text;
  chrome.action.setBadgeText({ text: state.paused ? '||' : text }).catch(() => {});
  chrome.action
    .setBadgeBackgroundColor({ color: state.paused ? '#f59e0b' : badge.color })
    .catch(() => {});
}

function broadcastState() {
  // The popup may be closed; ignore "no receiver" errors.
  chrome.runtime
    .sendMessage({ type: 'state', state: getPublicState() })
    .catch(() => {});
}

function getPublicState() {
  return {
    ...state,
    serverUrl: config.serverUrl,
    pairingCode: config.pairingCode,
    tabMode: config.tabMode,
    connected: socket.connected
  };
}

// --------------------------------------------------------------------- //
// Controlled tab management
// --------------------------------------------------------------------- //

/** Restore the remembered agent tab id after a service-worker revival. */
async function loadAgentTab() {
  if (state.agentTabId !== null) return state.agentTabId;
  const { agentTabId } = await chrome.storage.session.get({ agentTabId: null });
  state.agentTabId = agentTabId;
  return agentTabId;
}

async function rememberAgentTab(tabId) {
  state.agentTabId = tabId;
  await chrome.storage.session.set({ agentTabId: tabId });
  socket.sendEvent('agent_tab', { tabId });
}

/** True when the tab still exists and can be driven. */
async function tabIsUsable(tabId) {
  if (tabId === null || tabId === undefined) return false;
  try {
    const tab = await chrome.tabs.get(tabId);
    if (!tab) return false;
    // A tab that has not committed a navigation yet reports an empty url and
    // carries the real target in pendingUrl.
    const url = tab.url || tab.pendingUrl || 'about:blank';
    return !isProtectedUrl(url);
  } catch (_) {
    return false;
  }
}

/**
 * Return the agent's own tab, creating it if needed.
 *
 * A dedicated tab means consecutive tasks share cookies, logins and history,
 * and the agent can never hijack the tab the user is typing in.
 */
async function ensureAgentTab() {
  await loadAgentTab();
  if (await tabIsUsable(state.agentTabId)) return state.agentTabId;

  const tab = await chrome.tabs.create({ url: 'about:blank', active: true });
  // Let the new tab commit a navigation before the debugger attaches.
  await new Promise((r) => setTimeout(r, 400));
  await rememberAgentTab(tab.id);
  return tab.id;
}

/** Pick the tab the agent should drive. */
async function resolveControlledTab() {
  if (config.tabMode === 'dedicated') {
    // Stay on the agent tab unless control was explicitly moved elsewhere
    // (e.g. new_tab / switch_tab for an OAuth popup).
    if (state.controlledTabId !== null && (await tabIsUsable(state.controlledTabId))) {
      return state.controlledTabId;
    }
    return ensureAgentTab();
  }

  if (state.controlledTabId !== null) {
    try {
      const tab = await chrome.tabs.get(state.controlledTabId);
      if (tab && !isProtectedUrl(tab.url)) return tab.id;
    } catch (_) {
      state.controlledTabId = null;
    }
  }
  const [active] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (active && !isProtectedUrl(active.url)) return active.id;

  const candidates = await chrome.tabs.query({ currentWindow: true });
  const usable = candidates.find((t) => !isProtectedUrl(t.url));
  if (usable) return usable.id;

  throw new Error(
    'no controllable tab found. Open a normal web page (not a chrome:// page) and try again.'
  );
}

/** Attach control to a tab and turn on its visual overlay. */
async function takeControl(tabId) {
  const previous = state.controlledTabId;
  await engine.attach(tabId);
  state.controlledTabId = tabId;
  if (previous !== null && previous !== tabId) {
    await setOverlay(previous, { active: false }).catch(() => {});
  }
  await setOverlay(tabId, { active: true, paused: state.paused });
  return tabId;
}

/** Push overlay state into the content script (injecting it if needed). */
async function setOverlay(tabId, options) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: 'overlay', ...options });
  } catch (_) {
    // Content script not present yet (e.g. after a navigation) - inject it.
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ['content/overlay.js']
      });
      await chrome.tabs.sendMessage(tabId, { type: 'overlay', ...options });
    } catch (_) {
      /* page forbids injection (PDF viewer, store) - overlay is best-effort */
    }
  }
}

async function releaseControl() {
  const tabId = state.controlledTabId;
  state.controlledTabId = null;
  await engine.detach();
  if (tabId !== null) {
    await setOverlay(tabId, { active: false }).catch(() => {});
  }
}

/**
 * Fully stand down: drop the debugger, optionally close the agent tab, then
 * close the socket so the service worker can be evicted. The UI relay wakes
 * us again when the agent next needs the browser.
 */
async function goDormant(closeTab = false) {
  await releaseControl();
  if (closeTab) {
    await loadAgentTab();
    if (state.agentTabId !== null) {
      await chrome.tabs.remove(state.agentTabId).catch(() => {});
    }
    state.agentTabId = null;
    await chrome.storage.session.remove('agentTabId');
  }
  socket.sendEvent('released', { closedTab: closeTab });
  socket.stop();
  await saveConfig({ autoConnect: false });
  state.paused = false;
  updateBadge();
  broadcastState();
}

// --------------------------------------------------------------------- //
// Command dispatch
// --------------------------------------------------------------------- //
const HANDLERS = {
  navigate: async (p) => {
    const tabId = await resolveControlledTab();
    await takeControl(tabId);
    return engine.navigate(p);
  },
  click: (p) => engine.click(p),
  type: (p) => engine.type(p),
  press_key: (p) => engine.pressKey(p),
  scroll: (p) => engine.scroll(p),
  select_option: (p) => engine.selectOption(p),
  go_back: () => engine.goBack(),
  go_forward: () => engine.goForward(),
  screenshot: async () => {
    // Screenshots must work even before the first explicit action.
    if (!engine.attached) await takeControl(await resolveControlledTab());
    return engine.screenshot();
  },
  get_tree: (p) => engine.getTree(p),
  evaluate_js: (p) => engine.evaluateJs(p),
  get_page_info: () => engine.getPageInfo(),
  wait: (p) => engine.waitFor(p),

  new_tab: async (p) => {
    // In dedicated mode the agent tab *is* the agent's workspace: reuse it and
    // navigate, rather than littering the window with a tab per call.
    if (config.tabMode === 'dedicated') {
      const tabId = await ensureAgentTab();
      await takeControl(tabId);
      if (p.url && p.url !== 'about:blank') return engine.navigate(p);
      await engine.waitForLoad(10000);
      const fresh = await chrome.tabs.get(tabId);
      return { tabId, url: fresh.url, title: fresh.title, message: 'using agent tab' };
    }

    const tab = await chrome.tabs.create({ url: p.url || 'about:blank', active: true });
    // Give the new tab a moment to commit a navigation before attaching.
    await new Promise((r) => setTimeout(r, 600));
    await takeControl(tab.id);
    await engine.waitForLoad(10000);
    const fresh = await chrome.tabs.get(tab.id);
    return { tabId: tab.id, url: fresh.url, title: fresh.title, message: 'tab opened' };
  },

  switch_tab: async (p) => {
    const tabId = Number(p.tabId);
    const tab = await chrome.tabs.get(tabId);
    if (isProtectedUrl(tab.url)) throw new Error(`tab ${tabId} is a protected page`);
    await chrome.tabs.update(tabId, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
    await takeControl(tabId);
    return { tabId, url: tab.url, title: tab.title, message: 'switched tab' };
  },

  close_tab: async (p) => {
    const tabId = p.tabId ? Number(p.tabId) : state.controlledTabId;
    if (tabId === null || tabId === undefined) throw new Error('no tab to close');
    if (tabId === state.controlledTabId) await releaseControl();
    await chrome.tabs.remove(tabId);
    if (tabId === state.agentTabId) {
      state.agentTabId = null;
      await chrome.storage.session.remove('agentTabId');
    }
    // Return control to the agent's own tab rather than the user's.
    if (config.tabMode === 'dedicated') {
      await takeControl(await ensureAgentTab()).catch(() => {});
    } else {
      const [next] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (next && !isProtectedUrl(next.url)) {
        await takeControl(next.id).catch(() => {});
      }
    }
    return { message: `closed tab ${tabId}` };
  },

  list_tabs: async () => {
    const tabs = await chrome.tabs.query({});
    return {
      tabs: tabs.map((t) => ({
        id: t.id,
        title: t.title,
        url: t.url,
        active: t.id === state.controlledTabId,
        agentTab: t.id === state.agentTabId,
        protected: isProtectedUrl(t.url)
      }))
    };
  }
};

async function handleCommand(frame) {
  const started = Date.now();
  const { id, action, params = {} } = frame;

  if (state.paused && action !== 'screenshot') {
    socket.sendResult(id, false, {}, 'agent is paused by the user', Date.now() - started);
    return;
  }

  const handler = HANDLERS[action];
  if (!handler) {
    socket.sendResult(id, false, {}, `unsupported action: ${action}`, Date.now() - started);
    return;
  }

  state.busy = true;
  state.lastAction = action;
  state.actionCount += 1;
  broadcastState();

  try {
    // Every action except plain reads needs an attached, controlled tab.
    if (!['list_tabs', 'new_tab', 'switch_tab', 'navigate', 'screenshot'].includes(action)) {
      if (!engine.attached) await takeControl(await resolveControlledTab());
    }
    const data = await handler(params);
    socket.sendResult(id, true, data || {}, null, Date.now() - started);
    state.lastError = null;
  } catch (err) {
    const message = err && err.message ? err.message : String(err);
    socket.sendResult(id, false, {}, message, Date.now() - started);
    state.lastError = message;
  } finally {
    state.busy = false;
    broadcastState();
  }
}

function handleControl(frame) {
  switch (frame.signal) {
    case 'pause':
      state.paused = true;
      break;
    case 'resume':
      state.paused = false;
      break;
    case 'stop':
      state.paused = false;
      releaseControl().catch(() => {});
      break;
    case 'task_started':
      state.paused = false;
      break;
    case 'task_finished':
      // Detach the debugger but keep the agent tab, so the next task resumes
      // in the same tab with its cookies and login state intact.
      releaseControl().catch(() => {});
      break;
    case 'release':
      goDormant(!!frame.payload?.close_tab).catch(() => {});
      break;
    default:
      break;
  }
  if (state.controlledTabId !== null && frame.signal !== 'stop' && frame.signal !== 'task_finished') {
    setOverlay(state.controlledTabId, {
      active: true,
      paused: state.paused
    }).catch(() => {});
  }
  updateBadge();
  broadcastState();
}

// --------------------------------------------------------------------- //
// Popup / runtime messaging
// --------------------------------------------------------------------- //
const ACTIONS = {
  getState: async () => getPublicState(),

  /**
   * Wake signal relayed by the agent UI tab.
   *
   * This is the only path that starts a socket in normal operation: the
   * extension does nothing until the server says the agent needs the browser.
   */
  wake: async ({ serverUrl, pairingCode, sessionId, tabMode }) => {
    await saveConfig({
      serverUrl: serverUrl || config.serverUrl,
      pairingCode: (pairingCode || '').trim().toUpperCase(),
      sessionId: (sessionId || '').trim(),
      tabMode: tabMode || config.tabMode,
      autoConnect: true
    });
    if (!socket.connected && socket.state !== 'connecting') socket.start();
    return getPublicState();
  },

  connect: async ({ serverUrl, pairingCode, sessionId }) => {
    await saveConfig({
      serverUrl: serverUrl || config.serverUrl,
      pairingCode: (pairingCode || '').trim().toUpperCase(),
      sessionId: (sessionId || config.sessionId || '').trim(),
      autoConnect: true
    });
    if (!config.pairingCode && !config.sessionId) {
      throw new Error('open the agent UI so it can supply connection details');
    }
    socket.start();
    return getPublicState();
  },

  disconnect: async () => {
    await goDormant(false);
    return getPublicState();
  },

  pause: async () => {
    state.paused = true;
    socket.sendEvent('paused', {});
    if (state.controlledTabId !== null) {
      await setOverlay(state.controlledTabId, { active: true, paused: true });
    }
    updateBadge();
    return getPublicState();
  },

  resume: async () => {
    state.paused = false;
    socket.sendEvent('resumed', {});
    if (state.controlledTabId !== null) {
      await setOverlay(state.controlledTabId, { active: true, paused: false });
    }
    updateBadge();
    return getPublicState();
  },

  stop: async () => {
    state.paused = false;
    socket.sendEvent('stopped', {});
    await releaseControl();
    updateBadge();
    return getPublicState();
  },

  /** User grabs the wheel: detach immediately and tell the server. */
  takeover: async () => {
    state.paused = true;
    socket.sendEvent('user_takeover', { tabId: state.controlledTabId });
    await releaseControl();
    updateBadge();
    return getPublicState();
  }
};

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  const handler = ACTIONS[message?.action];
  if (!handler) return false;
  handler(message.payload || message || {})
    .then((result) => sendResponse({ ok: true, result }))
    .catch((err) => sendResponse({ ok: false, error: err?.message || String(err) }));
  return true; // keep the message channel open for the async reply
});

// --------------------------------------------------------------------- //
// Tab lifecycle
// --------------------------------------------------------------------- //
chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === state.agentTabId) {
    // The user closed the agent's tab; forget it so the next action recreates it.
    state.agentTabId = null;
    chrome.storage.session.remove('agentTabId').catch(() => {});
    socket.sendEvent('agent_tab', { tabId: null });
  }
  if (tabId === state.controlledTabId) {
    state.controlledTabId = null;
    engine.detach().catch(() => {});
    socket.sendEvent('error', { message: 'the controlled tab was closed' });
    broadcastState();
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (tabId !== state.controlledTabId) return;
  if (changeInfo.status === 'complete') {
    // A navigation replaces the document, so re-apply the overlay.
    setOverlay(tabId, { active: true, paused: state.paused }).catch(() => {});
    socket.sendEvent('tab_changed', { tabId, url: changeInfo.url });
  }
});

// --------------------------------------------------------------------- //
// Service-worker lifecycle
// --------------------------------------------------------------------- //

// A keepalive alarm only runs while a task is in flight; outside of that the
// worker is free to be evicted and the UI relay wakes it on demand.
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'keepalive') return;
  await loadConfig();
  if (!config.autoConnect) {
    await chrome.alarms.clear('keepalive').catch(() => {});
    return;
  }
  if (!socket.connected && socket.state !== 'connecting') socket.start();
});

chrome.runtime.onStartup.addListener(async () => {
  // A fresh browser session starts dormant: stale credentials would point at
  // a session the server no longer has.
  await saveConfig({ autoConnect: false, sessionId: '', pairingCode: '' });
  updateBadge();
});

chrome.runtime.onInstalled.addListener(async () => {
  await loadConfig();
  updateBadge();
});

// Initial boot of the worker. Reconnecting here is only correct when the
// worker was evicted *mid-task*; otherwise the stored credentials may point at
// a session the server no longer has, so we stay dormant and wait for a wake.
(async () => {
  await loadConfig();
  await loadAgentTab();
  updateBadge();
  if (config.autoConnect && config.sessionId && state.agentTabId !== null) {
    socket.start();
  }
})();
