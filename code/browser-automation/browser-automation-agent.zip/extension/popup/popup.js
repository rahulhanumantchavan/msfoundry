/**
 * Popup: a status placeholder plus an emergency stop.
 *
 * Connecting, pausing, tab control and tasks all live in the agent UI; the
 * popup deliberately keeps only the one control that must never depend on the
 * UI being responsive.
 */

const $ = (id) => document.getElementById(id);

const els = {
  openUi: $('open-ui'),
  estop: $('estop'),
  pill: $('status-pill'),
  session: $('session'),
  hint: $('hint'),
  tab: $('tab'),
  count: $('count'),
  last: $('last'),
  error: $('error')
};

const UI_URL = 'http://localhost:8501';

const PILL = {
  paired: { text: 'Active', cls: 'online' },
  connecting: { text: 'Waking…', cls: 'connecting' },
  disconnected: { text: 'Idle', cls: 'offline' },
  // Not failures: both mean "waiting to be woken with fresh details".
  error: { text: 'Idle', cls: 'offline' },
  stale: { text: 'Idle', cls: 'offline' },
  rejected: { text: 'Idle', cls: 'offline' }
};

/** Send an action to the service worker and surface any error. */
async function dispatch(action, payload = {}) {
  showError(null);
  try {
    const response = await chrome.runtime.sendMessage({ action, ...payload });
    if (!response?.ok) {
      showError(response?.error || 'action failed');
      return null;
    }
    render(response.result);
    return response.result;
  } catch (err) {
    showError(err?.message || String(err));
    return null;
  }
}

function showError(message) {
  if (!message) {
    els.error.hidden = true;
    els.error.textContent = '';
    return;
  }
  els.error.hidden = false;
  els.error.textContent = message;
}

function render(state) {
  if (!state) return;

  const paused = !!state.paused;
  const pill = paused && state.connected
    ? { text: 'Paused', cls: 'paused' }
    : PILL[state.connectionState] || PILL.disconnected;
  els.pill.textContent = pill.text;
  els.pill.className = `pill ${pill.cls}`;

  const connected = !!state.connected;
  els.session.textContent = connected && state.sessionId
    ? `session ${state.sessionId}`
    : 'idle - waiting for the agent';
  els.hint.textContent = connected
    ? 'The agent is driving this browser. Use the UI to pause or stop.'
    : 'Controlled from the agent UI. This extension stays idle until the agent needs the browser.';

  const tabId = state.agentTabId ?? state.controlledTabId;
  els.tab.textContent = tabId === null || tabId === undefined ? 'none' : `#${tabId}`;
  els.count.textContent = String(state.actionCount ?? 0);
  els.last.textContent = state.lastAction || '—';
  els.estop.disabled = !connected && tabId === null;

  // "Idle" is the normal resting state, not a failure worth reporting.
  if (state.lastError && connected) showError(state.lastError);
}

// --- wiring ------------------------------------------------------------- //
els.openUi.addEventListener('click', async () => {
  const [existing] = await chrome.tabs.query({ url: `${UI_URL}/*` });
  if (existing) {
    await chrome.tabs.update(existing.id, { active: true });
    await chrome.windows.update(existing.windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url: UI_URL, active: true });
  }
  window.close();
});

els.estop.addEventListener('click', async () => {
  await dispatch('stop');
  await dispatch('disconnect');
});

// Live updates pushed by the service worker.
chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === 'state') render(message.state);
});

// Initial paint.
dispatch('getState');
