/**
 * Visual feedback overlay injected into the controlled tab.
 *
 * Shows the user, unmistakably, that an AI agent is driving this tab:
 *  - an animated coloured border around the viewport,
 *  - a floating "AI Agent is working" badge with a Take over / Pause button.
 *
 * Everything lives in a closed shadow DOM attached to a single host element so
 * page CSS cannot restyle it and the page's own scripts cannot read it.
 */

(() => {
  // The content script is re-injected after navigations; keep it idempotent.
  if (window.__aiBrowserAgentOverlayInstalled) return;
  window.__aiBrowserAgentOverlayInstalled = true;

  const HOST_ID = '__ai-browser-agent-overlay__';
  let host = null;
  let shadow = null;
  let badgeText = null;
  let pauseButton = null;
  let activeState = { active: false, paused: false };

  const STYLE = `
    :host { all: initial; }
    .frame {
      position: fixed;
      inset: 0;
      pointer-events: none;
      z-index: 2147483646;
      border: 3px solid rgba(37, 99, 235, 0.95);
      box-shadow: inset 0 0 22px rgba(37, 99, 235, 0.28);
      border-radius: 2px;
      animation: pulse 2.4s ease-in-out infinite;
      transition: border-color .2s ease;
    }
    .frame.paused {
      border-color: rgba(245, 158, 11, 0.95);
      box-shadow: inset 0 0 22px rgba(245, 158, 11, 0.28);
      animation: none;
    }
    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.55; }
    }
    .badge {
      position: fixed;
      top: 16px;
      right: 16px;
      z-index: 2147483647;
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 9px 14px;
      background: rgba(17, 24, 39, 0.94);
      color: #f9fafb;
      font: 500 13px/1.4 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      border-radius: 999px;
      box-shadow: 0 8px 26px rgba(0, 0, 0, 0.35);
      pointer-events: auto;
      user-select: none;
      backdrop-filter: blur(6px);
    }
    .dot {
      width: 9px; height: 9px; border-radius: 50%;
      background: #22c55e;
      box-shadow: 0 0 0 0 rgba(34, 197, 94, 0.7);
      animation: ping 1.6s cubic-bezier(0, 0, 0.2, 1) infinite;
      flex: none;
    }
    .badge.paused .dot { background: #f59e0b; animation: none; }
    @keyframes ping {
      0%   { box-shadow: 0 0 0 0 rgba(34, 197, 94, 0.7); }
      70%  { box-shadow: 0 0 0 9px rgba(34, 197, 94, 0); }
      100% { box-shadow: 0 0 0 0 rgba(34, 197, 94, 0); }
    }
    button {
      font: 600 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      color: #f9fafb;
      background: rgba(255, 255, 255, 0.14);
      border: 1px solid rgba(255, 255, 255, 0.22);
      border-radius: 999px;
      padding: 5px 11px;
      cursor: pointer;
      transition: background .15s ease;
    }
    button:hover { background: rgba(255, 255, 255, 0.26); }
    button.stop { background: rgba(239, 68, 68, 0.85); border-color: rgba(239,68,68,.9); }
    button.stop:hover { background: rgba(239, 68, 68, 1); }
  `;

  function build() {
    if (host && document.documentElement.contains(host)) return;

    host = document.createElement('div');
    host.id = HOST_ID;
    // A closed root keeps the page from inspecting or restyling the overlay.
    shadow = host.attachShadow({ mode: 'closed' });

    const style = document.createElement('style');
    style.textContent = STYLE;

    const frame = document.createElement('div');
    frame.className = 'frame';
    frame.part = 'frame';

    const badge = document.createElement('div');
    badge.className = 'badge';

    const dot = document.createElement('span');
    dot.className = 'dot';

    badgeText = document.createElement('span');
    badgeText.textContent = 'AI Agent is working';

    pauseButton = document.createElement('button');
    pauseButton.textContent = 'Pause';
    pauseButton.addEventListener('click', () => {
      const next = !activeState.paused;
      chrome.runtime.sendMessage({ action: next ? 'pause' : 'resume' }).catch(() => {});
      render({ ...activeState, paused: next });
    });

    const takeover = document.createElement('button');
    takeover.className = 'stop';
    takeover.textContent = 'Take over';
    takeover.addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'takeover' }).catch(() => {});
      render({ active: false, paused: false });
    });

    badge.append(dot, badgeText, pauseButton, takeover);
    shadow.append(style, frame, badge);

    // Store refs for cheap updates.
    host.__frame = frame;
    host.__badge = badge;

    (document.body || document.documentElement).appendChild(host);
  }

  function render(next) {
    activeState = { ...activeState, ...next };
    if (!activeState.active) {
      if (host && host.parentNode) host.parentNode.removeChild(host);
      host = null;
      return;
    }
    build();
    const paused = !!activeState.paused;
    host.__frame.classList.toggle('paused', paused);
    host.__badge.classList.toggle('paused', paused);
    badgeText.textContent = paused ? 'AI Agent paused' : 'AI Agent is working';
    pauseButton.textContent = paused ? 'Resume' : 'Pause';
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== 'overlay') return false;
    render({ active: !!message.active, paused: !!message.paused });
    sendResponse({ ok: true });
    return true;
  });

  // Some sites wipe body children on hydration; re-attach if we disappear.
  const observer = new MutationObserver(() => {
    if (activeState.active && host && !document.documentElement.contains(host)) {
      host = null;
      build();
      render(activeState);
    }
  });
  observer.observe(document.documentElement, { childList: true, subtree: false });
})();
