/**
 * Wake relay: the bridge between the agent UI page and the service worker.
 *
 * The server cannot open a connection *into* a dormant MV3 service worker, so
 * it needs something inside Chrome to ring the doorbell. This content script
 * runs only on the agent's own UI page and:
 *
 *   1. discovers the shared session from the server (and also accepts a
 *      postMessage announcement from the Streamlit component iframe),
 *   2. subscribes to the server's relay stream,
 *   3. forwards `wake` signals to the service worker.
 *
 * Discovery is self-starting so the relay cannot be defeated by a missed
 * announcement, and closing the UI tab tears it down - which is what lets the
 * extension stay fully idle the rest of the time.
 */

(() => {
  if (window.__browserAgentRelay) return;
  window.__browserAgentRelay = true;

  const RETRY_MS = 3000;

  let current = null; // { sessionId, serverUrl }
  let source = null;
  let retryTimer = null;

  function sameTarget(a, b) {
    return a && b && a.sessionId === b.sessionId && a.serverUrl === b.serverUrl;
  }

  function stopStream() {
    if (retryTimer) {
      clearTimeout(retryTimer);
      retryTimer = null;
    }
    if (source) {
      try {
        source.close();
      } catch (_) {
        /* already closed */
      }
      source = null;
    }
  }

  /** Hand a signal to the service worker, starting it if it was evicted. */
  async function notifyWorker(action, payload) {
    try {
      await chrome.runtime.sendMessage({ action, ...payload });
    } catch (_) {
      // The extension was reloaded or disabled; the stream will retry.
    }
  }

  function handleFrame(frame) {
    if (!frame || !current) return;
    const payload = frame.payload || {};

    if (frame.signal === 'config') {
      // The server tells the relay exactly how the extension should connect,
      // so the user never types a URL or a pairing code.
      current.wsUrl = payload.ws_url || current.wsUrl;
      current.pairingCode = payload.pairing_code || current.pairingCode || '';
      current.tabMode = payload.tab_mode || current.tabMode || 'dedicated';
      return;
    }

    if (frame.signal === 'wake') {
      notifyWorker('wake', {
        serverUrl: current.wsUrl,
        pairingCode: current.pairingCode,
        sessionId: payload.session_id || current.sessionId,
        tabMode: current.tabMode
      });
    }
  }

  function startStream(target) {
    stopStream();
    current = { ...target };

    const url = `${target.serverUrl}/api/sessions/${encodeURIComponent(
      target.sessionId
    )}/relay`;

    try {
      source = new EventSource(url);
    } catch (_) {
      retryTimer = setTimeout(() => startStream(target), RETRY_MS);
      return;
    }

    source.onmessage = (event) => {
      let frame;
      try {
        frame = JSON.parse(event.data);
      } catch (_) {
        return;
      }
      handleFrame(frame);
    };

    source.onerror = () => {
      // EventSource reconnects on its own, but a server restart can leave it
      // wedged; rebuild it after a short delay.
      stopStream();
      retryTimer = setTimeout(() => startStream(target), RETRY_MS);
    };
  }

  // Backup path: the UI announces itself from a Streamlit component iframe,
  // which can only reach the top frame via postMessage. Discovery normally
  // wins the race; this corrects the stream if the UI points somewhere else.
  window.addEventListener('message', (event) => {
    const announce = event.data && event.data.__browserAgent;
    if (!announce || !announce.sessionId || !announce.serverUrl) return;

    const target = {
      sessionId: String(announce.sessionId),
      serverUrl: String(announce.serverUrl).replace(/\/+$/, ''),
      wsUrl: '',
      pairingCode: '',
      tabMode: 'dedicated'
    };
    // Streamlit re-renders on every rerun, so only act on a real change.
    if (sameTarget(current, target) && source) return;
    startStream(target);
  });

  /**
   * Find the shared session without waiting to be told.
   *
   * The UI page is served by Streamlit but the agent server may be elsewhere,
   * so try the page's own origin first and then the conventional local port.
   */
  async function discover() {
    if (current && source) return;

    const candidates = [window.location.origin];
    for (const guess of ['http://127.0.0.1:8000', 'http://localhost:8000']) {
      if (!candidates.includes(guess)) candidates.push(guess);
    }

    for (const base of candidates) {
      try {
        const response = await fetch(`${base}/api/session/default`, {
          method: 'GET',
          cache: 'no-store'
        });
        if (!response.ok) continue;
        const data = await response.json();
        if (!data.session_id) continue;
        startStream({
          sessionId: String(data.session_id),
          serverUrl: base.replace(/\/+$/, ''),
          wsUrl: data.ws_url || '',
          pairingCode: data.pairing_code || '',
          tabMode: 'dedicated'
        });
        return;
      } catch (_) {
        // Not the agent server (or not reachable) - try the next candidate.
      }
    }
    // The server may simply not be up yet; keep looking while the tab is open.
    retryTimer = setTimeout(discover, RETRY_MS);
  }

  window.addEventListener('pagehide', stopStream);
  discover();
})();
