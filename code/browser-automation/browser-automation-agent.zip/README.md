# AI Browser Agent

A production-ready system that lets an AI agent hosted on a **central server**
observe and control a user's **own Chrome browser** through a Manifest V3
extension, with a **Streamlit** chat UI for prompting and live viewing.

```
┌──────────────┐   HTTP/REST    ┌─────────────────────────┐   WebSocket    ┌──────────────────┐
│  Streamlit   │ ◀────────────▶ │     FastAPI Server      │ ◀────────────▶ │ Chrome Extension │
│      UI      │   event poll   │                         │   RPC + events │     (MV3)        │
└──────────────┘                │  • LangGraph/DeepAgents │                └──────────────────┘
                                │  • Azure OpenAI (vision)│                         │
                                │  • OpenCV pipeline      │                  chrome.debugger
                                │  • Session + pairing    │                         │
                                └─────────────────────────┘                    User's tab
```

**Flow:** the user types a task in Streamlit → the server's LangGraph agent
reasons over a screenshot from the browser → it calls a browser tool → the
extension executes it via the Chrome DevTools Protocol → a new screenshot flows
back through the OpenCV pipeline → the loop repeats until the task is done.

**Activation:** the extension is dormant until it is needed. The UI tab's relay
content script discovers the server by itself and subscribes to a wake stream;
on the agent's first browser action the server pushes a wake signal down it,
starting the service worker. The agent then works in its own dedicated tab, and
releases it when the task ends. Both sides agree on one well-known session id
(`local`), so reloading the page never strands the extension.

```
Agent needs browser ──▶ server ──SSE──▶ UI tab relay ──▶ service worker
                                                              │
                                                     opens the agent tab
```

---

## Features

### Chrome Extension (Manifest V3)
- **Full automation** via `chrome.debugger` (CDP) so every click and keystroke
  is a **trusted** browser-level event that sites cannot distinguish from a
  real user: `navigate`, `click` (coordinates *or* CSS selector), `type`,
  `press_key`, `scroll`, `select_option`, `new_tab`, `switch_tab`, `close_tab`,
  `go_back`, `go_forward`, `screenshot`, `get_tree`, `evaluate_js`,
  `list_tabs`, `wait`, `get_page_info`.
- **Real-time screenshots** as base64 PNG, streamed over a persistent socket.
- **Visual feedback**: an animated coloured border around the controlled tab
  plus a floating *"AI Agent is working"* badge, rendered in a **closed shadow
  DOM** so page CSS cannot hide or restyle it.
- **On-demand activation**: the extension holds no connection at rest. When the
  agent needs the browser, the server signals the UI tab's relay content
  script, which wakes the service worker — so there is nothing to connect by
  hand and nothing running when you are not using it.
- **Dedicated agent tab**: the agent works in its own tab, reused across tasks,
  so it never hijacks the tab you are typing in and keeps its own session state.
- **UI-driven control**: connect, release, tab management, pause, stop and
  take-over are all driven from Streamlit. The popup is a status placeholder
  with an emergency stop.
- **Resilient**: exponential backoff with jitter, automatic re-handshake, and a
  keepalive alarm that runs only while a task is in flight.

### Vision Pipeline (OpenCV + Pillow + numpy)
- Decode base64 → OpenCV BGR (with a Pillow fallback for exotic encodings).
- **Resize** with `INTER_AREA` (preserves small UI text far better than
  bilinear), **CLAHE** contrast enhancement on the LAB L-channel, and optional
  bilateral denoising.
- **Exact coordinate mapping** across device-pixel-ratio *and* downscaling, so
  a point the model reads off the image lands on the right CSS pixel on HiDPI
  displays.
- **Annotation** for the UI and debugging: click crosshairs, labelled bounding
  boxes from the accessibility tree, translucent highlights, and a coordinate
  grid.
- Returns both the **raw** and **annotated** images to Streamlit.

### Agent (LangGraph + DeepAgents + Azure OpenAI)
- Built with `deepagents.create_deep_agent`, which layers planning, a
  scratchpad filesystem and sub-agents over a LangGraph ReAct loop.
- **Azure OpenAI** through `AzureChatOpenAI` (`langchain-openai`).
- A strict **Observe → Reason → Act** loop with a browser-optimised system
  prompt (one action per turn, verify before continuing, scroll to find,
  never invent credentials).
- **`ScreenshotMiddleware`** attaches the live viewport to every model call, so
  the LLM always reasons about current reality instead of a stale description.
- **`StopCheckMiddleware`** enforces pause, stop and the step budget *between*
  model calls, so the UI's controls feel instant.
- **Session memory** via a LangGraph checkpointer keyed on the session id.
- **Human-in-the-loop** through the `ask_user` tool, which suspends the run
  until the operator answers in Streamlit.

### Streamlit UI
- Chat interface for prompts, with the agent's reasoning and every tool call.
- **Live screenshot viewer** that updates after each action.
- **Browser panel**: connection state, agent tab id, open-tab and release
  controls — no pairing code to copy.
- **Start / Pause / Stop / Clear**, vision-mode switch and a step-budget slider.
- Secret-aware input: when the agent asks for a password or OTP, the reply box
  is masked automatically.

---

## Project structure

```
browser-agent/
├── extension/                  Chrome Extension (Manifest V3)
│   ├── manifest.json
│   ├── background.js           Service worker: socket + command dispatch
│   ├── lib/
│   │   ├── ws-client.js        Reconnecting WebSocket client
│   │   └── automation.js       CDP automation engine + a11y tree
│   ├── content/
│   │   ├── overlay.js          In-page visual feedback (closed shadow DOM)
│   │   └── relay.js            Wakes the worker on demand from the UI tab
│   ├── popup/                  Status placeholder + emergency stop
│   └── icons/
├── server/
│   ├── api/app.py              FastAPI: /ws/extension, /ws/ui, REST control
│   ├── agent/
│   │   ├── runner.py           Agent construction + streaming run loop
│   │   ├── browser_tools.py    LangChain tools bridged to the extension
│   │   ├── vision_middleware.py Screenshot injection + stop checks
│   │   └── prompts.py          Browser-optimised system prompt
│   ├── vision/pipeline.py      OpenCV processing + annotation
│   ├── sessions/               Session state, pairing, RPC bridge
│   ├── protocol.py             Shared wire protocol (pydantic)
│   └── config.py               Env-driven settings
├── ui/
│   ├── app.py                  Streamlit application
│   └── client.py               REST client
├── tests/
│   ├── test_bridge.py          Pairing + RPC + vision + UI stream
│   └── test_agent_flow.py      Full agent loop with a scripted model
├── run_server.py
├── requirements.txt
└── .env.example
```

---

## Setup

### Prerequisites
- **Python 3.11+**
- **Google Chrome 116+**
- An **Azure OpenAI** resource with a **vision-capable** deployment
  (`gpt-4o`, `gpt-4o-mini`, `gpt-4.1`, …)

### 1. Install dependencies

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
```

### 2. Configure Azure OpenAI

```bash
cp .env.example .env     # Windows: copy .env.example .env
```

Open `.env` and paste your key into `AZURE_OPENAI_API_KEY`.

Azure exposes **two endpoint shapes**. The server detects which one you have
and selects the matching client automatically.

**(a) v1 / OpenAI-compatible** — Microsoft Foundry style, ends in `/openai/v1`:

```ini
AZURE_OPENAI_ENDPOINT=https://your-resource.services.ai.azure.com/openai/v1
AZURE_OPENAI_API_KEY=your-key
AZURE_OPENAI_DEPLOYMENT=gpt-6-astra     # the DEPLOYMENT name, not the model
AZURE_OPENAI_API_MODE=auto
```

**(b) classic** — ends in `.openai.azure.com`:

```ini
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_API_KEY=your-key
AZURE_OPENAI_DEPLOYMENT=gpt-4o
AZURE_OPENAI_API_VERSION=2024-10-21
```

> **Why this matters:** the two surfaces route differently. A v1 endpoint takes
> the deployment as the `model` field (`POST .../openai/v1/chat/completions`),
> while a classic endpoint puts it in the path
> (`POST .../openai/deployments/<name>/chat/completions?api-version=...`).
> Passing a v1 endpoint to the classic client produces a broken doubled URL,
> so `AZURE_OPENAI_API_MODE=auto` picks the right one for you. Override with
> `v1` or `classic` only if detection ever guesses wrong.

> The deployment **must support vision**. A text-only deployment will fail once
> the first screenshot is attached.

Verify your configuration without starting the server:

```bash
python tests/check_azure_wiring.py
```

### 3. Start the server

```bash
python run_server.py
```

Verify it is healthy:

```bash
curl http://127.0.0.1:8000/health
# {"status":"ok", "azure_configured":true, ...}
```

### 4. Start the Streamlit UI

In a second terminal:

```bash
streamlit run ui/app.py
```

Open <http://localhost:8501>.

### 5. Load the Chrome extension

1. Go to `chrome://extensions`.
2. Enable **Developer mode** (top right).
3. Click **Load unpacked** and select the `extension/` folder.
4. Pin the extension so its popup is one click away.

### 6. Run

1. Open <http://localhost:8501> **in the Chrome window where you loaded the
   extension**. The sidebar should read *"Chrome detected · idle until the
   agent needs it"* — there is no pairing step.
2. Type a task in the Streamlit chat, e.g.
   *"Go to news.ycombinator.com and summarise the top 3 stories."*
3. The extension wakes, opens its own tab and starts working. Press
   **Release** in the sidebar when you want it to stand down.

> The UI must run in the same Chrome as the extension — it is what wakes the
> service worker. Opening the UI in a different browser leaves the agent with
> no way to reach Chrome.

---

## Usage notes

### Vision modes
| Mode | What the agent sees | Use when |
| --- | --- | --- |
| `hybrid` *(default)* | Screenshot **+** accessibility tree with CSS selectors | Almost always — the most reliable |
| `vision` | Screenshot only; clicks purely by coordinates | Canvas apps, or to test pure visual grounding |

### Controls
All day-to-day control lives in the Streamlit UI.

- **Pause** — the agent finishes the in-flight action then blocks. Resume to
  continue with full context.
- **Stop** — cancels the run and detaches the debugger from the tab.
- **Open tab** — opens (or recreates) the agent's dedicated tab.
- **Release** — detaches the debugger, closes the socket and lets the extension
  go dormant again.
- **Clear** — wipes the transcript and the agent's memory for that session.
- **Take over** (in-page badge) — immediately detaches control and tells the
  server the human has the wheel.
- **Emergency stop** (extension popup) — cuts browser control without going
  through the UI, for when the UI is unreachable.

### Safety
- The agent calls `ask_user` and waits for anything irreversible or sensitive:
  purchases, sending messages, deleting data, logins, OTP/2FA codes.
- `BLOCKED_DOMAINS` in `.env` is enforced server-side before any navigation.
- Only `http`, `https`, `about` and `file` schemes are allowed; `javascript:`
  and `data:` URLs are rejected even when written without `://`.
- `chrome://`, the Web Store and other privileged pages can never be attached.
- `AGENT_MAX_STEPS` caps browser actions per task to stop runaway loops.

---

## Configuration reference

All settings come from environment variables (see `.env.example`).

| Variable | Default | Purpose |
| --- | --- | --- |
| `AZURE_OPENAI_ENDPOINT` | — | Azure resource endpoint **(required)** |
| `AZURE_OPENAI_API_KEY` | — | API key **(required)** |
| `AZURE_OPENAI_DEPLOYMENT` | `gpt-4o` | Vision-capable deployment name |
| `AZURE_OPENAI_API_MODE` | `auto` | `auto` / `v1` / `classic` client selection |
| `AZURE_OPENAI_API_VERSION` | `2024-10-21` | API version (classic endpoint only) |
| `AZURE_OPENAI_TEMPERATURE` | *(empty)* | Lower is more deterministic. **Leave empty for reasoning models** (gpt-6/gpt-5/o-series) which reject it |
| `SERVER_HOST` / `SERVER_PORT` | `127.0.0.1` / `8000` | Bind address |
| `SERVER_PUBLIC_URL` | `http://127.0.0.1:8000` | URL handed to the UI/extension |
| `EXTENSION_AUTO_CONNECT` | `true` | Wake the extension from the UI instead of a typed code |
| `EXTENSION_WAKE_TIMEOUT` | `25` | Seconds a browser action waits for the woken extension |
| `AGENT_TAB_MODE` | `dedicated` | `dedicated` (own tab) or `active` (adopt the current tab) |
| `EXTENSION_RELEASE_ON_IDLE` | `true` | Release browser control when a task ends |
| `AGENT_MAX_STEPS` | `40` | Browser-action budget per task |
| `AGENT_RECURSION_LIMIT` | `150` | LangGraph model-turn limit |
| `BROWSER_RPC_TIMEOUT` | `45` | Seconds before one action fails |
| `VISION_MAX_WIDTH` | `1280` | Screenshot width sent to the model |
| `VISION_JPEG_QUALITY` | `85` | Encoding quality for model + UI |
| `VISION_ENHANCE_CONTRAST` | `true` | CLAHE contrast boost |
| `VISION_DENOISE` | `false` | Bilateral denoising |
| `VISION_MODE` | `hybrid` | `hybrid` or `vision` |
| `BLOCKED_DOMAINS` | *(empty)* | Comma-separated navigation blocklist |

---

## Testing

Both suites run without Azure credentials and without a real browser.

```bash
# Pairing, RPC bridge, OpenCV pipeline, UI event stream, security guards
python tests/test_bridge.py

# Full agent loop (LangGraph + tools + screenshot middleware) with a fake LLM
python tests/test_agent_flow.py

# Tool schemas are valid for function calling
python tests/check_schemas.py

# Endpoint detection builds the right client + URL (no Azure call)
python tests/check_azure_wiring.py

# about:blank is controllable; about:settings and chrome:// are not
python tests/check_blank_tab_guard.py

# Screenshots reach the UI after every action, at any poll rate
python tests/check_live_view.py

# The poll cursor never skips frames when the log prunes itself
python tests/check_event_cursor.py
```

These need a configured `.env` and make **real Azure calls**:

```bash
# Does your deployment support chat + vision + tool calling?
python tests/check_azure_live.py

# Full Observe -> Reason -> Act loop against a simulated page
python tests/check_full_loop.py
```

These drive the Streamlit UI and need a running server:

```bash
python tests/check_ondemand_wake.py  # dormant -> wake -> connect -> act
python tests/check_ui_autopair.py    # UI notices an extension that connects later
python tests/check_ui_adoption.py    # UI adopts a live extension automatically
python tests/check_live_task.py      # real task against your Chrome
```

---

## Troubleshooting

| Symptom | Cause / fix |
| --- | --- |
| *"Azure OpenAI is not configured"* | `.env` missing or unfilled. `/health` reports `api_key_set` / `endpoint_set` so you can see which. |
| `404 Resource not found` from Azure | Endpoint/client mismatch. Run `python tests/check_azure_wiring.py` and check the printed call URL — a doubled `/openai/v1/openai/deployments/` means the mode is wrong. Set `AZURE_OPENAI_API_MODE` explicitly. |
| `401 Unauthorized` from Azure | Wrong or expired key, or the key belongs to a different resource than the endpoint. |
| `DeploymentNotFound` | `AZURE_OPENAI_DEPLOYMENT` must be the **deployment** name from Foundry, not the base model name. |
| `Unsupported parameter: 'temperature'` | A reasoning deployment (gpt-6, gpt-5, o-series). Set `AZURE_OPENAI_TEMPERATURE=` (empty) in `.env` so the parameter is omitted. |
| *"Chrome extension not detected in this browser"* | The UI is open in a different browser (or profile) from the extension. Open <http://localhost:8501> in the Chrome window where you loaded `extension/`, then reload. If you just updated the extension, press **Reload** on `chrome://extensions` — the relay content script only runs on pages loaded after it. |
| Popup shows *"Idle"* and nothing happens | Normal at rest. If it stays idle during a task, reload the extension and the UI tab: a restarted server invalidates the stored details, and the extension re-requests them on the next wake. |
| Sidebar says *"Chrome detected"* but the agent never acts | The wake signal reached the relay but the worker did not connect. Open `chrome://extensions`, confirm the extension is enabled, and check its service-worker console for errors. |
| *"the Chrome extension did not respond to the wake signal"* | The worker failed to start or could not reach `SERVER_PUBLIC_URL`. Verify `/health` is reachable from the browser, then raise `EXTENSION_WAKE_TIMEOUT`. |
| Extension badge stays grey | Normal at rest — the badge only turns green while the agent is actually driving the browser. |
| Agent keeps opening new tabs | `AGENT_TAB_MODE` is not `dedicated`, or the agent tab was closed mid-task (it is recreated on the next action). |
| *"cannot control a protected page (about:blank)"* | Fixed — a blank tab is where the agent tab starts and is controllable. Reload the extension at `chrome://extensions` to pick up the change. |
| *"cannot control a protected page"* | The active tab is `chrome://`, the Web Store or a PDF. Switch to a normal page. |
| Live view freezes while the chat keeps moving | Fixed — the UI poll cursor is a frame sequence number, not a list index, so pruning old screenshots can no longer skip newer frames. |
| Clicks land in the wrong place | A stale screenshot. The agent should call `screenshot` or `get_tree`; coordinates must come from the newest image. |
| Debugger bar is distracting | Chrome always shows *"…is debugging this browser"* while `chrome.debugger` is attached. It disappears on Stop/Take over. |
| Model errors about images | The deployment is not vision-capable — use `gpt-4o` or similar. |
| Agent stops early | `AGENT_MAX_STEPS` was hit; raise it in `.env` or via the sidebar slider. |

---

## Security considerations

This system drives a browser that holds the user's **real logged-in sessions**.

- Run the server on `127.0.0.1` for personal use. If you host it remotely,
  terminate **TLS** (so the extension uses `wss://`) and put authentication in
  front of the REST API — pairing codes authenticate the *extension*, not the
  operator.
- Auto-connect does **not** remove the pairing code from the protocol; the
  server still issues one and the UI relay delivers it automatically. Anything
  that can read the agent UI page can therefore connect the extension, which is
  why the relay content script is scoped to `localhost`/`127.0.0.1` only. Set
  `EXTENSION_AUTO_CONNECT=false` to require a hand-entered code instead.
- Secrets live only in environment variables; nothing is written to disk.
- `evaluate_js` executes arbitrary JavaScript in the page. Add it to
  `REQUIRE_APPROVAL_TOOLS` or remove it from the toolkit in hardened
  deployments.
- Screenshots of the user's tabs are sent to Azure OpenAI. Make sure that is
  acceptable for your data-handling policy before pointing the agent at
  sensitive sites.
- Review `BLOCKED_DOMAINS` before giving the agent access to a machine with
  banking or admin sessions.

---

## License

Provided as-is for you to adapt. Review the security notes before any
multi-user or production deployment.
