"""A paired browser session: WebSocket transport, RPC bridge and event fan-out."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import time
from dataclasses import dataclass, field
from typing import Any

from fastapi import WebSocket

from server.protocol import (
    BrowserAction,
    Command,
    Control,
    Event,
    SessionStatus,
    Stream,
    StreamEvent,
    now_ms,
)

logger = logging.getLogger(__name__)

# Events that should never be dropped even when a UI client is slow.
_CRITICAL_EVENTS = {StreamEvent.STATUS, StreamEvent.ERROR, StreamEvent.HUMAN_INPUT_REQUEST}


class BrowserBridgeError(RuntimeError):
    """Raised when a browser command fails, times out or is cancelled."""


@dataclass(slots=True)
class PendingCall:
    """Bookkeeping for one in-flight RPC."""

    future: asyncio.Future[dict[str, Any]]
    action: str
    started_at: float = field(default_factory=time.monotonic)


class Session:
    """Owns one extension connection plus any attached UI observers.

    The session is the single synchronisation point between:
      * the Chrome extension socket (command/result RPC),
      * the agent coroutine (issues commands, reads screenshots),
      * UI sockets (receive a read-only event stream).
    """

    def __init__(self, session_id: str, pairing_code: str) -> None:
        self.id = session_id
        self.pairing_code = pairing_code
        self.status: SessionStatus = SessionStatus.IDLE

        # Transport
        self._ext_ws: WebSocket | None = None
        self._ui_sockets: set[WebSocket] = set()
        self._send_lock = asyncio.Lock()

        # On-demand wake: relays are long-poll/SSE subscribers living in the
        # UI tab, which is the only thing that can reach a dormant MV3 worker.
        self._relays: set[asyncio.Queue[dict[str, Any]]] = set()
        self._ext_connected = asyncio.Event()
        self._wake_lock = asyncio.Lock()
        self.wake_timeout: float = 25.0

        # RPC bookkeeping
        self._pending: dict[str, PendingCall] = {}

        # Control flags
        self._pause_event = asyncio.Event()
        self._pause_event.set()  # not paused
        self._stop_requested = False

        # Human-in-the-loop
        self._human_future: asyncio.Future[str] | None = None
        self._human_question: str | None = None

        # Agent task handle
        self.agent_task: asyncio.Task[Any] | None = None

        # Observable state
        self.paired_at: int | None = None
        self.current_task: str | None = None
        self.steps_taken: int = 0
        self.last_error: str | None = None
        self.page_url: str | None = None
        self.page_title: str | None = None
        self.extension_version: str = ""
        # Id of the dedicated tab the agent drives, as reported by the extension.
        self.agent_tab_id: int | None = None

        # Most recent screenshot payload pushed by the extension.
        self.last_screenshot: dict[str, Any] | None = None
        # Rolling transcript mirrored to late-joining UI clients.
        self.event_log: list[dict[str, Any]] = []
        self.max_event_log = 400
        # Monotonic frame counter; the UI's poll cursor tracks this, not an
        # index, so trimming the log never strands a client.
        self._seq = 0

    # ------------------------------------------------------------------ #
    # Connection lifecycle
    # ------------------------------------------------------------------ #
    @property
    def extension_connected(self) -> bool:
        return self._ext_ws is not None

    def attach_extension(self, ws: WebSocket, *, version: str = "") -> None:
        self._ext_ws = ws
        self.extension_version = version
        self.paired_at = now_ms()
        self._ext_connected.set()
        if self.status is SessionStatus.ERROR:
            self.status = SessionStatus.IDLE

    def detach_extension(self, ws: WebSocket | None = None) -> None:
        """Drop the extension socket and fail every in-flight RPC."""
        if ws is not None and self._ext_ws is not ws:
            return  # a newer connection already replaced this one
        self._ext_ws = None
        self._ext_connected.clear()
        self._fail_all_pending("extension disconnected")

    # ------------------------------------------------------------------ #
    # On-demand wake
    # ------------------------------------------------------------------ #
    @property
    def relay_connected(self) -> bool:
        """True when a UI tab is able to wake the extension."""
        return bool(self._relays)

    def attach_relay(self) -> asyncio.Queue[dict[str, Any]]:
        """Register a wake relay (the UI tab's content script)."""
        queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=16)
        self._relays.add(queue)
        return queue

    def detach_relay(self, queue: asyncio.Queue[dict[str, Any]]) -> None:
        self._relays.discard(queue)

    def signal_relays(self, signal: str, payload: dict[str, Any] | None = None) -> int:
        """Push a signal to every relay. Returns how many received it."""
        frame = {"signal": signal, "payload": payload or {}, "ts": now_ms()}
        delivered = 0
        for queue in list(self._relays):
            try:
                queue.put_nowait(frame)
                delivered += 1
            except asyncio.QueueFull:
                # A wedged relay must never block the agent.
                self._relays.discard(queue)
        return delivered

    async def ensure_extension(self, timeout: float = 25.0) -> None:
        """Wake the extension on demand and wait until its socket is live.

        The server cannot dial into an MV3 service worker, so it asks the UI
        tab's content script to do it. Raises :class:`BrowserBridgeError` when
        no relay exists or the extension does not appear in time.
        """
        if self.extension_connected:
            return

        # One waker at a time, so a burst of tool calls wakes the worker once.
        async with self._wake_lock:
            if self.extension_connected:
                return

            if not self._relays:
                raise BrowserBridgeError(
                    "Chrome cannot be reached. Open the agent UI in the same "
                    "Chrome window that has the AI Browser Agent extension "
                    "installed, then try again."
                )

            self.signal_relays("wake", {"session_id": self.id})
            try:
                await asyncio.wait_for(self._ext_connected.wait(), timeout=timeout)
            except TimeoutError as exc:
                raise BrowserBridgeError(
                    "the Chrome extension did not respond to the wake signal "
                    f"within {timeout:.0f}s. Check that it is installed and "
                    "enabled in this browser."
                ) from exc

    def attach_ui(self, ws: WebSocket) -> None:
        self._ui_sockets.add(ws)

    def detach_ui(self, ws: WebSocket) -> None:
        self._ui_sockets.discard(ws)

    def _fail_all_pending(self, reason: str) -> None:
        for call_id, pending in list(self._pending.items()):
            if not pending.future.done():
                pending.future.set_exception(BrowserBridgeError(reason))
            self._pending.pop(call_id, None)

    # ------------------------------------------------------------------ #
    # Extension RPC
    # ------------------------------------------------------------------ #
    async def call(
        self,
        action: BrowserAction | str,
        params: dict[str, Any] | None = None,
        *,
        timeout: float = 45.0,
    ) -> dict[str, Any]:
        """Send a command to the extension and await its result.

        Raises:
            BrowserBridgeError: on disconnect, timeout, stop request, or when
                the extension reports a failure.
        """
        if self._stop_requested:
            raise BrowserBridgeError("task stopped by user")

        # Block here while the user has paused the run.
        await self._pause_event.wait()

        if self._stop_requested:
            raise BrowserBridgeError("task stopped by user")

        # First browser action of a task wakes the dormant extension.
        if self._ext_ws is None:
            await self.ensure_extension(timeout=self.wake_timeout)

        ws = self._ext_ws
        if ws is None:
            raise BrowserBridgeError("Chrome extension is not connected.")

        action_value = action.value if isinstance(action, BrowserAction) else str(action)
        cmd = Command(
            action=action_value,  # type: ignore[arg-type]
            params=params or {},
            timeout_ms=int(timeout * 1000),
        )
        loop = asyncio.get_running_loop()
        future: asyncio.Future[dict[str, Any]] = loop.create_future()
        self._pending[cmd.id] = PendingCall(future=future, action=action_value)

        try:
            await self._send_to_extension(cmd.model_dump(mode="json"))
        except Exception as exc:  # noqa: BLE001 - normalised into bridge error
            self._pending.pop(cmd.id, None)
            raise BrowserBridgeError(f"failed to send {action_value}: {exc}") from exc

        try:
            return await asyncio.wait_for(future, timeout=timeout)
        except TimeoutError as exc:
            raise BrowserBridgeError(
                f"browser action {action_value!r} timed out after {timeout:.0f}s"
            ) from exc
        finally:
            self._pending.pop(cmd.id, None)

    def resolve(self, call_id: str, ok: bool, data: dict[str, Any], error: str | None) -> None:
        """Complete a pending RPC from an incoming ``result`` frame."""
        pending = self._pending.pop(call_id, None)
        if pending is None or pending.future.done():
            return
        if ok:
            pending.future.set_result(data or {})
        else:
            pending.future.set_exception(
                BrowserBridgeError(error or f"{pending.action} failed")
            )

    async def _send_to_extension(self, frame: dict[str, Any]) -> None:
        ws = self._ext_ws
        if ws is None:
            raise BrowserBridgeError("extension not connected")
        async with self._send_lock:
            await ws.send_json(frame)

    async def send_control(self, signal: str, payload: dict[str, Any] | None = None) -> None:
        """Best-effort control signal to the extension (badge, pause, stop)."""
        if self._ext_ws is None:
            return
        with contextlib.suppress(Exception):
            await self._send_to_extension(
                Control(signal=signal, payload=payload or {}).model_dump(mode="json")
            )

    # ------------------------------------------------------------------ #
    # Run control (pause / resume / stop)
    # ------------------------------------------------------------------ #
    @property
    def is_paused(self) -> bool:
        return not self._pause_event.is_set()

    @property
    def stop_requested(self) -> bool:
        return self._stop_requested

    async def pause(self) -> None:
        if self.status in (SessionStatus.RUNNING, SessionStatus.AWAITING_HUMAN):
            self._pause_event.clear()
            self.status = SessionStatus.PAUSED
            await self.send_control("pause")
            await self.broadcast_status()

    async def resume(self) -> None:
        self._pause_event.set()
        if self.status is SessionStatus.PAUSED:
            self.status = SessionStatus.RUNNING
        await self.send_control("resume")
        await self.broadcast_status()

    async def stop(self) -> None:
        """Request cancellation of the running agent task."""
        self._stop_requested = True
        self.status = SessionStatus.STOPPING
        # Release any coroutine blocked on the pause gate so it can observe the
        # stop flag and unwind.
        self._pause_event.set()
        self._fail_all_pending("task stopped by user")
        if self._human_future is not None and not self._human_future.done():
            self._human_future.cancel()
        if self.agent_task is not None and not self.agent_task.done():
            self.agent_task.cancel()
        await self.send_control("stop")
        await self.broadcast_status()

    def begin_task(self, prompt: str) -> None:
        """Reset per-run counters before the agent starts."""
        self._stop_requested = False
        self._pause_event.set()
        self.current_task = prompt
        self.steps_taken = 0
        self.last_error = None
        self.status = SessionStatus.RUNNING

    def finish_task(self, status: SessionStatus, error: str | None = None) -> None:
        self.status = status
        self.last_error = error
        self.agent_task = None
        self._stop_requested = False
        self._pause_event.set()

    # ------------------------------------------------------------------ #
    # Human-in-the-loop
    # ------------------------------------------------------------------ #
    async def ask_human(self, question: str, *, timeout: float = 600.0) -> str:
        """Pause the run and wait for the user to answer via the UI."""
        loop = asyncio.get_running_loop()
        self._human_future = loop.create_future()
        self._human_question = question
        previous_status = self.status
        self.status = SessionStatus.AWAITING_HUMAN
        await self.broadcast(
            StreamEvent.HUMAN_INPUT_REQUEST, {"question": question}
        )
        await self.broadcast_status()
        try:
            return await asyncio.wait_for(self._human_future, timeout=timeout)
        except TimeoutError:
            return "(no response from user within the time limit)"
        except asyncio.CancelledError:
            raise
        finally:
            self._human_future = None
            self._human_question = None
            if self.status is SessionStatus.AWAITING_HUMAN:
                self.status = (
                    SessionStatus.RUNNING
                    if previous_status is SessionStatus.RUNNING
                    else previous_status
                )

    @property
    def pending_question(self) -> str | None:
        return self._human_question

    def provide_human_reply(self, reply: str) -> bool:
        """Deliver a user answer to a waiting ``ask_human`` call."""
        if self._human_future is None or self._human_future.done():
            return False
        self._human_future.set_result(reply)
        return True

    # ------------------------------------------------------------------ #
    # UI broadcast
    # ------------------------------------------------------------------ #
    async def broadcast(
        self, event: StreamEvent, payload: dict[str, Any] | None = None
    ) -> None:
        """Fan a frame out to every attached UI socket, pruning dead ones."""
        frame = Stream(
            event=event, session_id=self.id, payload=payload or {}
        ).model_dump(mode="json")
        self._record(frame)
        if not self._ui_sockets:
            return
        dead: list[WebSocket] = []
        for ws in list(self._ui_sockets):
            try:
                await ws.send_json(frame)
            except Exception:  # noqa: BLE001 - socket is gone, drop it
                dead.append(ws)
        for ws in dead:
            self._ui_sockets.discard(ws)

    async def broadcast_status(self) -> None:
        await self.broadcast(StreamEvent.STATUS, self.status_payload())

    def status_payload(self) -> dict[str, Any]:
        return {
            "session_id": self.id,
            "status": self.status.value,
            "extension_connected": self.extension_connected,
            "relay_connected": self.relay_connected,
            "agent_tab_id": self.agent_tab_id,
            "paired_at": self.paired_at,
            "current_task": self.current_task,
            "steps_taken": self.steps_taken,
            "last_error": self.last_error,
            "page_url": self.page_url,
            "page_title": self.page_title,
            "paused": self.is_paused,
            "pending_question": self._human_question,
        }

    def _record(self, frame: dict[str, Any]) -> None:
        """Keep a bounded transcript so late UI clients can replay context.

        Frames carry a monotonic ``seq``: the UI polls with ``since=<last seq>``
        rather than a list index, so pruning old entries can never hide a newer
        one behind a cursor that did not advance.
        """
        event = frame.get("event")
        self._seq += 1
        frame["seq"] = self._seq

        # Screenshots are heavy, but dropping the *entry* would shift every
        # later frame. Blank the payload instead and keep the frame in place.
        if event == StreamEvent.SCREENSHOT.value:
            for old in self.event_log:
                if old.get("event") == StreamEvent.SCREENSHOT.value:
                    payload = old.get("payload")
                    if isinstance(payload, dict) and payload.get("image"):
                        payload["image"] = None
                        payload["pruned"] = True
        self.event_log.append(frame)
        if len(self.event_log) > self.max_event_log:
            # Preserve critical frames when trimming.
            overflow = len(self.event_log) - self.max_event_log
            trimmed: list[dict[str, Any]] = []
            removed = 0
            for f in self.event_log:
                if removed < overflow and f.get("event") not in {
                    e.value for e in _CRITICAL_EVENTS
                }:
                    removed += 1
                    continue
                trimmed.append(f)
            self.event_log = trimmed[-self.max_event_log :]

    # ------------------------------------------------------------------ #
    # Extension events
    # ------------------------------------------------------------------ #
    def record_event(self, event: Event) -> None:
        """Update cached page state from an unsolicited extension event."""
        payload = event.payload or {}
        if event.name in ("screenshot", "page_state"):
            if payload.get("image"):
                self.last_screenshot = payload
            self.page_url = payload.get("url") or self.page_url
            self.page_title = payload.get("title") or self.page_title
        elif event.name == "tab_changed":
            self.page_url = payload.get("url") or self.page_url
            self.page_title = payload.get("title") or self.page_title
