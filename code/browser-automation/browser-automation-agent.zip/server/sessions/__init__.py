"""Session state, pairing and the extension RPC bridge."""

from server.sessions.manager import SessionManager, get_session_manager
from server.sessions.session import BrowserBridgeError, Session

__all__ = [
    "BrowserBridgeError",
    "Session",
    "SessionManager",
    "get_session_manager",
]
