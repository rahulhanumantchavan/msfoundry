"""Session registry and pairing-code issuance."""

from __future__ import annotations

import asyncio
import logging
import secrets
import time
from dataclasses import dataclass

from server.protocol import new_id
from server.sessions.session import Session

logger = logging.getLogger(__name__)

# Unambiguous alphabet (no O/0/I/1) so codes are easy to read and retype.
_CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
_CODE_LENGTH = 6
_CODE_TTL_SECONDS = 15 * 60

# Well-known id for the single local browser session, so the UI and the
# extension can agree on it without a pairing handshake.
DEFAULT_SESSION_ID = "local"


@dataclass(slots=True)
class PairingTicket:
    """A short-lived code that an extension exchanges for a session."""

    code: str
    session_id: str
    created_at: float
    used: bool = False

    @property
    def expired(self) -> bool:
        return (time.time() - self.created_at) > _CODE_TTL_SECONDS


class SessionManager:
    """Owns every live :class:`Session` and the pairing handshake."""

    def __init__(self) -> None:
        self._sessions: dict[str, Session] = {}
        self._tickets: dict[str, PairingTicket] = {}
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------ #
    # Pairing
    # ------------------------------------------------------------------ #
    def _generate_code(self) -> str:
        while True:
            code = "".join(secrets.choice(_CODE_ALPHABET) for _ in range(_CODE_LENGTH))
            if code not in self._tickets:
                return code

    def create_pairing(self, session_id: str | None = None) -> PairingTicket:
        """Mint a new pairing code (and session shell) for the UI to display."""
        self._purge_expired()
        sid = session_id or new_id()[:12]
        code = self._generate_code()
        ticket = PairingTicket(code=code, session_id=sid, created_at=time.time())
        self._tickets[code] = ticket
        if sid not in self._sessions:
            self._sessions[sid] = Session(sid, code)
        logger.info("issued pairing code %s for session %s", code, sid)
        return ticket

    def ensure_default_pairing(self) -> PairingTicket:
        """Return the shared local session's ticket, creating it once.

        On-demand wake has no pairing step, so the UI and extension need a
        session id they can both arrive at independently. The ticket is
        refreshed rather than reissued so the id survives page reloads.
        """
        self._purge_expired()
        for ticket in self._tickets.values():
            if ticket.session_id == DEFAULT_SESSION_ID and not ticket.expired:
                ticket.created_at = time.time()  # keep it alive while in use
                return ticket
        return self.create_pairing(DEFAULT_SESSION_ID)

    def redeem_pairing(self, code: str) -> Session | None:
        """Exchange a pairing code for its session.

        Codes are single-use for a *new* pairing, but the same extension may
        reconnect with the same code after a transient socket drop, so a used
        ticket still resolves while it has not expired.
        """
        self._purge_expired()
        normalized = (code or "").strip().upper().replace("-", "").replace(" ", "")
        ticket = self._tickets.get(normalized)
        if ticket is None or ticket.expired:
            return None
        ticket.used = True
        # Refresh TTL so a long-running session is not dropped mid-task.
        ticket.created_at = time.time()
        return self._sessions.get(ticket.session_id)

    def _purge_expired(self) -> None:
        for code, ticket in list(self._tickets.items()):
            if ticket.expired:
                self._tickets.pop(code, None)

    # ------------------------------------------------------------------ #
    # Session access
    # ------------------------------------------------------------------ #
    def get(self, session_id: str) -> Session | None:
        return self._sessions.get(session_id)

    def get_or_create(self, session_id: str) -> Session:
        session = self._sessions.get(session_id)
        if session is None:
            session = Session(session_id, pairing_code="")
            self._sessions[session_id] = session
        return session

    def list_sessions(self) -> list[Session]:
        return list(self._sessions.values())

    async def remove(self, session_id: str) -> None:
        session = self._sessions.pop(session_id, None)
        if session is None:
            return
        if session.agent_task is not None and not session.agent_task.done():
            session.agent_task.cancel()
        session.detach_extension()
        for code, ticket in list(self._tickets.items()):
            if ticket.session_id == session_id:
                self._tickets.pop(code, None)

    def code_for(self, session_id: str) -> str | None:
        for ticket in self._tickets.values():
            if ticket.session_id == session_id and not ticket.expired:
                return ticket.code
        return None


_manager: SessionManager | None = None


def get_session_manager() -> SessionManager:
    """Process-wide session manager singleton."""
    global _manager
    if _manager is None:
        _manager = SessionManager()
    return _manager
