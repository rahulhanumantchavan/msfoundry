"""Central configuration loaded from environment variables.

All secrets (Azure OpenAI endpoint, key, deployment) must be supplied via the
environment or a local ``.env`` file. Nothing sensitive is ever hard-coded.
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# Load the repository-root .env before Settings is instantiated so that plain
# os.environ lookups elsewhere (e.g. langchain internals) also see the values.
_REPO_ROOT = Path(__file__).resolve().parent.parent
load_dotenv(_REPO_ROOT / ".env", override=False)


class Settings(BaseSettings):
    """Runtime settings for the browser-agent server."""

    model_config = SettingsConfigDict(
        env_file=str(_REPO_ROOT / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # ---- Azure OpenAI -----------------------------------------------------
    azure_openai_endpoint: str = Field(default="", alias="AZURE_OPENAI_ENDPOINT")
    azure_openai_api_key: str = Field(default="", alias="AZURE_OPENAI_API_KEY")
    azure_openai_deployment: str = Field(
        default="gpt-4o", alias="AZURE_OPENAI_DEPLOYMENT"
    )
    azure_openai_api_version: str = Field(
        default="2024-10-21", alias="AZURE_OPENAI_API_VERSION"
    )
    # Reasoning models (o-series, gpt-5/6 family) reject `temperature`.
    # Leave empty to omit the parameter entirely.
    azure_openai_temperature: float | None = Field(
        default=None, alias="AZURE_OPENAI_TEMPERATURE"
    )
    # "auto" picks the client from the endpoint shape; force with
    # "v1" (OpenAI-compatible) or "classic" (deployment-path) if needed.
    azure_openai_api_mode: str = Field(default="auto", alias="AZURE_OPENAI_API_MODE")

    # ---- Server -----------------------------------------------------------
    server_host: str = Field(default="127.0.0.1", alias="SERVER_HOST")
    server_port: int = Field(default=8000, alias="SERVER_PORT")
    server_public_url: str = Field(
        default="http://127.0.0.1:8000", alias="SERVER_PUBLIC_URL"
    )

    # ---- Extension connection --------------------------------------------
    # On-demand wake: the extension stays dormant until the agent actually
    # needs the browser, then the UI tab's content script relays a wake signal.
    extension_auto_connect: bool = Field(
        default=True, alias="EXTENSION_AUTO_CONNECT"
    )
    # How long a browser call waits for a woken extension to finish connecting.
    extension_wake_timeout: float = Field(
        default=25.0, alias="EXTENSION_WAKE_TIMEOUT"
    )
    # "dedicated" => the agent always drives its own tab; "active" => it adopts
    # whichever tab the user is looking at (legacy behaviour).
    agent_tab_mode: str = Field(default="dedicated", alias="AGENT_TAB_MODE")
    # Release the debugger and close the socket when a task ends.
    extension_release_on_idle: bool = Field(
        default=True, alias="EXTENSION_RELEASE_ON_IDLE"
    )

    # ---- Agent behaviour --------------------------------------------------
    agent_max_steps: int = Field(default=40, alias="AGENT_MAX_STEPS")
    agent_recursion_limit: int = Field(default=150, alias="AGENT_RECURSION_LIMIT")
    # Hard ceiling for how long a single browser RPC may take.
    browser_rpc_timeout: float = Field(default=45.0, alias="BROWSER_RPC_TIMEOUT")

    # ---- Vision pipeline --------------------------------------------------
    # Screenshots are downscaled to this width before being sent to the model.
    vision_max_width: int = Field(default=1280, alias="VISION_MAX_WIDTH")
    vision_jpeg_quality: int = Field(default=85, alias="VISION_JPEG_QUALITY")
    vision_enhance_contrast: bool = Field(
        default=True, alias="VISION_ENHANCE_CONTRAST"
    )
    vision_denoise: bool = Field(default=False, alias="VISION_DENOISE")
    # "vision" => coordinates only, "hybrid" => coordinates + accessibility tree
    vision_mode: str = Field(default="hybrid", alias="VISION_MODE")

    # ---- Safety -----------------------------------------------------------
    # Comma separated list of domains the agent may never navigate to.
    blocked_domains: str = Field(default="", alias="BLOCKED_DOMAINS")
    # Require explicit human approval for these tools.
    require_approval_tools: str = Field(
        default="", alias="REQUIRE_APPROVAL_TOOLS"
    )

    @field_validator("azure_openai_temperature", mode="before")
    @classmethod
    def _blank_temperature_is_none(cls, value: Any) -> Any:
        """Treat an empty/unset env value as "do not send temperature".

        Reasoning deployments reject the parameter outright, so operators need
        a way to omit it rather than pick a number.
        """
        if value is None:
            return None
        if isinstance(value, str) and not value.strip():
            return None
        return value

    @property
    def blocked_domain_list(self) -> list[str]:
        return [d.strip().lower() for d in self.blocked_domains.split(",") if d.strip()]

    @property
    def approval_tool_list(self) -> list[str]:
        return [
            t.strip() for t in self.require_approval_tools.split(",") if t.strip()
        ]

    @property
    def azure_configured(self) -> bool:
        return bool(self.azure_openai_endpoint and self.azure_openai_api_key)

    @property
    def uses_v1_endpoint(self) -> bool:
        """True when the endpoint is Azure's OpenAI-compatible ``/openai/v1`` surface.

        Azure exposes two shapes:

        * classic   ``https://<res>.openai.azure.com/``
          -> deployment is part of the path, needs ``AzureChatOpenAI``.
        * v1        ``https://<res>.services.ai.azure.com/openai/v1``
          -> OpenAI-compatible; the deployment travels as the ``model`` field.

        Passing a v1 endpoint to ``AzureChatOpenAI`` silently produces a broken
        doubled URL (``/openai/v1/openai/deployments/...``), so the client type
        is selected from the endpoint shape.
        """
        mode = (self.azure_openai_api_mode or "auto").strip().lower()
        if mode == "v1":
            return True
        if mode == "classic":
            return False
        return self.azure_openai_endpoint.rstrip("/").endswith("/openai/v1")


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return the process-wide settings singleton."""
    return Settings()  # type: ignore[call-arg]


def reload_settings() -> Settings:
    """Clear the cache and re-read the environment (used by tests/dev reload)."""
    get_settings.cache_clear()
    load_dotenv(_REPO_ROOT / ".env", override=True)
    os.environ.setdefault("PYTHONUNBUFFERED", "1")
    return get_settings()
