"""Wire protocol shared by the Chrome extension, FastAPI server and Streamlit UI.

Two WebSocket channels exist:

1. ``/ws/extension``  – the Chrome extension connects here. The server issues
   ``command`` frames (RPC requests) and the extension answers with ``result``
   frames carrying the same ``id``. The extension also pushes unsolicited
   ``event`` frames (screenshots, tab changes, user takeover...).
2. ``/ws/ui``        – the Streamlit UI (or any observer) subscribes here to
   receive a read-only stream of agent/browser events.

Every frame is a JSON object with a mandatory ``type`` discriminator.
"""

from __future__ import annotations

import time
import uuid
from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, Field


def new_id() -> str:
    return uuid.uuid4().hex


def now_ms() -> int:
    return int(time.time() * 1000)


# --------------------------------------------------------------------------- #
# Enumerations
# --------------------------------------------------------------------------- #
class FrameType(StrEnum):
    """Top-level discriminator for every WebSocket frame."""

    # extension -> server
    HELLO = "hello"
    RESULT = "result"
    EVENT = "event"
    PONG = "pong"
    # server -> extension
    WELCOME = "welcome"
    COMMAND = "command"
    PING = "ping"
    CONTROL = "control"
    # server -> ui
    STREAM = "stream"


class BrowserAction(StrEnum):
    """Every automation primitive the extension implements."""

    NAVIGATE = "navigate"
    CLICK = "click"
    TYPE = "type"
    PRESS_KEY = "press_key"
    SCROLL = "scroll"
    SELECT_OPTION = "select_option"
    NEW_TAB = "new_tab"
    SWITCH_TAB = "switch_tab"
    CLOSE_TAB = "close_tab"
    GO_BACK = "go_back"
    GO_FORWARD = "go_forward"
    SCREENSHOT = "screenshot"
    GET_TREE = "get_tree"
    EVALUATE_JS = "evaluate_js"
    LIST_TABS = "list_tabs"
    WAIT = "wait"
    GET_PAGE_INFO = "get_page_info"


class SessionStatus(StrEnum):
    IDLE = "idle"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPING = "stopping"
    DONE = "done"
    ERROR = "error"
    AWAITING_HUMAN = "awaiting_human"


class StreamEvent(StrEnum):
    """Event names published to the UI channel."""

    AGENT_MESSAGE = "agent_message"
    AGENT_THINKING = "agent_thinking"
    TOOL_CALL = "tool_call"
    TOOL_RESULT = "tool_result"
    SCREENSHOT = "screenshot"
    STATUS = "status"
    ERROR = "error"
    PAIRING = "pairing"
    PLAN = "plan"
    HUMAN_INPUT_REQUEST = "human_input_request"


# --------------------------------------------------------------------------- #
# Frames
# --------------------------------------------------------------------------- #
class Hello(BaseModel):
    """First frame the extension sends after the socket opens."""

    type: Literal[FrameType.HELLO] = FrameType.HELLO
    pairing_code: str
    extension_version: str = "0.0.0"
    user_agent: str = ""
    capabilities: list[str] = Field(default_factory=list)


class Welcome(BaseModel):
    """Server acknowledgement of a successful pairing."""

    type: Literal[FrameType.WELCOME] = FrameType.WELCOME
    session_id: str
    server_time: int = Field(default_factory=now_ms)
    heartbeat_interval_ms: int = 20_000


class Command(BaseModel):
    """An RPC request from server to extension."""

    type: Literal[FrameType.COMMAND] = FrameType.COMMAND
    id: str = Field(default_factory=new_id)
    action: BrowserAction
    params: dict[str, Any] = Field(default_factory=dict)
    timeout_ms: int = 45_000


class Result(BaseModel):
    """Extension's answer to a :class:`Command`."""

    type: Literal[FrameType.RESULT] = FrameType.RESULT
    id: str
    ok: bool
    data: dict[str, Any] = Field(default_factory=dict)
    error: str | None = None
    duration_ms: int = 0


class Event(BaseModel):
    """Unsolicited push from the extension (screenshot, takeover, tab change)."""

    type: Literal[FrameType.EVENT] = FrameType.EVENT
    name: str
    payload: dict[str, Any] = Field(default_factory=dict)
    ts: int = Field(default_factory=now_ms)


class Control(BaseModel):
    """Server -> extension control signal (pause / resume / stop / badge)."""

    type: Literal[FrameType.CONTROL] = FrameType.CONTROL
    signal: str
    payload: dict[str, Any] = Field(default_factory=dict)


class Stream(BaseModel):
    """Server -> UI broadcast frame."""

    type: Literal[FrameType.STREAM] = FrameType.STREAM
    event: StreamEvent
    session_id: str
    payload: dict[str, Any] = Field(default_factory=dict)
    ts: int = Field(default_factory=now_ms)


# --------------------------------------------------------------------------- #
# REST payloads
# --------------------------------------------------------------------------- #
class StartTaskRequest(BaseModel):
    session_id: str
    prompt: str
    vision_mode: str | None = None
    max_steps: int | None = None


class HumanReplyRequest(BaseModel):
    session_id: str
    reply: str


class SessionSummary(BaseModel):
    session_id: str
    status: SessionStatus
    extension_connected: bool
    paired_at: int | None = None
    current_task: str | None = None
    steps_taken: int = 0
    last_error: str | None = None
    page_url: str | None = None
    page_title: str | None = None
