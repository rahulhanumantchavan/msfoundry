"""Middleware that keeps the model's view of the browser fresh and bounded.

Two concerns are handled here:

``ScreenshotMiddleware``
    Before every model call, attach the most recent processed screenshot as an
    image content block, so the LLM always reasons about the *current* viewport
    rather than a stale description.

``StopCheckMiddleware``
    Honour pause/stop requests between model calls so a running task reacts to
    the UI immediately instead of only between tool calls.
"""

from __future__ import annotations

import logging
from typing import Any

from langchain.agents.middleware import AgentMiddleware, ModelRequest
from langchain_core.messages import HumanMessage

from server.agent.browser_tools import BrowserToolkit
from server.sessions.session import BrowserBridgeError, Session

logger = logging.getLogger(__name__)


class ScreenshotMiddleware(AgentMiddleware):
    """Injects the latest screenshot into each model request."""

    def __init__(self, toolkit: BrowserToolkit, *, jpeg_quality: int = 85) -> None:
        super().__init__()
        self.toolkit = toolkit
        self.jpeg_quality = jpeg_quality

    async def awrap_model_call(self, request: ModelRequest, handler):  # type: ignore[override]
        shot = self.toolkit.latest
        if shot is None:
            # First turn of a run: grab an initial frame so the model starts
            # with a real observation instead of a blank slate.
            try:
                shot = await self.toolkit._capture()  # noqa: SLF001 - same package
            except BrowserBridgeError as exc:
                logger.debug("initial capture failed: %s", exc)
                shot = None

        if shot is not None:
            b64 = shot.base64_model(fmt="jpeg", quality=self.jpeg_quality)
            observation = HumanMessage(
                content=[
                    {
                        "type": "text",
                        "text": (
                            "Current browser viewport "
                            f"({shot.width}x{shot.height} image, "
                            f"{shot.css_width}x{shot.css_height} CSS px).\n"
                            f"URL: {shot.url or 'unknown'}\n"
                            f"Title: {shot.title or 'unknown'}\n"
                            "Click coordinates must be read from THIS image."
                        ),
                    },
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{b64}"},
                    },
                ]
            )
            request = request.override(messages=[*request.messages, observation])

        return await handler(request)


class StopCheckMiddleware(AgentMiddleware):
    """Blocks on pause and aborts the run when the user pressed Stop."""

    def __init__(self, session: Session, max_steps: int) -> None:
        super().__init__()
        self.session = session
        self.max_steps = max_steps

    async def awrap_model_call(self, request: ModelRequest, handler):  # type: ignore[override]
        if self.session.stop_requested:
            raise BrowserBridgeError("task stopped by user")
        # Wait out any active pause before spending a model call.
        await self.session._pause_event.wait()  # noqa: SLF001 - same package
        if self.session.stop_requested:
            raise BrowserBridgeError("task stopped by user")
        if self.session.steps_taken > self.max_steps:
            raise BrowserBridgeError(
                f"step budget exhausted ({self.max_steps} browser actions)"
            )
        return await handler(request)


def strip_old_images(messages: list[Any], *, keep_last: int = 2) -> list[Any]:
    """Remove image blocks from all but the newest ``keep_last`` observations.

    Screenshots dominate token cost; older frames add little once the agent has
    acted on them. Each stripped message keeps its text so the narrative of the
    run stays intact.
    """
    image_indices = [
        i
        for i, m in enumerate(messages)
        if isinstance(getattr(m, "content", None), list)
        and any(
            isinstance(b, dict) and b.get("type") == "image_url" for b in m.content
        )
    ]
    if len(image_indices) <= keep_last:
        return messages

    to_strip = set(image_indices[:-keep_last]) if keep_last else set(image_indices)
    out: list[Any] = []
    for i, m in enumerate(messages):
        if i not in to_strip:
            out.append(m)
            continue
        text_blocks = [
            b
            for b in m.content
            if not (isinstance(b, dict) and b.get("type") == "image_url")
        ]
        text_blocks.append(
            {"type": "text", "text": "[older screenshot removed to save context]"}
        )
        out.append(m.model_copy(update={"content": text_blocks}))
    return out
