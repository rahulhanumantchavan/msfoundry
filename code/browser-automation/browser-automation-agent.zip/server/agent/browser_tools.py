"""LangChain tools that drive the user's browser through the extension bridge.

Every tool is a thin, well-typed wrapper over a :class:`~server.protocol.BrowserAction`
RPC. After each *mutating* action the toolset captures a fresh screenshot, runs
it through the OpenCV pipeline and publishes it to the UI, so the agent's next
turn always observes the post-action state.
"""

from __future__ import annotations

import asyncio
import logging
import re
from typing import Any
from urllib.parse import urlparse

from langchain_core.tools import StructuredTool

from server.config import Settings
from server.protocol import BrowserAction, StreamEvent
from server.sessions.session import BrowserBridgeError, Session
from server.vision import VisionPipeline
from server.vision.pipeline import ProcessedScreenshot

logger = logging.getLogger(__name__)

# Matches a leading URI scheme such as "https:", "about:" or "javascript:".
_SCHEME_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9+.-]*:")

# Actions after which the page is expected to change and a new screenshot is
# therefore worth capturing.
_MUTATING = {
    BrowserAction.NAVIGATE,
    BrowserAction.CLICK,
    BrowserAction.TYPE,
    BrowserAction.PRESS_KEY,
    BrowserAction.SCROLL,
    BrowserAction.SELECT_OPTION,
    BrowserAction.NEW_TAB,
    BrowserAction.SWITCH_TAB,
    BrowserAction.CLOSE_TAB,
    BrowserAction.GO_BACK,
    BrowserAction.GO_FORWARD,
}


class BrowserToolkit:
    """Builds the tool list bound to one session."""

    def __init__(
        self,
        session: Session,
        settings: Settings,
        vision: VisionPipeline,
    ) -> None:
        self.session = session
        self.settings = settings
        self.vision = vision
        # Latest processed screenshot - the vision middleware reads this to
        # attach an image to the next model call.
        self.latest: ProcessedScreenshot | None = None
        self._blocked = settings.blocked_domain_list

    # ------------------------------------------------------------------ #
    # Internals
    # ------------------------------------------------------------------ #
    @staticmethod
    def normalize_url(url: str) -> str:
        """Add an https:// prefix only to genuinely scheme-less inputs.

        ``javascript:alert(1)`` carries a scheme even though it has no ``://``,
        so a naive ``"://" in url`` test would wrap it into a benign-looking
        ``https://javascript:alert(1)`` and defeat the scheme guard.
        """
        if _SCHEME_RE.match(url.strip()):
            return url.strip()
        return f"https://{url.strip()}"

    def _check_url(self, url: str) -> None:
        """Reject navigation to blocked domains and dangerous schemes."""
        parsed = urlparse(self.normalize_url(url))
        scheme = (parsed.scheme or "").lower()
        if scheme not in ("http", "https", "about", "file"):
            raise ValueError(f"refusing to navigate to unsupported scheme {scheme!r}")
        host = (parsed.hostname or "").lower()
        for blocked in self._blocked:
            if host == blocked or host.endswith(f".{blocked}"):
                raise ValueError(
                    f"navigation to {host!r} is blocked by server policy"
                )

    async def _rpc(
        self, action: BrowserAction, params: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        return await self.session.call(
            action, params or {}, timeout=self.settings.browser_rpc_timeout
        )

    async def _capture(
        self, *, click_css: tuple[float, float] | None = None, label: str | None = None
    ) -> ProcessedScreenshot | None:
        """Grab, process, cache and broadcast a screenshot. Never raises."""
        try:
            data = await self._rpc(BrowserAction.SCREENSHOT, {})
        except BrowserBridgeError as exc:
            logger.debug("screenshot capture failed: %s", exc)
            return None

        shot = self.vision.safe_process(
            data.get("image", ""),
            device_pixel_ratio=float(data.get("device_pixel_ratio") or 1.0),
            url=data.get("url"),
            title=data.get("title"),
            viewport=data.get("viewport") or {},
            captured_at=int(data.get("ts") or 0),
        )
        if shot is None:
            return None

        self.latest = shot
        self.session.page_url = shot.url or self.session.page_url
        self.session.page_title = shot.title or self.session.page_title

        annotated = (
            self.vision.annotate_css_click(shot, *click_css, label=label)
            if click_css is not None
            else shot.image
        )
        await self.session.broadcast(
            StreamEvent.SCREENSHOT,
            {
                "image": self.vision.encode_for_ui(annotated),
                "url": shot.url,
                "title": shot.title,
                "width": shot.width,
                "height": shot.height,
                "css_width": shot.css_width,
                "css_height": shot.css_height,
                "annotated": click_css is not None,
            },
        )
        return shot

    async def _act(
        self,
        action: BrowserAction,
        params: dict[str, Any],
        *,
        summary: str,
        click_css: tuple[float, float] | None = None,
    ) -> str:
        """Run a mutating action then report the resulting page state."""
        try:
            result = await self._rpc(action, params)
        except BrowserBridgeError as exc:
            return f"ERROR: {exc}"
        except ValueError as exc:
            return f"ERROR: {exc}"

        self.session.steps_taken += 1
        # Give the page a brief moment to react (navigation, XHR, animation).
        await asyncio.sleep(float(params.get("_settle", 0.6)))

        shot = None
        if action in _MUTATING:
            shot = await self._capture(click_css=click_css, label=summary)

        detail = result.get("message") or ""
        state = ""
        if shot is not None:
            state = f" Now at {shot.url} ({shot.title!r})."
        elif result.get("url"):
            state = f" Now at {result['url']}."
        return f"OK: {summary}.{(' ' + detail) if detail else ''}{state}"

    # ------------------------------------------------------------------ #
    # Tool implementations
    # ------------------------------------------------------------------ #
    async def navigate(self, url: str) -> str:
        """Navigate the controlled tab to a URL."""
        try:
            self._check_url(url)
        except ValueError as exc:
            return f"ERROR: {exc}"
        url = self.normalize_url(url)
        return await self._act(
            BrowserAction.NAVIGATE,
            {"url": url, "_settle": 1.2},
            summary=f"navigated to {url}",
        )

    async def click(
        self,
        x: int | None = None,
        y: int | None = None,
        selector: str | None = None,
        button: str = "left",
        click_count: int = 1,
    ) -> str:
        """Click by viewport coordinates or by CSS selector."""
        if selector:
            return await self._act(
                BrowserAction.CLICK,
                {"selector": selector, "button": button, "clickCount": click_count},
                summary=f"clicked selector {selector!r}",
            )
        if x is None or y is None:
            return (
                "ERROR: provide either (x, y) coordinates or a CSS selector. "
                "Coordinates must be read off the latest screenshot."
            )
        shot = self.latest
        css_x, css_y = float(x), float(y)
        if shot is not None:
            # The model sees the downscaled image; translate to CSS pixels.
            css_x, css_y = shot.to_css_point(float(x), float(y))
        return await self._act(
            BrowserAction.CLICK,
            {
                "x": css_x,
                "y": css_y,
                "button": button,
                "clickCount": click_count,
            },
            summary=f"clicked ({int(css_x)}, {int(css_y)})",
            click_css=(css_x, css_y),
        )

    async def type_text(
        self,
        text: str,
        selector: str | None = None,
        x: int | None = None,
        y: int | None = None,
        clear_first: bool = True,
        press_enter: bool = False,
    ) -> str:
        """Type text, optionally focusing a selector/coordinate first."""
        params: dict[str, Any] = {
            "text": text,
            "clearFirst": clear_first,
            "pressEnter": press_enter,
        }
        target = "focused element"
        if selector:
            params["selector"] = selector
            target = f"selector {selector!r}"
        elif x is not None and y is not None:
            shot = self.latest
            css_x, css_y = (
                shot.to_css_point(float(x), float(y))
                if shot is not None
                else (float(x), float(y))
            )
            params["x"], params["y"] = css_x, css_y
            target = f"({int(css_x)}, {int(css_y)})"
        preview = text if len(text) <= 40 else f"{text[:37]}..."
        return await self._act(
            BrowserAction.TYPE,
            params,
            summary=f"typed {preview!r} into {target}",
        )

    async def press_key(self, key: str, modifiers: list[str] | None = None) -> str:
        """Press a single key, e.g. Enter, Tab, Escape, ArrowDown, a."""
        return await self._act(
            BrowserAction.PRESS_KEY,
            {"key": key, "modifiers": modifiers or []},
            summary=f"pressed {key}",
        )

    async def scroll(
        self,
        direction: str = "down",
        amount: int = 600,
        selector: str | None = None,
    ) -> str:
        """Scroll the page (or a scrollable element) in a direction."""
        if direction not in ("up", "down", "left", "right", "top", "bottom"):
            return "ERROR: direction must be up, down, left, right, top or bottom"
        return await self._act(
            BrowserAction.SCROLL,
            {"direction": direction, "amount": amount, "selector": selector},
            summary=f"scrolled {direction}",
        )

    async def select_option(self, selector: str, value: str) -> str:
        """Choose an option in a <select> element by value or visible label."""
        return await self._act(
            BrowserAction.SELECT_OPTION,
            {"selector": selector, "value": value},
            summary=f"selected {value!r} in {selector!r}",
        )

    async def new_tab(self, url: str = "about:blank") -> str:
        """Open a new tab and switch control to it."""
        if url and url != "about:blank":
            try:
                self._check_url(url)
            except ValueError as exc:
                return f"ERROR: {exc}"
            url = self.normalize_url(url)
        return await self._act(
            BrowserAction.NEW_TAB,
            {"url": url, "_settle": 1.2},
            summary=f"opened new tab at {url}",
        )

    async def switch_tab(self, tab_id: int) -> str:
        """Give control to an existing tab (ids come from list_tabs)."""
        return await self._act(
            BrowserAction.SWITCH_TAB,
            {"tabId": tab_id},
            summary=f"switched to tab {tab_id}",
        )

    async def close_tab(self, tab_id: int | None = None) -> str:
        """Close a tab (defaults to the controlled tab)."""
        return await self._act(
            BrowserAction.CLOSE_TAB,
            {"tabId": tab_id},
            summary=f"closed tab {tab_id if tab_id is not None else '(current)'}",
        )

    async def go_back(self) -> str:
        """Go back in the tab's history."""
        return await self._act(
            BrowserAction.GO_BACK, {"_settle": 1.0}, summary="navigated back"
        )

    async def go_forward(self) -> str:
        """Go forward in the tab's history."""
        return await self._act(
            BrowserAction.GO_FORWARD, {"_settle": 1.0}, summary="navigated forward"
        )

    async def screenshot(self) -> str:
        """Capture the current viewport. Use when you need a fresh look."""
        shot = await self._capture()
        if shot is None:
            return "ERROR: could not capture a screenshot (is a tab attached?)"
        return f"OK: screenshot captured. {shot.describe()}"

    async def get_tree(self, max_elements: int = 120) -> str:
        """Return the interactive accessibility tree of the current page.

        Each entry is ``[index] role "name" (x,y wxh) selector`` where x/y are
        CSS-pixel viewport centre coordinates safe to pass to ``click``.
        """
        try:
            data = await self._rpc(
                BrowserAction.GET_TREE, {"maxElements": max_elements}
            )
        except BrowserBridgeError as exc:
            return f"ERROR: {exc}"

        nodes = data.get("nodes") or []
        if not nodes:
            return "No interactive elements were found on this page."

        lines: list[str] = []
        boxes: list[dict[str, Any]] = []
        shot = self.latest
        for i, node in enumerate(nodes[:max_elements]):
            role = node.get("role") or node.get("tag") or "element"
            name = (node.get("name") or "").strip()
            if len(name) > 80:
                name = f"{name[:77]}..."
            rect = node.get("rect") or {}
            cx = rect.get("cx")
            cy = rect.get("cy")
            selector = node.get("selector") or ""
            extra = []
            if node.get("value"):
                extra.append(f"value={str(node['value'])[:40]!r}")
            if node.get("disabled"):
                extra.append("disabled")
            if node.get("checked") is not None:
                extra.append(f"checked={node['checked']}")
            pos = (
                f"({int(cx)},{int(cy)} {int(rect.get('w', 0))}x{int(rect.get('h', 0))})"
                if cx is not None and cy is not None
                else ""
            )
            lines.append(
                f"[{i}] {role} {name!r} {pos} {selector}"
                + (f" {' '.join(extra)}" if extra else "")
            )
            # Build model-space boxes for the annotated UI view.
            if shot is not None and cx is not None and cy is not None:
                x0, y0 = shot.to_model_point(
                    float(rect.get("x", cx)), float(rect.get("y", cy))
                )
                x1, y1 = shot.to_model_point(
                    float(rect.get("x", cx)) + float(rect.get("w", 0)),
                    float(rect.get("y", cy)) + float(rect.get("h", 0)),
                )
                boxes.append(
                    {
                        "x": x0,
                        "y": y0,
                        "width": max(x1 - x0, 1),
                        "height": max(y1 - y0, 1),
                        "label": str(i),
                    }
                )

        if shot is not None and boxes:
            annotated = self.vision.annotate(shot, boxes=boxes, banner="accessibility tree")
            await self.session.broadcast(
                StreamEvent.SCREENSHOT,
                {
                    "image": self.vision.encode_for_ui(annotated),
                    "url": shot.url,
                    "title": shot.title,
                    "annotated": True,
                },
            )

        header = (
            f"{len(lines)} interactive elements on {data.get('url') or 'the page'} "
            f"(coordinates are CSS pixels, usable with click):"
        )
        return header + "\n" + "\n".join(lines)

    async def evaluate_js(self, expression: str) -> str:
        """Evaluate a JavaScript expression in the page and return its result."""
        try:
            data = await self._rpc(
                BrowserAction.EVALUATE_JS, {"expression": expression}
            )
        except BrowserBridgeError as exc:
            return f"ERROR: {exc}"
        value = data.get("value")
        text = str(value)
        if len(text) > 4000:
            text = f"{text[:4000]}... (truncated)"
        return f"Result: {text}"

    async def list_tabs(self) -> str:
        """List open tabs with their ids, titles and URLs."""
        try:
            data = await self._rpc(BrowserAction.LIST_TABS, {})
        except BrowserBridgeError as exc:
            return f"ERROR: {exc}"
        tabs = data.get("tabs") or []
        if not tabs:
            return "No tabs reported."
        lines = [
            f"- id={t.get('id')}{' (controlled)' if t.get('active') else ''} "
            f"{str(t.get('title') or '')[:70]!r} {t.get('url')}"
            for t in tabs
        ]
        return "Open tabs:\n" + "\n".join(lines)

    async def get_page_info(self) -> str:
        """Return URL, title, scroll offsets, viewport size and visible text."""
        try:
            data = await self._rpc(BrowserAction.GET_PAGE_INFO, {})
        except BrowserBridgeError as exc:
            return f"ERROR: {exc}"
        text = str(data.get("text") or "")
        if len(text) > 6000:
            text = f"{text[:6000]}... (truncated)"
        return (
            f"url: {data.get('url')}\ntitle: {data.get('title')}\n"
            f"scroll: x={data.get('scrollX')} y={data.get('scrollY')} "
            f"of height={data.get('scrollHeight')}\n"
            f"viewport: {data.get('width')}x{data.get('height')}\n"
            f"readyState: {data.get('readyState')}\n\n--- visible text ---\n{text}"
        )

    async def wait(self, seconds: float = 2.0, selector: str | None = None) -> str:
        """Wait a fixed time, or until a CSS selector appears (max 30s)."""
        seconds = float(min(max(seconds, 0.0), 30.0))
        try:
            data = await self._rpc(
                BrowserAction.WAIT,
                {"seconds": seconds, "selector": selector},
            )
        except BrowserBridgeError as exc:
            return f"ERROR: {exc}"
        await self._capture()
        if selector:
            found = bool(data.get("found"))
            return (
                f"OK: selector {selector!r} appeared."
                if found
                else f"Selector {selector!r} did not appear within {seconds:g}s."
            )
        return f"OK: waited {seconds:g}s."

    async def ask_user(self, question: str) -> str:
        """Pause and ask the human for input (credentials, a choice, approval).

        Use this whenever you need a decision, a secret you must not guess, or
        confirmation before an irreversible action.
        """
        await self.session.broadcast(
            StreamEvent.AGENT_MESSAGE,
            {"role": "assistant", "content": f"**I need your input:** {question}"},
        )
        try:
            answer = await self.session.ask_human(question)
        except asyncio.CancelledError:
            raise
        return f"User replied: {answer}"

    # ------------------------------------------------------------------ #
    # LangChain tool construction
    # ------------------------------------------------------------------ #
    def build_tools(self) -> list[StructuredTool]:
        """Expose the bound methods as LangChain structured tools.

        ``StructuredTool.from_function`` infers the argument schema from the
        type hints and the docstring, so each coroutine above is the single
        source of truth for both behaviour and schema.
        """
        specs: list[tuple[Any, str, str]] = [
            (
                self.navigate,
                "navigate",
                "Navigate the controlled browser tab to a URL. Accepts a bare "
                "domain (example.com) or a full URL.",
            ),
            (
                self.click,
                "click",
                "Click an element. Prefer a CSS 'selector' when you have a "
                "reliable one; otherwise pass 'x' and 'y' read directly off the "
                "latest screenshot. Set click_count=2 for a double click.",
            ),
            (
                self.type_text,
                "type_text",
                "Type text into an input. Optionally focus a 'selector' or an "
                "(x, y) point first. clear_first empties the field; "
                "press_enter submits afterwards.",
            ),
            (
                self.press_key,
                "press_key",
                "Press a keyboard key such as Enter, Tab, Escape, ArrowDown, "
                "Backspace, or a character. modifiers may include Control, "
                "Shift, Alt, Meta.",
            ),
            (
                self.scroll,
                "scroll",
                "Scroll the page or a scrollable element. direction is one of "
                "up, down, left, right, top, bottom.",
            ),
            (
                self.select_option,
                "select_option",
                "Select an option inside a <select> dropdown by value or "
                "visible label.",
            ),
            (self.new_tab, "new_tab", "Open a new tab and take control of it."),
            (
                self.switch_tab,
                "switch_tab",
                "Switch control to an existing tab by its id (see list_tabs).",
            ),
            (
                self.close_tab,
                "close_tab",
                "Close a tab. Omit tab_id to close the controlled tab.",
            ),
            (self.go_back, "go_back", "Go back one entry in the tab history."),
            (self.go_forward, "go_forward", "Go forward one entry in the tab history."),
            (
                self.screenshot,
                "screenshot",
                "Capture a fresh screenshot of the viewport. The image is "
                "attached automatically to your next turn.",
            ),
            (
                self.get_tree,
                "get_tree",
                "List the interactive elements (accessibility tree) with their "
                "roles, names, CSS-pixel coordinates and selectors. Use this "
                "when you need exact targets instead of guessing from pixels.",
            ),
            (
                self.evaluate_js,
                "evaluate_js",
                "Evaluate a JavaScript expression in the page and return the "
                "result. Use for reading values or precise DOM queries.",
            ),
            (self.list_tabs, "list_tabs", "List all open tabs with ids and URLs."),
            (
                self.get_page_info,
                "get_page_info",
                "Get the URL, title, scroll position, viewport size and the "
                "visible text of the page. Cheaper than a screenshot for "
                "reading content.",
            ),
            (
                self.wait,
                "wait",
                "Wait for a number of seconds, or until a CSS selector appears.",
            ),
            (
                self.ask_user,
                "ask_user",
                "Ask the human operator a question and wait for their reply. "
                "Use for credentials, ambiguous choices, or confirmation "
                "before irreversible actions.",
            ),
        ]

        tools: list[StructuredTool] = []
        for func, name, description in specs:
            tools.append(
                StructuredTool.from_function(
                    coroutine=func,
                    name=name,
                    description=description,
                )
            )
        return tools
