"""Builds and executes the LangGraph/DeepAgents browser agent.

The agent is assembled with :func:`deepagents.create_deep_agent`, which layers
planning (todo list), filesystem scratchpad and sub-agent middleware on top of a
LangGraph ReAct loop. We add two browser-specific middlewares:

* :class:`~server.agent.vision_middleware.ScreenshotMiddleware` - attaches the
  live viewport to every model call.
* :class:`~server.agent.vision_middleware.StopCheckMiddleware` - enforces
  pause/stop/step-budget between model calls.

Streaming is consumed with ``astream_events`` so the Streamlit UI sees the
agent's reasoning, tool calls and results as they happen.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from deepagents import create_deep_agent
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, HumanMessage
from langchain_openai import AzureChatOpenAI, ChatOpenAI
from langgraph.checkpoint.memory import InMemorySaver

from server.agent.browser_tools import BrowserToolkit
from server.agent.prompts import build_system_prompt
from server.agent.vision_middleware import (
    ScreenshotMiddleware,
    StopCheckMiddleware,
)
from server.config import Settings, get_settings
from server.protocol import SessionStatus, StreamEvent
from server.sessions.session import BrowserBridgeError, Session
from server.vision import VisionPipeline

logger = logging.getLogger(__name__)


class AgentConfigurationError(RuntimeError):
    """Raised when Azure OpenAI credentials are missing or invalid."""


def build_llm(settings: Settings) -> BaseChatModel:
    """Instantiate the Azure OpenAI chat model used by the agent.

    Two Azure endpoint shapes are supported (see
    :pyattr:`~server.config.Settings.uses_v1_endpoint`):

    * ``.../openai/v1``       -> OpenAI-compatible, uses :class:`ChatOpenAI`
      with ``base_url``; the deployment name travels as ``model``.
    * ``https://<res>.openai.azure.com/`` -> classic, uses
      :class:`AzureChatOpenAI` with ``azure_deployment`` + ``api_version``.
    """
    if not settings.azure_configured:
        raise AgentConfigurationError(
            "Azure OpenAI is not configured. Set AZURE_OPENAI_ENDPOINT and "
            "AZURE_OPENAI_API_KEY (see .env.example)."
        )

    # Reasoning deployments (o-series, gpt-5/6 family) reject `temperature`
    # with a 400. Only send it when the operator explicitly set one.
    optional: dict[str, Any] = {}
    if settings.azure_openai_temperature is not None:
        optional["temperature"] = settings.azure_openai_temperature

    if settings.uses_v1_endpoint:
        return ChatOpenAI(
            base_url=settings.azure_openai_endpoint.rstrip("/"),
            api_key=settings.azure_openai_api_key,
            model=settings.azure_openai_deployment,
            max_retries=3,
            timeout=120,
            **optional,
        )

    return AzureChatOpenAI(
        azure_endpoint=settings.azure_openai_endpoint,
        api_key=settings.azure_openai_api_key,
        azure_deployment=settings.azure_openai_deployment,
        api_version=settings.azure_openai_api_version,
        max_retries=3,
        timeout=120,
        **optional,
    )


class AgentRunner:
    """Owns agent construction and the per-session run loop."""

    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()
        # One checkpointer per process keeps conversation memory across the
        # turns of a session (thread_id == session id).
        self.checkpointer = InMemorySaver()
        self._toolkits: dict[str, BrowserToolkit] = {}

    # ------------------------------------------------------------------ #
    # Construction
    # ------------------------------------------------------------------ #
    def _vision_pipeline(self, vision_mode: str) -> VisionPipeline:
        s = self.settings
        return VisionPipeline(
            max_width=s.vision_max_width,
            enhance_contrast=s.vision_enhance_contrast,
            denoise=s.vision_denoise,
            jpeg_quality=s.vision_jpeg_quality,
        )

    def toolkit_for(self, session: Session, vision_mode: str) -> BrowserToolkit:
        """Reuse a session's toolkit so the latest screenshot survives turns."""
        toolkit = self._toolkits.get(session.id)
        if toolkit is None:
            toolkit = BrowserToolkit(
                session, self.settings, self._vision_pipeline(vision_mode)
            )
            self._toolkits[session.id] = toolkit
        return toolkit

    def discard(self, session_id: str) -> None:
        self._toolkits.pop(session_id, None)

    def build_agent(self, session: Session, vision_mode: str, max_steps: int):
        """Create the compiled LangGraph agent for one session."""
        toolkit = self.toolkit_for(session, vision_mode)
        tools = toolkit.build_tools()
        if vision_mode == "vision":
            # Pure-vision mode hides the accessibility tree entirely.
            tools = [t for t in tools if t.name != "get_tree"]

        llm = build_llm(self.settings)
        return create_deep_agent(
            model=llm,
            tools=tools,
            system_prompt=build_system_prompt(vision_mode),
            middleware=[
                StopCheckMiddleware(session, max_steps),
                ScreenshotMiddleware(
                    toolkit, jpeg_quality=self.settings.vision_jpeg_quality
                ),
            ],
            checkpointer=self.checkpointer,
        )

    # ------------------------------------------------------------------ #
    # Execution
    # ------------------------------------------------------------------ #
    async def run_task(
        self,
        session: Session,
        prompt: str,
        *,
        vision_mode: str | None = None,
        max_steps: int | None = None,
    ) -> None:
        """Execute one user task end to end, streaming progress to the UI."""
        mode = (vision_mode or self.settings.vision_mode or "hybrid").lower()
        budget = int(max_steps or self.settings.agent_max_steps)

        session.begin_task(prompt)
        await session.send_control("task_started", {"prompt": prompt})
        await session.broadcast_status()
        await session.broadcast(
            StreamEvent.AGENT_MESSAGE, {"role": "user", "content": prompt}
        )

        try:
            agent = self.build_agent(session, mode, budget)
        except AgentConfigurationError as exc:
            session.finish_task(SessionStatus.ERROR, str(exc))
            await session.broadcast(StreamEvent.ERROR, {"message": str(exc)})
            await session.broadcast_status()
            await session.send_control("task_finished", {"status": "error"})
            return

        config: dict[str, Any] = {
            "configurable": {"thread_id": session.id},
            "recursion_limit": self.settings.agent_recursion_limit,
        }

        status = SessionStatus.DONE
        error: str | None = None
        try:
            await self._stream(agent, prompt, config, session)
        except asyncio.CancelledError:
            status = SessionStatus.IDLE
            error = "stopped by user"
            await session.broadcast(
                StreamEvent.AGENT_MESSAGE,
                {"role": "assistant", "content": "_Task stopped by user._"},
            )
            raise
        except BrowserBridgeError as exc:
            # Expected, user-visible control-flow errors (stop, budget, bridge).
            message = str(exc)
            if "stopped by user" in message:
                status, error = SessionStatus.IDLE, message
            else:
                status, error = SessionStatus.ERROR, message
            await session.broadcast(StreamEvent.ERROR, {"message": message})
        except Exception as exc:  # noqa: BLE001 - surfaced to the operator
            logger.exception("agent run failed")
            status, error = SessionStatus.ERROR, f"{type(exc).__name__}: {exc}"
            await session.broadcast(StreamEvent.ERROR, {"message": error})
        finally:
            if status is not SessionStatus.IDLE or error != "stopped by user":
                session.finish_task(status, error)
            else:
                session.finish_task(SessionStatus.IDLE, None)
            await session.broadcast_status()
            await session.send_control(
                "task_finished", {"status": session.status.value}
            )

    async def _stream(
        self,
        agent: Any,
        prompt: str,
        config: dict[str, Any],
        session: Session,
    ) -> None:
        """Consume the LangGraph event stream and republish it to the UI."""
        inputs = {"messages": [HumanMessage(content=prompt)]}
        seen_tool_calls: set[str] = set()

        async for event in agent.astream_events(inputs, config=config, version="v2"):
            kind = event.get("event")
            name = event.get("name") or ""
            data = event.get("data") or {}

            if kind == "on_chat_model_end":
                message = data.get("output")
                await self._publish_model_output(session, message)

            elif kind == "on_tool_start":
                call_id = str(event.get("run_id") or "")
                if call_id in seen_tool_calls:
                    continue
                seen_tool_calls.add(call_id)
                await session.broadcast(
                    StreamEvent.TOOL_CALL,
                    {"tool": name, "args": _safe_args(data.get("input"))},
                )

            elif kind == "on_tool_end":
                output = data.get("output")
                text = _tool_output_text(output)
                await session.broadcast(
                    StreamEvent.TOOL_RESULT,
                    {
                        "tool": name,
                        "result": text[:2000],
                        "ok": not text.startswith("ERROR"),
                    },
                )
                if name == "write_todos":
                    await session.broadcast(
                        StreamEvent.PLAN, {"todos": _safe_args(data.get("input"))}
                    )

    async def _publish_model_output(self, session: Session, message: Any) -> None:
        """Emit assistant text (and a thinking trace) for one model turn."""
        if not isinstance(message, AIMessage):
            return
        text = _message_text(message).strip()
        if not text:
            return
        has_tools = bool(getattr(message, "tool_calls", None))
        await session.broadcast(
            StreamEvent.AGENT_THINKING if has_tools else StreamEvent.AGENT_MESSAGE,
            {"role": "assistant", "content": text},
        )


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def _message_text(message: Any) -> str:
    """Flatten a LangChain message's content into plain text."""
    content = getattr(message, "content", "")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, str):
                parts.append(block)
            elif isinstance(block, dict) and block.get("type") == "text":
                parts.append(str(block.get("text", "")))
        return "\n".join(p for p in parts if p)
    return str(content or "")


def _safe_args(value: Any) -> dict[str, Any]:
    """Coerce tool input into a JSON-safe dict, redacting bulky blobs."""
    if not isinstance(value, dict):
        return {"value": str(value)[:500]}
    out: dict[str, Any] = {}
    for key, val in value.items():
        if isinstance(val, str) and len(val) > 500:
            out[key] = f"{val[:500]}... (truncated)"
        elif isinstance(val, (str, int, float, bool)) or val is None:
            out[key] = val
        else:
            out[key] = str(val)[:500]
    return out


def _tool_output_text(output: Any) -> str:
    """Extract the string payload from a ToolMessage or raw return value."""
    if output is None:
        return ""
    content = getattr(output, "content", None)
    if content is not None:
        return _message_text(output)
    return str(output)


_runner: AgentRunner | None = None


def get_agent_runner() -> AgentRunner:
    """Process-wide agent runner singleton."""
    global _runner
    if _runner is None:
        _runner = AgentRunner()
    return _runner
