"""FastAPI application: WebSocket bridge (extension + UI) and REST control API."""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
from collections.abc import AsyncIterator
from typing import Any

from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel

from server.agent import get_agent_runner
from server.config import get_settings
from server.protocol import (
    BrowserAction,
    Event,
    FrameType,
    HumanReplyRequest,
    SessionStatus,
    StartTaskRequest,
    Stream,
    StreamEvent,
    Welcome,
    now_ms,
)
from server.sessions import get_session_manager
from server.sessions.session import BrowserBridgeError, Session

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
)
logger = logging.getLogger("browser-agent.api")

app = FastAPI(
    title="AI Browser Agent Server",
    version="1.0.0",
    description=(
        "Central server that pairs with a Chrome extension over WebSocket and "
        "drives it with a LangGraph + DeepAgents agent backed by Azure OpenAI."
    ),
)

# The extension's service worker and the Streamlit UI are different origins.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


# --------------------------------------------------------------------------- #
# Health & pairing
# --------------------------------------------------------------------------- #
class PairingResponse(BaseModel):
    session_id: str
    pairing_code: str
    ws_url: str
    expires_in_seconds: int = 900


@app.get("/health")
async def health() -> dict[str, Any]:
    settings = get_settings()
    manager = get_session_manager()
    return {
        "status": "ok",
        "time": now_ms(),
        "azure_configured": settings.azure_configured,
        "deployment": settings.azure_openai_deployment
        if settings.azure_configured
        else None,
        # Surfaced so the UI can tell the operator exactly what is missing.
        "endpoint_set": bool(settings.azure_openai_endpoint),
        "api_key_set": bool(settings.azure_openai_api_key),
        "api_mode": "v1" if settings.uses_v1_endpoint else "classic",
        "vision_mode": settings.vision_mode,
        "sessions": len(manager.list_sessions()),
    }


@app.get("/api/session/default", response_model=PairingResponse)
async def default_session() -> PairingResponse:
    """Return the shared local session, creating it once.

    With on-demand wake there is no pairing step, so the UI and the extension
    must agree on a session id without negotiating one. A single well-known id
    means a page reload - or a second UI tab - reuses the same session instead
    of stranding the extension on an orphaned one.
    """
    settings = get_settings()
    manager = get_session_manager()
    ticket = manager.ensure_default_pairing()
    session = manager.get(ticket.session_id)
    if session is not None:
        session.wake_timeout = settings.extension_wake_timeout
    ws_base = settings.server_public_url.replace("http://", "ws://").replace(
        "https://", "wss://"
    )
    return PairingResponse(
        session_id=ticket.session_id,
        pairing_code=ticket.code,
        ws_url=f"{ws_base}/ws/extension",
    )


@app.post("/api/pairing", response_model=PairingResponse)
async def create_pairing(session_id: str | None = None) -> PairingResponse:
    """Mint a pairing code for the extension to redeem."""
    settings = get_settings()
    manager = get_session_manager()
    ticket = manager.create_pairing(session_id)
    session = manager.get(ticket.session_id)
    if session is not None:
        session.wake_timeout = settings.extension_wake_timeout
    ws_base = settings.server_public_url.replace("http://", "ws://").replace(
        "https://", "wss://"
    )
    return PairingResponse(
        session_id=ticket.session_id,
        pairing_code=ticket.code,
        ws_url=f"{ws_base}/ws/extension",
    )


# --------------------------------------------------------------------------- #
# On-demand extension wake
# --------------------------------------------------------------------------- #
@app.get("/api/sessions/{session_id}/relay")
async def extension_relay(session_id: str, request: Request) -> StreamingResponse:
    """Server-sent events consumed by the UI tab's content script.

    The server cannot open a connection *into* a dormant MV3 service worker,
    so the UI page - which lives in the same Chrome - relays wake signals via
    ``chrome.runtime.sendMessage``. Closing the UI tab ends the relay and the
    extension goes fully idle.
    """
    settings = get_settings()
    session = get_session_manager().get_or_create(session_id)
    session.wake_timeout = settings.extension_wake_timeout
    queue = session.attach_relay()

    async def pump() -> AsyncIterator[str]:
        # Tell the relay what to connect to; it has no config of its own.
        ws_base = settings.server_public_url.replace("http://", "ws://").replace(
            "https://", "wss://"
        )
        hello = {
            "signal": "config",
            "payload": {
                "session_id": session.id,
                "ws_url": f"{ws_base}/ws/extension",
                "pairing_code": get_session_manager().code_for(session.id) or "",
                "tab_mode": settings.agent_tab_mode,
            },
        }
        yield f"data: {json.dumps(hello)}\n\n"
        await session.broadcast_status()
        try:
            while True:
                if await request.is_disconnected():
                    break
                try:
                    frame = await asyncio.wait_for(queue.get(), timeout=15.0)
                except TimeoutError:
                    yield ": keepalive\n\n"  # keeps proxies from closing the stream
                    continue
                yield f"data: {json.dumps(frame)}\n\n"
        finally:
            session.detach_relay(queue)
            with contextlib.suppress(Exception):
                await session.broadcast_status()

    return StreamingResponse(
        pump(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.post("/api/sessions/{session_id}/connect")
async def connect_extension(session_id: str) -> dict[str, Any]:
    """Ask the extension to connect now (UI "Connect" button)."""
    settings = get_settings()
    session = _require_session(session_id)
    session.wake_timeout = settings.extension_wake_timeout
    if session.extension_connected:
        return {"ok": True, "extension_connected": True}
    try:
        await session.ensure_extension(timeout=settings.extension_wake_timeout)
    except BrowserBridgeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    await session.broadcast_status()
    return {"ok": True, "extension_connected": True}


@app.post("/api/sessions/{session_id}/disconnect")
async def disconnect_extension(session_id: str) -> dict[str, Any]:
    """Release the debugger and let the extension go dormant again."""
    session = _require_session(session_id)
    if session.agent_task is not None and not session.agent_task.done():
        raise HTTPException(
            status_code=409, detail="stop the running task before disconnecting"
        )
    await session.send_control("release", {"close_tab": False})
    await session.broadcast_status()
    return {"ok": True}


@app.post("/api/sessions/{session_id}/tab")
async def agent_tab_control(session_id: str, action: str = "open") -> dict[str, Any]:
    """Open, focus or close the agent's dedicated tab from the UI."""
    settings = get_settings()
    if action not in {"open", "focus", "close"}:
        raise HTTPException(status_code=400, detail=f"unknown action {action!r}")
    session = _require_session(session_id)
    session.wake_timeout = settings.extension_wake_timeout
    try:
        if action == "close":
            if not session.extension_connected:
                return {"ok": True, "agent_tab_id": None}
            await session.send_control("release", {"close_tab": True})
            session.agent_tab_id = None
            await session.broadcast_status()
            return {"ok": True, "agent_tab_id": None}

        await session.ensure_extension(timeout=settings.extension_wake_timeout)
        data = await session.call(
            BrowserAction.NEW_TAB if action == "open" else BrowserAction.GET_PAGE_INFO,
            {"url": "about:blank"} if action == "open" else {},
            timeout=settings.browser_rpc_timeout,
        )
    except BrowserBridgeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    if data.get("tabId") is not None:
        session.agent_tab_id = int(data["tabId"])
    await session.broadcast_status()
    return {"ok": True, "agent_tab_id": session.agent_tab_id, **data}


def _require_session(session_id: str) -> Session:
    session = get_session_manager().get(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail=f"unknown session {session_id!r}")
    return session


@app.get("/api/sessions/{session_id}")
async def get_session_status(session_id: str) -> dict[str, Any]:
    session = _require_session(session_id)
    payload = session.status_payload()
    payload["pairing_code"] = get_session_manager().code_for(session_id)
    return payload


@app.get("/api/sessions")
async def list_sessions() -> dict[str, Any]:
    manager = get_session_manager()
    return {"sessions": [s.status_payload() for s in manager.list_sessions()]}


@app.get("/api/sessions/active/connected")
async def connected_sessions() -> dict[str, Any]:
    """Sessions that currently have a live extension socket.

    The UI uses this to adopt an extension that is already paired instead of
    minting a fresh code the user would have to retype - a page refresh resets
    Streamlit's session state but does not disturb the extension's socket.
    """
    manager = get_session_manager()
    active = [s for s in manager.list_sessions() if s.extension_connected]
    return {
        "sessions": [
            {**s.status_payload(), "pairing_code": manager.code_for(s.id)}
            for s in active
        ]
    }


@app.get("/api/sessions/{session_id}/events")
async def get_session_events(session_id: str, since: int = 0) -> dict[str, Any]:
    """Replay the buffered event log (used by the Streamlit poll loop).

    ``since`` is a frame *sequence number*, not a list index: the log prunes
    and trims itself, so an index-based cursor would silently skip frames.
    """
    session = _require_session(session_id)
    log = session.event_log
    fresh = [f for f in log if int(f.get("seq") or 0) > since]
    cursor = int(log[-1].get("seq") or 0) if log else since
    return {"events": fresh, "cursor": cursor}

# --------------------------------------------------------------------------- #
# Task control (REST)
# --------------------------------------------------------------------------- #
@app.post("/api/task/start")
async def start_task(req: StartTaskRequest) -> dict[str, Any]:
    """Kick off an agent run for a paired session."""
    settings = get_settings()
    session = _require_session(req.session_id)
    session.wake_timeout = settings.extension_wake_timeout
    # The extension is woken lazily on the first browser action, so a dormant
    # one is fine here - but with no relay nothing can ever wake it.
    if not session.extension_connected and not session.relay_connected:
        raise HTTPException(
            status_code=409,
            detail=(
                "Chrome cannot be reached. Open this UI in the Chrome window "
                "that has the AI Browser Agent extension installed."
            ),
        )
    if session.agent_task is not None and not session.agent_task.done():
        raise HTTPException(status_code=409, detail="a task is already running")
    if not req.prompt.strip():
        raise HTTPException(status_code=400, detail="prompt must not be empty")

    runner = get_agent_runner()
    session.agent_task = asyncio.create_task(
        runner.run_task(
            session,
            req.prompt.strip(),
            vision_mode=req.vision_mode,
            max_steps=req.max_steps,
        ),
        name=f"agent-{session.id}",
    )
    return {"ok": True, "session_id": session.id, "status": session.status.value}


@app.post("/api/task/pause")
async def pause_task(session_id: str) -> dict[str, Any]:
    session = _require_session(session_id)
    await session.pause()
    return {"ok": True, "status": session.status.value}


@app.post("/api/task/resume")
async def resume_task(session_id: str) -> dict[str, Any]:
    session = _require_session(session_id)
    await session.resume()
    return {"ok": True, "status": session.status.value}


@app.post("/api/task/stop")
async def stop_task(session_id: str) -> dict[str, Any]:
    session = _require_session(session_id)
    await session.stop()
    # Give the cancelled task a moment to unwind before reporting status.
    task = session.agent_task
    if task is not None:
        with contextlib.suppress(asyncio.CancelledError, TimeoutError):
            await asyncio.wait_for(asyncio.shield(task), timeout=5.0)
    session.finish_task(SessionStatus.IDLE, None)
    await session.broadcast_status()
    return {"ok": True, "status": session.status.value}


@app.post("/api/task/reply")
async def human_reply(req: HumanReplyRequest) -> dict[str, Any]:
    """Answer a pending ``ask_user`` question."""
    session = _require_session(req.session_id)
    delivered = session.provide_human_reply(req.reply)
    if not delivered:
        raise HTTPException(status_code=409, detail="no pending question")
    await session.broadcast(
        StreamEvent.AGENT_MESSAGE, {"role": "user", "content": req.reply}
    )
    await session.broadcast_status()
    return {"ok": True}


@app.post("/api/sessions/{session_id}/clear")
async def clear_session(session_id: str) -> dict[str, Any]:
    """Stop any run, wipe the transcript and detach agent memory."""
    session = _require_session(session_id)
    if session.agent_task is not None and not session.agent_task.done():
        await session.stop()
    session.event_log.clear()
    session.last_screenshot = None
    session.current_task = None
    session.steps_taken = 0
    session.last_error = None
    session.finish_task(SessionStatus.IDLE, None)
    get_agent_runner().discard(session_id)
    await session.broadcast_status()
    return {"ok": True}

# --------------------------------------------------------------------------- #
# WebSocket: Chrome extension
# --------------------------------------------------------------------------- #
@app.websocket("/ws/extension")
async def extension_socket(ws: WebSocket) -> None:
    """Persistent control channel with the Chrome extension.

    Handshake: the extension sends a ``hello`` frame containing its pairing
    code; on success the server replies with ``welcome`` and the socket becomes
    the RPC transport for browser commands.
    """
    await ws.accept()
    manager = get_session_manager()
    session: Session | None = None

    try:
        # --- handshake (bounded so a silent client cannot hold a slot) ----
        try:
            first = await asyncio.wait_for(ws.receive_json(), timeout=20.0)
        except (TimeoutError, ValueError):
            await ws.close(code=4000, reason="handshake timeout")
            return

        if first.get("type") != FrameType.HELLO.value:
            await ws.close(code=4001, reason="expected hello frame")
            return

        session = manager.redeem_pairing(str(first.get("pairing_code") or ""))
        if session is None:
            # Auto-connect: the relay hands the extension a session id directly,
            # so a code is only needed when the UI could not supply one.
            requested = str(first.get("session_id") or "").strip()
            if get_settings().extension_auto_connect and requested:
                session = manager.get(requested)
            if session is None:
                await ws.send_json(
                    {"type": "error", "message": "invalid or expired pairing code"}
                )
                await ws.close(code=4003, reason="invalid pairing code")
                return

        # Replace any previous socket for this session.
        session.detach_extension()
        session.attach_extension(
            ws, version=str(first.get("extension_version") or "")
        )
        await ws.send_json(
            Welcome(session_id=session.id).model_dump(mode="json")
        )
        logger.info("extension paired to session %s", session.id)
        await session.broadcast_status()
        await session.broadcast(
            StreamEvent.PAIRING,
            {"connected": True, "session_id": session.id},
        )

        # --- main receive loop -------------------------------------------
        while True:
            frame = await ws.receive_json()
            await _handle_extension_frame(session, frame)

    except WebSocketDisconnect:
        logger.info(
            "extension disconnected from session %s",
            session.id if session else "(unpaired)",
        )
    except Exception:  # noqa: BLE001 - never let one socket kill the server
        logger.exception("extension socket error")
    finally:
        if session is not None:
            session.detach_extension(ws)
            with contextlib.suppress(Exception):
                await session.broadcast_status()
                await session.broadcast(
                    StreamEvent.PAIRING,
                    {"connected": False, "session_id": session.id},
                )


async def _handle_extension_frame(session: Session, frame: dict[str, Any]) -> None:
    """Dispatch one inbound frame from the extension."""
    ftype = frame.get("type")

    if ftype == FrameType.RESULT.value:
        session.resolve(
            str(frame.get("id") or ""),
            bool(frame.get("ok")),
            frame.get("data") or {},
            frame.get("error"),
        )
        return

    if ftype == FrameType.EVENT.value:
        event = Event(
            name=str(frame.get("name") or "unknown"),
            payload=frame.get("payload") or {},
        )
        session.record_event(event)
        await _republish_event(session, event)
        return

    if ftype == FrameType.PONG.value:
        return

    logger.debug("ignoring extension frame of type %r", ftype)


async def _republish_event(session: Session, event: Event) -> None:
    """Translate extension events into UI stream frames."""
    payload = event.payload or {}

    if event.name == "screenshot":
        # Push-mode screenshots (e.g. user takeover) are already encoded.
        image = payload.get("image") or ""
        if image:
            data_url = (
                image if image.startswith("data:") else f"data:image/png;base64,{image}"
            )
            await session.broadcast(
                StreamEvent.SCREENSHOT,
                {
                    "image": data_url,
                    "url": payload.get("url"),
                    "title": payload.get("title"),
                    "annotated": False,
                },
            )
        return

    if event.name == "user_takeover":
        await session.pause()
        await session.broadcast(
            StreamEvent.AGENT_MESSAGE,
            {
                "role": "system",
                "content": "User took over the browser - the agent is paused.",
            },
        )
        return

    if event.name in ("paused", "resumed", "stopped"):
        if event.name == "paused":
            await session.pause()
        elif event.name == "resumed":
            await session.resume()
        else:
            await session.stop()
        return

    if event.name == "tab_changed":
        if payload.get("tabId") is not None:
            session.agent_tab_id = int(payload["tabId"])
        if payload.get("url"):
            session.page_url = str(payload["url"])
        await session.broadcast_status()
        return

    if event.name == "agent_tab":
        tab_id = payload.get("tabId")
        session.agent_tab_id = int(tab_id) if tab_id is not None else None
        await session.broadcast_status()
        return

    if event.name == "released":
        session.agent_tab_id = None
        await session.broadcast_status()
        return

    if event.name == "error":
        await session.broadcast(
            StreamEvent.ERROR, {"message": str(payload.get("message") or "")}
        )
        return

# --------------------------------------------------------------------------- #
# WebSocket: UI observers
# --------------------------------------------------------------------------- #
@app.websocket("/ws/ui/{session_id}")
async def ui_socket(ws: WebSocket, session_id: str) -> None:
    """Read-only event stream for the Streamlit UI (or any observer)."""
    await ws.accept()
    manager = get_session_manager()
    session = manager.get_or_create(session_id)
    session.attach_ui(ws)

    try:
        # Replay buffered history so a late client is immediately in sync.
        for frame in list(session.event_log):
            await ws.send_json(frame)
        await ws.send_json(
            Stream(
                event=StreamEvent.STATUS,
                session_id=session.id,
                payload=session.status_payload(),
            ).model_dump(mode="json")
        )

        while True:
            # The UI does not send commands; this keeps the socket open and
            # detects disconnects promptly.
            await ws.receive_text()
    except WebSocketDisconnect:
        pass
    except Exception:  # noqa: BLE001
        logger.debug("ui socket closed", exc_info=True)
    finally:
        session.detach_ui(ws)


# --------------------------------------------------------------------------- #
# Errors
# --------------------------------------------------------------------------- #
@app.exception_handler(Exception)
async def unhandled_exception_handler(_request, exc: Exception) -> JSONResponse:
    logger.exception("unhandled server error")
    return JSONResponse(
        status_code=500,
        content={"detail": f"{type(exc).__name__}: {exc}"},
    )


def run() -> None:
    """Entry point used by ``python -m server.api.app``."""
    import uvicorn

    settings = get_settings()
    uvicorn.run(
        "server.api.app:app",
        host=settings.server_host,
        port=settings.server_port,
        log_level="info",
    )


if __name__ == "__main__":
    run()
