"""Screenshot processing pipeline built on OpenCV + Pillow + numpy.

Responsibilities
----------------
* Decode base64 PNG screenshots pushed by the Chrome extension into OpenCV
  (BGR ``numpy.ndarray``) images.
* Normalise them for the vision model: downscale to a bounded width, optional
  CLAHE contrast enhancement and optional denoising.
* Produce annotated copies (click markers, bounding boxes, labels, grid) that
  are streamed to the Streamlit UI for debugging and live viewing.
* Re-encode to base64 (PNG for fidelity, JPEG for bandwidth).

Coordinate contract
-------------------
The agent always reasons in **CSS pixel** coordinates of the visible viewport.
Screenshots arrive at device-pixel resolution (``device_pixel_ratio`` > 1 on
HiDPI screens) and are further downscaled for the model. ``ProcessedScreenshot``
therefore records every scale factor so a model-space point can be converted
back to a CSS-pixel point the extension can click.
"""

from __future__ import annotations

import base64
import binascii
import io
import logging
from dataclasses import dataclass, field
from typing import Any

import cv2
import numpy as np
from PIL import Image

logger = logging.getLogger(__name__)

# BGR colours (OpenCV ordering)
_COLOR_CLICK = (0, 0, 255)       # red
_COLOR_BOX = (0, 200, 0)         # green
_COLOR_HIGHLIGHT = (0, 215, 255)  # amber
_COLOR_TEXT_BG = (32, 32, 32)
_COLOR_TEXT_FG = (255, 255, 255)
_COLOR_GRID = (200, 200, 200)


# --------------------------------------------------------------------------- #
# Codec helpers
# --------------------------------------------------------------------------- #
def _strip_data_url(data: str) -> str:
    """Remove an optional ``data:image/png;base64,`` prefix."""
    if "," in data and data.strip().lower().startswith("data:"):
        return data.split(",", 1)[1]
    return data


def decode_base64_image(data: str) -> np.ndarray:
    """Decode a base64 (optionally data-URL) image into an OpenCV BGR array.

    Raises:
        ValueError: if the payload is empty or cannot be decoded.
    """
    if not data:
        raise ValueError("empty screenshot payload")
    raw_b64 = _strip_data_url(data)
    try:
        raw = base64.b64decode(raw_b64, validate=False)
    except (binascii.Error, ValueError) as exc:
        raise ValueError(f"invalid base64 screenshot: {exc}") from exc
    if not raw:
        raise ValueError("screenshot decoded to zero bytes")

    buf = np.frombuffer(raw, dtype=np.uint8)
    img = cv2.imdecode(buf, cv2.IMREAD_COLOR)
    if img is None:
        # Fall back to Pillow which tolerates a few formats cv2 rejects.
        try:
            pil = Image.open(io.BytesIO(raw)).convert("RGB")
        except Exception as exc:  # noqa: BLE001 - surfaced as ValueError
            raise ValueError(f"unsupported image payload: {exc}") from exc
        img = cv2.cvtColor(np.array(pil), cv2.COLOR_RGB2BGR)
    return img


def encode_image_base64(img: np.ndarray, *, fmt: str = "png", quality: int = 85) -> str:
    """Encode an OpenCV BGR image to a base64 string (no data-URL prefix)."""
    fmt = fmt.lower()
    if fmt in ("jpg", "jpeg"):
        params = [int(cv2.IMWRITE_JPEG_QUALITY), int(np.clip(quality, 1, 100))]
        ok, buf = cv2.imencode(".jpg", img, params)
    else:
        # Compression level 6 balances CPU time against payload size.
        ok, buf = cv2.imencode(".png", img, [int(cv2.IMWRITE_PNG_COMPRESSION), 6])
    if not ok:
        raise ValueError(f"failed to encode image as {fmt}")
    return base64.b64encode(buf.tobytes()).decode("ascii")


def to_data_url(b64: str, *, fmt: str = "png") -> str:
    mime = "image/jpeg" if fmt.lower() in ("jpg", "jpeg") else "image/png"
    return f"data:{mime};base64,{b64}"


# --------------------------------------------------------------------------- #
# Result container
# --------------------------------------------------------------------------- #
@dataclass(slots=True)
class ProcessedScreenshot:
    """A screenshot normalised for the model plus its annotated twin."""

    # Image data
    image: np.ndarray                 # processed (model-space) BGR image
    raw_image: np.ndarray             # original decoded BGR image

    # Geometry
    raw_width: int
    raw_height: int
    width: int
    height: int
    scale: float                      # model-space -> raw-image factor
    device_pixel_ratio: float = 1.0

    # Page context captured alongside the pixels
    url: str | None = None
    title: str | None = None
    viewport: dict[str, Any] = field(default_factory=dict)
    captured_at: int = 0

    # Lazily-populated encodings
    _b64_model: str | None = field(default=None, repr=False)
    _b64_raw: str | None = field(default=None, repr=False)

    @property
    def css_width(self) -> int:
        """Viewport width in CSS pixels."""
        value = self.viewport.get("width")
        if isinstance(value, (int, float)) and value > 0:
            return int(value)
        return int(round(self.raw_width / max(self.device_pixel_ratio, 1e-6)))

    @property
    def css_height(self) -> int:
        value = self.viewport.get("height")
        if isinstance(value, (int, float)) and value > 0:
            return int(value)
        return int(round(self.raw_height / max(self.device_pixel_ratio, 1e-6)))

    def to_css_point(self, x: float, y: float) -> tuple[int, int]:
        """Convert a model-space point into CSS-pixel page coordinates.

        The model sees the downscaled image, so we first undo the resize
        (``* scale``) and then undo the device pixel ratio.
        """
        dpr = max(self.device_pixel_ratio, 1e-6)
        css_x = (x * self.scale) / dpr
        css_y = (y * self.scale) / dpr
        css_x = float(np.clip(css_x, 0, max(self.css_width - 1, 0)))
        css_y = float(np.clip(css_y, 0, max(self.css_height - 1, 0)))
        return int(round(css_x)), int(round(css_y))

    def to_model_point(self, css_x: float, css_y: float) -> tuple[int, int]:
        """Inverse of :meth:`to_css_point` (CSS pixels -> model-space pixels)."""
        dpr = max(self.device_pixel_ratio, 1e-6)
        scale = max(self.scale, 1e-6)
        mx = (css_x * dpr) / scale
        my = (css_y * dpr) / scale
        mx = float(np.clip(mx, 0, max(self.width - 1, 0)))
        my = float(np.clip(my, 0, max(self.height - 1, 0)))
        return int(round(mx)), int(round(my))

    def base64_model(self, *, fmt: str = "jpeg", quality: int = 85) -> str:
        """Base64 of the processed image (cached)."""
        if self._b64_model is None:
            self._b64_model = encode_image_base64(self.image, fmt=fmt, quality=quality)
        return self._b64_model

    def base64_raw(self) -> str:
        """Base64 PNG of the original screenshot (cached)."""
        if self._b64_raw is None:
            self._b64_raw = encode_image_base64(self.raw_image, fmt="png")
        return self._b64_raw

    def describe(self) -> str:
        """Short textual summary injected into the agent's context."""
        parts = [
            f"viewport={self.css_width}x{self.css_height}css",
            f"image={self.width}x{self.height}px",
        ]
        if self.url:
            parts.append(f"url={self.url}")
        if self.title:
            parts.append(f"title={self.title!r}")
        return " ".join(parts)

# --------------------------------------------------------------------------- #
# Annotation helpers
# --------------------------------------------------------------------------- #
def _put_label(
    img: np.ndarray,
    text: str,
    org: tuple[int, int],
    *,
    color: tuple[int, int, int] = _COLOR_TEXT_FG,
    scale: float = 0.45,
    thickness: int = 1,
) -> None:
    """Draw text with a filled background box so it stays readable."""
    if not text:
        return
    font = cv2.FONT_HERSHEY_SIMPLEX
    (tw, th), baseline = cv2.getTextSize(text, font, scale, thickness)
    x, y = org
    # Keep the label inside the image bounds.
    x = int(np.clip(x, 0, max(img.shape[1] - tw - 4, 0)))
    y = int(np.clip(y, th + baseline + 2, img.shape[0] - 2))
    cv2.rectangle(
        img,
        (x, y - th - baseline - 2),
        (x + tw + 4, y + 2),
        _COLOR_TEXT_BG,
        thickness=-1,
    )
    cv2.putText(img, text, (x + 2, y - baseline), font, scale, color, thickness, cv2.LINE_AA)


def annotate_click(
    img: np.ndarray,
    x: int,
    y: int,
    *,
    label: str | None = None,
    color: tuple[int, int, int] = _COLOR_CLICK,
    radius: int = 14,
) -> np.ndarray:
    """Return a copy of ``img`` with a crosshair + ring marking a click point."""
    out = img.copy()
    h, w = out.shape[:2]
    x = int(np.clip(x, 0, max(w - 1, 0)))
    y = int(np.clip(y, 0, max(h - 1, 0)))
    cv2.circle(out, (x, y), radius, color, 2, cv2.LINE_AA)
    cv2.circle(out, (x, y), 2, color, -1, cv2.LINE_AA)
    cv2.line(out, (x - radius - 6, y), (x - radius + 2, y), color, 1, cv2.LINE_AA)
    cv2.line(out, (x + radius - 2, y), (x + radius + 6, y), color, 1, cv2.LINE_AA)
    cv2.line(out, (x, y - radius - 6), (x, y - radius + 2), color, 1, cv2.LINE_AA)
    cv2.line(out, (x, y + radius - 2), (x, y + radius + 6), color, 1, cv2.LINE_AA)
    _put_label(out, label or f"({x},{y})", (x + radius + 4, y - radius), color=color)
    return out


def annotate_boxes(
    img: np.ndarray,
    boxes: list[dict[str, Any]],
    *,
    color: tuple[int, int, int] = _COLOR_BOX,
) -> np.ndarray:
    """Draw labelled bounding boxes.

    Each box is a mapping with ``x``/``y``/``width``/``height`` (model-space
    pixels) and an optional ``label``.
    """
    out = img.copy()
    for box in boxes:
        try:
            x = int(box.get("x", 0))
            y = int(box.get("y", 0))
            bw = int(box.get("width", 0))
            bh = int(box.get("height", 0))
        except (TypeError, ValueError):
            continue
        if bw <= 0 or bh <= 0:
            continue
        cv2.rectangle(out, (x, y), (x + bw, y + bh), color, 2, cv2.LINE_AA)
        label = str(box.get("label") or "")
        if label:
            _put_label(out, label, (x, max(y - 2, 12)), color=_COLOR_TEXT_FG)
    return out


def annotate_highlight(
    img: np.ndarray,
    region: tuple[int, int, int, int],
    *,
    alpha: float = 0.25,
    color: tuple[int, int, int] = _COLOR_HIGHLIGHT,
) -> np.ndarray:
    """Blend a translucent rectangle over a region of interest."""
    out = img.copy()
    x, y, w, h = region
    h_img, w_img = out.shape[:2]
    x0, y0 = max(x, 0), max(y, 0)
    x1, y1 = min(x + w, w_img), min(y + h, h_img)
    if x1 <= x0 or y1 <= y0:
        return out
    overlay = out.copy()
    cv2.rectangle(overlay, (x0, y0), (x1, y1), color, thickness=-1)
    cv2.addWeighted(overlay, alpha, out, 1 - alpha, 0, out)
    cv2.rectangle(out, (x0, y0), (x1, y1), color, 2, cv2.LINE_AA)
    return out


def annotate_grid(img: np.ndarray, *, step: int = 100) -> np.ndarray:
    """Overlay a labelled coordinate grid (useful when debugging clicks)."""
    out = img.copy()
    h, w = out.shape[:2]
    if step <= 0:
        return out
    for x in range(step, w, step):
        cv2.line(out, (x, 0), (x, h), _COLOR_GRID, 1, cv2.LINE_AA)
        _put_label(out, str(x), (x + 2, 14), scale=0.35)
    for y in range(step, h, step):
        cv2.line(out, (0, y), (w, y), _COLOR_GRID, 1, cv2.LINE_AA)
        _put_label(out, str(y), (2, y + 12), scale=0.35)
    return out

# --------------------------------------------------------------------------- #
# Pipeline
# --------------------------------------------------------------------------- #
class VisionPipeline:
    """Turns raw extension screenshots into model-ready + UI-ready images."""

    def __init__(
        self,
        *,
        max_width: int = 1280,
        enhance_contrast: bool = True,
        denoise: bool = False,
        jpeg_quality: int = 85,
    ) -> None:
        self.max_width = max(int(max_width), 320)
        self.enhance_contrast = enhance_contrast
        self.denoise = denoise
        self.jpeg_quality = int(np.clip(jpeg_quality, 1, 100))

    # -- individual stages -------------------------------------------------
    def resize(self, img: np.ndarray) -> tuple[np.ndarray, float]:
        """Downscale so width <= ``max_width``; returns (image, scale).

        ``scale`` converts a processed-image coordinate back to the raw image
        (raw = processed * scale). It is ``1.0`` when no resize happened.
        """
        h, w = img.shape[:2]
        if w <= self.max_width or w == 0:
            return img, 1.0
        ratio = self.max_width / float(w)
        new_size = (self.max_width, max(int(round(h * ratio)), 1))
        # INTER_AREA is the correct choice for shrinking - it averages pixels
        # and preserves small text far better than bilinear.
        resized = cv2.resize(img, new_size, interpolation=cv2.INTER_AREA)
        return resized, 1.0 / ratio

    def apply_contrast(self, img: np.ndarray) -> np.ndarray:
        """CLAHE on the L channel of LAB - boosts faint UI text/borders."""
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        l_chan, a_chan, b_chan = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        merged = cv2.merge((clahe.apply(l_chan), a_chan, b_chan))
        return cv2.cvtColor(merged, cv2.COLOR_LAB2BGR)

    def apply_denoise(self, img: np.ndarray) -> np.ndarray:
        """Edge-preserving denoise; cheap enough for interactive use."""
        return cv2.bilateralFilter(img, d=5, sigmaColor=50, sigmaSpace=50)

    # -- orchestration -----------------------------------------------------
    def process(
        self,
        b64_png: str,
        *,
        device_pixel_ratio: float = 1.0,
        url: str | None = None,
        title: str | None = None,
        viewport: dict[str, Any] | None = None,
        captured_at: int = 0,
    ) -> ProcessedScreenshot:
        """Full decode -> normalise pipeline. Raises ``ValueError`` on bad input."""
        raw = decode_base64_image(b64_png)
        raw_h, raw_w = raw.shape[:2]

        processed, scale = self.resize(raw)
        if self.enhance_contrast:
            processed = self.apply_contrast(processed)
        if self.denoise:
            processed = self.apply_denoise(processed)

        proc_h, proc_w = processed.shape[:2]
        return ProcessedScreenshot(
            image=processed,
            raw_image=raw,
            raw_width=raw_w,
            raw_height=raw_h,
            width=proc_w,
            height=proc_h,
            scale=scale,
            device_pixel_ratio=max(float(device_pixel_ratio or 1.0), 1e-6),
            url=url,
            title=title,
            viewport=viewport or {},
            captured_at=captured_at,
        )

    def safe_process(self, b64_png: str, **kwargs: Any) -> ProcessedScreenshot | None:
        """``process`` that logs and returns ``None`` instead of raising."""
        try:
            return self.process(b64_png, **kwargs)
        except ValueError as exc:
            logger.warning("screenshot processing failed: %s", exc)
            return None

    # -- annotation convenience -------------------------------------------
    def annotate(
        self,
        shot: ProcessedScreenshot,
        *,
        click: tuple[int, int] | None = None,
        click_label: str | None = None,
        boxes: list[dict[str, Any]] | None = None,
        highlight: tuple[int, int, int, int] | None = None,
        grid: bool = False,
        banner: str | None = None,
    ) -> np.ndarray:
        """Compose any combination of overlays onto the processed image."""
        out = shot.image.copy()
        if grid:
            out = annotate_grid(out)
        if highlight:
            out = annotate_highlight(out, highlight)
        if boxes:
            out = annotate_boxes(out, boxes)
        if click:
            out = annotate_click(out, click[0], click[1], label=click_label)
        if banner:
            _put_label(out, banner, (8, 20), scale=0.55, thickness=1)
        return out

    def annotate_css_click(
        self,
        shot: ProcessedScreenshot,
        css_x: float,
        css_y: float,
        *,
        label: str | None = None,
    ) -> np.ndarray:
        """Annotate using CSS-pixel coordinates (what the extension clicked)."""
        mx, my = shot.to_model_point(css_x, css_y)
        return annotate_click(
            shot.image, mx, my, label=label or f"click ({int(css_x)},{int(css_y)})"
        )

    def encode_for_ui(self, img: np.ndarray) -> str:
        """Data URL (JPEG) suitable for direct rendering in Streamlit/HTML."""
        return to_data_url(
            encode_image_base64(img, fmt="jpeg", quality=self.jpeg_quality),
            fmt="jpeg",
        )
