"""OpenCV-based screenshot processing pipeline."""

from server.vision.pipeline import (
    ProcessedScreenshot,
    VisionPipeline,
    annotate_click,
    decode_base64_image,
    encode_image_base64,
)

__all__ = [
    "ProcessedScreenshot",
    "VisionPipeline",
    "annotate_click",
    "decode_base64_image",
    "encode_image_base64",
]
