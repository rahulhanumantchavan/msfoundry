"""AI Browser Agent server package."""

__version__ = "1.0.0"
