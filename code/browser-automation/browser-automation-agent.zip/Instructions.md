python run_server.py

streamlit run ui/app.py