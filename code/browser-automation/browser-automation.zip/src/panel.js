import { configFrom, webUrl, MAX_ACTIONS, RUN_TIMEOUT, nextAction, needsApproval, actionDescription, actionProgress, wantsSummary, summarizeResults } from './core.js';
import { browserTool } from './dom.js';

const $ = id => document.getElementById(id);
let run;
let pendingGate;

class PageChangedError extends Error {}

function log(message) {
  const item = document.createElement('li');
  item.textContent = `${new Date().toLocaleTimeString()} · ${message}`;
  $('log').append(item);
  if ($('activity-log').open) item.scrollIntoView({ block: 'nearest' });
}
function assertRunning(ctx) {
  if (ctx.controller.signal.aborted || run !== ctx) throw new Error('Run stopped.');
}
function stop(message = 'Stopped. Completed actions cannot be undone.') {
  if (!run) return;
  run.controller.abort();
  if (pendingGate) { pendingGate.reject(new Error(message)); pendingGate = undefined; }
  $('gate').hidden = true;
}

function gate(ctx, message, preview = '', permission) {
  assertRunning(ctx);
  $('status').textContent = 'Approval needed';
  $('gate-message').textContent = message;
  $('gate-preview').textContent = preview;
  $('gate').dataset.requestId = crypto.randomUUID();
  $('gate').hidden = false;
  return new Promise((resolve, reject) => { pendingGate = { ctx, resolve, reject, permission }; });
}
$('approve').addEventListener('click', async () => {
  const pending = pendingGate;
  if (!pending) return;
  $('approve').disabled = true;
  try {
    // Permission requests must originate directly from this user gesture.
    if (pending.permission && !await chrome.permissions.request({ origins: pending.permission })) throw new Error('Site permission was denied.');
    assertRunning(pending.ctx);
    if (pendingGate === pending) { pendingGate = undefined; $('gate').hidden = true; pending.resolve(); }
  } catch (error) {
    if (pendingGate === pending) { pendingGate = undefined; $('gate').hidden = true; pending.reject(error); }
  } finally { $('approve').disabled = false; }
});
$('reject').addEventListener('click', () => stop());
$('stop').addEventListener('click', () => stop());
window.addEventListener('pagehide', () => stop());

$('config-form').addEventListener('submit', async event => {
  event.preventDefault();
  try {
    const config = configFrom({ endpoint: $('endpoint').value, deployment: $('deployment').value, key: $('key').value });
    if (!await chrome.permissions.request({ origins: [`${config.endpoint}/*`] })) throw new Error('Azure endpoint permission denied.');
    await chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
    await chrome.storage.local.set({ config });
    $('key').value = '';
    $('key').placeholder = 'Saved locally — re-enter to change settings';
    $('settings').open = false;
    $('result').textContent = 'Configuration saved. No API request has been made yet.';
  } catch (error) { $('result').textContent = error.message; }
});
$('forget').addEventListener('click', async () => {
  stop();
  await chrome.storage.local.remove('config');
  $('key').value = '';
  $('key').placeholder = '';
  $('result').textContent = 'Saved configuration and key removed. Site permissions can be revoked in Chrome extension settings.';
});

async function currentTab(ctx) {
  assertRunning(ctx);
  const tab = await chrome.tabs.get(ctx.tabId);
  assertRunning(ctx);
  if (!tab.active) throw new Error('Task tab is no longer active. Run stopped to avoid acting in the background.');
  return tab;
}
async function dom(ctx, command) {
  await currentTab(ctx);
  const results = await chrome.scripting.executeScript({ target: { tabId: ctx.tabId }, func: browserTool, args: [command], injectImmediately: true });
  assertRunning(ctx);
  if (!results[0] || results[0].error) throw new Error(results[0]?.error?.message || 'Page script could not run.');
  const result = results[0].result;
  if (result?.error) throw new Error(result.error);
  return result;
}
async function pause(ctx, milliseconds) {
  assertRunning(ctx);
  await new Promise((resolve, reject) => {
    const abort = () => { clearTimeout(timer); reject(new Error('Run stopped.')); };
    const timer = setTimeout(() => { ctx.controller.signal.removeEventListener('abort', abort); resolve(); }, milliseconds);
    ctx.controller.signal.addEventListener('abort', abort, { once: true });
  });
}
async function pageReady(ctx, tab, nonce) {
  if (!/^https?:/.test(tab.url || '')) return tab.status === 'complete';
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: ctx.tabId }, func: browserTool, args: [{ type: 'readiness' }], injectImmediately: true
    });
    assertRunning(ctx);
    const ready = results[0]?.result;
    return ready?.ready === true && ready.url === tab.url && (!nonce || ready.nonce === nonce);
  } catch {
    assertRunning(ctx);
    return false;
  }
}

async function settled(ctx) {
  await pause(ctx, 350);
  const end = Date.now() + 15_000;
  let stableUrl;
  let stableSince = 0;
  while (Date.now() < end) {
    const tab = await currentTab(ctx);
    const ready = await pageReady(ctx, tab);
    if (!ready || tab.url !== stableUrl) {
      stableUrl = tab.url;
      stableSince = ready ? Date.now() : 0;
    } else if (!stableSince) {
      stableSince = Date.now();
    } else if (Date.now() - stableSince >= 800) return tab;
    await pause(ctx, 200);
  }
  throw new Error('Page did not become interactive at a stable URL within 15 seconds.');
}
async function authorizeOrigin(ctx, url) {
  assertRunning(ctx);
  if (!ctx.consented) throw new Error('Run consent is required.');
  const origin = webUrl(url).origin;
  if (!await chrome.permissions.contains({ origins: [`${origin}/*`] })) throw new Error('Website access is unavailable. Grant site access and restart the run.');
  assertRunning(ctx);
  ctx.origins.add(origin);
}
async function snapshot(ctx) {
  let tab = await currentTab(ctx);
  if (!/^https?:/.test(tab.url || '')) {
    return { url: 'Browser-internal page (not accessible)', text: 'Use navigate to open an HTTP(S) website.', elements: [], tabUrl: tab.url };
  }
  await authorizeOrigin(ctx, tab.url);
  tab = await currentTab(ctx);
  const origin = webUrl(tab.url).origin;
  if (!ctx.origins.has(origin)) throw new Error('Page changed during site approval. Restart the run.');
  const probe = await dom(ctx, { type: 'probe' });
  if (probe.blocked) throw new Error('Sensitive page detected. This MVP does not automate login, payment or other identified sensitive pages.');
  if (probe.origin !== origin) throw new Error('Page changed during inspection.');
  const data = await dom(ctx, { type: 'snapshot' });
  if (webUrl(data.url).origin !== origin) throw new Error('Page changed during inspection.');
  if (!ctx.shared.has(origin)) {
    log(`Sharing page context from ${origin} under this run's consent.`);
    ctx.shared.add(origin);
  }
  if ((await currentTab(ctx)).url !== tab.url) throw new Error('Page navigated during sharing approval. Restart to inspect the new page.');
  return { ...data, tabUrl: tab.url };
}

async function execute(ctx, action, data) {
  const tab = await currentTab(ctx);
  if (data.tabUrl && tab.url !== data.tabUrl) throw new PageChangedError('Page changed before action dispatch.');
  if (needsApproval(action)) {
    const element = data.elements.find(e => e.id === action.element);
    await gate(ctx, 'Approve this browser action? Page labels and model proposals can be misleading. Verify the actual page before approving.',
      JSON.stringify({ action, target: element, site: data.url }, null, 2));
    if ((await currentTab(ctx)).url !== tab.url) throw new Error('Page changed during action approval.');
  }
  assertRunning(ctx);
  if (action.type === 'navigate') {
    await authorizeOrigin(ctx, action.url);
    await currentTab(ctx);
    await chrome.tabs.update(ctx.tabId, { url: action.url });
  } else if (action.type === 'back' || action.type === 'forward') {
    await chrome.tabs[action.type === 'back' ? 'goBack' : 'goForward'](ctx.tabId);
  } else if (action.type === 'wait') {
    await pause(ctx, action.milliseconds);
  } else {
    const result = await dom(ctx, { type: 'act', nonce: data.nonce, action });
    if (result?.navigateUrl && action.type === 'click') {
      webUrl(result.navigateUrl);
      await authorizeOrigin(ctx, result.navigateUrl);
      if ((await currentTab(ctx)).url !== tab.url) throw new Error('Page changed during destination approval.');
      await chrome.tabs.update(ctx.tabId, { url: result.navigateUrl });
    } else if (typeof result !== 'string') {
      if (result == null && ['click', 'submit'].includes(action.type)) {
        await settled(ctx);
        if ((await currentTab(ctx)).url === tab.url) throw new Error(`${action.type} returned no result and no navigation was observed. Action was not retried.`);
      } else throw new Error(`${action.type} returned no usable result. Action was not retried.`);
    }
  }
  await settled(ctx);
}

async function acquire(ctx) {
  const port = chrome.runtime.connect({ name: 'automation-run' });
  ctx.port = port;
  await new Promise((resolve, reject) => {
    port.onMessage.addListener(message => message.acquired ? resolve() : reject(new Error('Another Browser Pilot panel is already running a task.')));
    port.onDisconnect.addListener(() => { ctx.controller.abort(); reject(new Error('Automation connection closed.')); });
  });
  ctx.heartbeat = setInterval(() => { try { port.postMessage({ ping: true }); } catch { stop(); } }, 20_000);
}

$('start').addEventListener('click', async () => {
  if (run) return;
  const task = $('task').value.trim();
  if (!task) { $('result').textContent = 'Enter instructions first.'; return; }
  const ctx = { controller: new AbortController(), origins: new Set(), shared: new Set() };
  run = ctx;
  $('start').disabled = true;
  $('stop').disabled = false;
  $('config-form').querySelectorAll('button, input').forEach(el => { el.disabled = true; });
  $('log').replaceChildren();
  $('results-panel').hidden = true;
  $('summary').textContent = '';
  $('summary-source').textContent = '';
  $('status').textContent = 'Preparing';
  $('result').textContent = 'Preparing task…';
  const timeout = setTimeout(() => stop('Two-minute run limit reached.'), RUN_TIMEOUT);
  try {
    const stored = await chrome.storage.local.get('config');
    if (!stored.config) throw new Error('Save your Azure OpenAI configuration first.');
    const config = configFrom(stored.config);
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error('No active browser tab.');
    ctx.tabId = tab.id;
    await acquire(ctx);
    await gate(ctx, 'Allow automatic browser actions and page sharing for this run?', `Deployment: ${config.deployment}\nEndpoint: ${config.endpoint}\n\n${task}\n\nThis run may navigate to any HTTP(S) website, send visible page text and element labels to Azure, and automatically fill, click and submit forms without further approval. These actions can change data or send messages. Use only non-confidential sites and instructions. Redaction is imperfect. Stop cannot undo completed actions. Chrome site permissions persist until revoked.`, ['https://*/*', 'http://*/*']);
    ctx.consented = true;
    const history = [];
    let pageRefreshes = 0;
    const refreshPage = async () => {
      if (++pageRefreshes > 3) throw new Error('Page kept changing. Stopped after 3 refreshes without replaying stale actions.');
      $('status').textContent = 'Page changed';
      $('result').textContent = 'Waiting for redirects to settle, then inspecting the current page…';
      $('results-panel').hidden = true;
      log(`Page changed; discarded stale model decision. Refresh ${pageRefreshes}/3.`);
      await settled(ctx);
    };
    for (let step = 0; step < MAX_ACTIONS; step++) {
      assertRunning(ctx);
      $('status').textContent = `Step ${step + 1}/${MAX_ACTIONS}`;
      const data = await snapshot(ctx);
      $('result').textContent = 'Asking your model for the next action…';
      // Keep the full current URL local; query strings are not model context.
      const { tabUrl, ...modelData } = data;
      const signal = AbortSignal.any([ctx.controller.signal, AbortSignal.timeout(30_000)]);
      const action = await nextAction(config, task, modelData, history, signal);
      assertRunning(ctx);
      const latestTab = await currentTab(ctx);
      if (latestTab.url !== tabUrl || !await pageReady(ctx, latestTab, data.nonce)) {
        await refreshPage();
        step--;
        continue;
      }
      if (action.type === 'done') {
        $('results-panel').hidden = false;
        $('summary').textContent = action.message;
        $('results-note').textContent = 'Automation model report — verify against the page.';
        $('summary-source').textContent = modelData.url ? `Observed page: ${modelData.url}` : '';
        if (wantsSummary(task)) {
          $('status').textContent = 'Summarizing';
          $('result').textContent = 'Writing an evidence-based summary with your Azure model…';
          try {
            const summarySignal = AbortSignal.any([ctx.controller.signal, AbortSignal.timeout(30_000)]);
            const summary = await summarizeResults(config, task, modelData, history, action.message, summarySignal);
            assertRunning(ctx);
            const summaryTab = await currentTab(ctx);
            if (summaryTab.url !== tabUrl || !await pageReady(ctx, summaryTab, data.nonce)) {
              await refreshPage();
              step--;
              continue;
            }
            $('summary').textContent = summary;
            $('results-note').textContent = 'AI-generated from the observed page and action history. Page content may be incomplete.';
          } catch (error) {
            assertRunning(ctx);
            if (pageRefreshes > 3) throw error;
            $('results-note').textContent = `Summary unavailable: ${error.message} Showing the automation model report instead.`;
            ctx.finalStatus = 'Summary unavailable';
          }
        }
        $('result').textContent = 'Run finished. See Results below.';
        ctx.finalStatus ||= 'Completed';
        log('Model finished the task.');
        return;
      }
      $('result').textContent = actionProgress(action, data.elements);
      try {
        await execute(ctx, action, data);
      } catch (error) {
        if (!(error instanceof PageChangedError)) throw error;
        await refreshPage();
        step--;
        continue;
      }
      const description = actionDescription(action);
      log(description);
      history.push({ step: step + 1, action: description, result: 'Dispatched; inspect current snapshot to verify outcome.' });
    }
    ctx.finalStatus = 'Action limit reached';
    $('result').textContent = '20-action limit reached. Review the page before starting another run.';
  } catch (error) {
    ctx.finalStatus = ctx.controller.signal.aborted ? 'Stopped' : 'Failed';
    $('result').textContent = ctx.controller.signal.aborted ? 'Run stopped or timed out. Completed actions cannot be undone.' : error.message;
    log('Run ended. See status above.');
  } finally {
    clearTimeout(timeout);
    clearInterval(ctx.heartbeat);
    ctx.port?.disconnect();
    ctx.controller.abort();
    if (pendingGate?.ctx === ctx) pendingGate = undefined;
    $('gate').hidden = true;
    run = undefined;
    $('start').disabled = false;
    $('stop').disabled = true;
    $('config-form').querySelectorAll('button, input').forEach(el => { el.disabled = false; });
    $('status').textContent = ctx.finalStatus || 'Stopped';
  }
});

try {
  const { config } = await chrome.storage.local.get('config');
  if (config) {
    $('endpoint').value = config.endpoint;
    $('deployment').value = config.deployment;
    $('key').placeholder = 'Saved locally — re-enter to change settings';
    $('settings').open = false;
  }
} catch { $('result').textContent = 'Could not read extension settings.'; }
