// This function is serialized by chrome.scripting; keep it self-contained.
export function browserTool(command) {
  try {
  const stateKey = '__browserPilotState';
  if (command.type === 'readiness') {
    return {
      url: location.href,
      ready: document.readyState !== 'loading' && !!document.body,
      nonce: globalThis[stateKey]?.nonce
    };
  }
  const secretPattern = /password|passwd|secret|token|csrf|xsrf|api.?key|credit.?card|card.?number|cvv|cvc|social.?security|ssn|one.?time|otp|iban/i;
  const visible = el => {
    const rect = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none';
  };
  const sensitive = el => ['password', 'file', 'hidden'].includes(el.type) || secretPattern.test([
    el.name, el.id, el.autocomplete, el.getAttribute('aria-label'), el.getAttribute('placeholder'),
    ...Array.from(el.labels || [], label => label.innerText)
  ].join(' '));
  const blocked = () => /\/(login|signin|sign-in|checkout|payment|banking|medical|patient)(\/|$)/i.test(location.pathname)
    || Array.from(document.querySelectorAll('input')).some(el => visible(el) && sensitive(el) && el.type !== 'file');
  const clean = value => String(value || '')
    .replace(/\bBearer\s+\S+/gi, '[redacted]')
    .replace(/\b[A-Za-z0-9_\-]{32,}\b/g, '[redacted]')
    .replace(/\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b/g, '[email]')
    .replace(/\b(?:\d[ -]?){13,19}\b/g, '[number]');
  const safeUrl = raw => {
    try {
      const url = new URL(raw, location.href);
      if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) return '';
      return url.origin + url.pathname;
    } catch { return ''; }
  };
  const label = el => {
    const labels = Array.from(el.labels || [], item => {
      const copy = item.cloneNode(true);
      copy.querySelectorAll('input, textarea, select, [contenteditable]').forEach(control => control.remove());
      return copy.textContent.trim();
    }).join(' ');
    return clean(el.getAttribute('aria-label') || labels
      || (!el.isContentEditable && el.innerText) || el.getAttribute('placeholder') || el.getAttribute('title') || el.name || el.tagName.toLowerCase()).trim().slice(0, 160);
  };
  const fingerprint = el => JSON.stringify([el.tagName, el.type, label(el), el.getAttribute('href'), el.form?.action, el.form?.method, el.disabled]);

  if (command.type === 'probe') return { origin: location.origin, blocked: blocked() };
  if (blocked()) throw new Error('Sensitive page detected. Browser Pilot will not inspect or automate this page.');
  if (command.type === 'snapshot') {
    const entries = Array.from(document.querySelectorAll('a[href], button, input, textarea, select, [role="button"], [role="tab"], [contenteditable="true"]'))
      .filter(el => visible(el) && !sensitive(el) && !el.disabled).slice(0, 120);
    const nonce = crypto.randomUUID();
    const refs = new Map();
    const elements = entries.map((el, index) => {
      const id = `e${index + 1}`;
      refs.set(id, { el, fingerprint: fingerprint(el) });
      return {
        id, tag: el.tagName.toLowerCase(), type: el.type || '', label: label(el),
        ...(el.getAttribute('role') ? { role: el.getAttribute('role') } : {}),
        ...(el.hasAttribute('aria-selected') ? { selected: el.getAttribute('aria-selected') === 'true' } : {}),
        ...(el.matches('a[href]') ? { href: safeUrl(el.href) } : {}),
        ...(el.tagName === 'SELECT' ? { options: Array.from(el.options).slice(0, 40).map(o => ({ value: clean(o.value).slice(0, 120), label: clean(o.text).slice(0, 120) })) } : {}),
        ...(el.type === 'checkbox' || el.type === 'radio' ? { checked: el.checked } : {})
      };
    });
    globalThis[stateKey] = { nonce, url: location.href, refs };
    const chunks = [];
    const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
    let node;
    let size = 0;
    while ((node = walker.nextNode()) && size < 6000) {
      const parent = node.parentElement;
      if (!parent || parent.closest('script, style, noscript, input, textarea, select, [contenteditable], [hidden], [aria-hidden="true"]') || !visible(parent)) continue;
      const text = clean(node.textContent.trim());
      if (text) { chunks.push(text); size += text.length; }
    }
    return { nonce, url: safeUrl(location.href), title: clean(document.title).slice(0, 200), text: chunks.join(' ').slice(0, 6000), elements };
  }

  const state = globalThis[stateKey];
  if (!state || state.nonce !== command.nonce || state.url !== location.href) throw new Error('Page changed; start a new run to inspect fresh elements.');
  const action = command.action;
  if (action.type === 'scroll') {
    const y = action.direction === 'top' ? -window.scrollY : action.direction === 'bottom' ? document.documentElement.scrollHeight : (action.direction === 'up' ? -1 : 1) * innerHeight * 0.8;
    window.scrollBy({ top: y, behavior: 'instant' });
    return 'Page scrolled.';
  }
  const ref = state.refs.get(action.element);
  const el = ref?.el;
  if (!el || !el.isConnected || !visible(el) || sensitive(el) || el.disabled || ref.fingerprint !== fingerprint(el)) {
    throw new Error('Element changed or is unavailable; start a new run.');
  }
  el.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
  // News cards may layer a duplicate anchor over their accessible headline link.
  let equivalentLink;
  const reachable = Array.from(el.getClientRects()).some(rect => {
    const left = Math.max(0, rect.left);
    const right = Math.min(innerWidth, rect.right);
    const top = Math.max(0, rect.top);
    const bottom = Math.min(innerHeight, rect.bottom);
    if (right <= left || bottom <= top) return false;
    return [0.5, 0.15, 0.85].some(x => [0.5, 0.15, 0.85].some(y => {
      const hit = document.elementFromPoint(left + (right - left) * x, top + (bottom - top) * y);
      if (hit && (hit === el || el.contains(hit))) return true;
      const anchor = hit?.closest('a[href]');
      if (action.type === 'click' && el.matches('a[href]') && anchor
          && (anchor.parentElement === el.parentElement || anchor.parentElement?.parentElement === el.parentElement)
          && !['BODY', 'HTML'].includes(el.parentElement?.tagName) && anchor.href === el.href
          && !anchor.closest('dialog, [role="dialog"], [aria-modal="true"]')
          && !el.closest('dialog, [role="dialog"], [aria-modal="true"]')
          && !anchor.hasAttribute('download') && !el.hasAttribute('download')
          && ['', '_self', '_blank'].includes(anchor.target)
          && ['', '_self', '_blank'].includes(el.target)) {
        equivalentLink = anchor;
        return true;
      }
      return false;
    }));
  });
  if (!reachable) throw new Error(`Element "${label(el)}" is covered by another element. Close any dialog or overlay and retry.`);
  if (action.type === 'fill') {
    if (el.readOnly) throw new Error('Field is read-only.');
    if (el.isContentEditable) {
      el.textContent = action.value;
    } else if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
      if (el instanceof HTMLInputElement && !['text', 'email', 'tel', 'url', 'search', 'number', 'date', 'datetime-local', 'month', 'week', 'time'].includes(el.type)) {
        throw new Error('This input cannot be filled.');
      }
      const prototype = el instanceof HTMLInputElement ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype;
      Object.getOwnPropertyDescriptor(prototype, 'value').set.call(el, action.value);
    } else throw new Error('Element is not a text field.');
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return 'Field filled.';
  }
  if (action.type === 'select') {
    if (!(el instanceof HTMLSelectElement) || !Array.from(el.options).some(o => o.value === action.value && !o.disabled)) throw new Error('Select option is unavailable.');
    el.value = action.value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return 'Option selected.';
  }
  const form = el.form;
  const submitting = action.type === 'submit' || (action.type === 'click' && form && ['submit', 'image'].includes(el.type));
  if (submitting) {
    const unsafeField = field => {
      if (field.type === 'hidden') {
        const metadata = [field.name, field.id, field.autocomplete].join(' ');
        // Anti-forgery values are submitted by the browser, never exposed in snapshots.
        if (/^(csrf|xsrf|sxsrf|csrfmiddlewaretoken|_csrf|_token|__requestverificationtoken|csrf_token|xsrf_token)$/i.test(field.name)) return false;
        return secretPattern.test(metadata);
      }
      return sensitive(field);
    };
    if (!form || Array.from(form.elements).some(unsafeField)) throw new Error('Form contains password, payment, file or other sensitive fields.');
    const destination = new URL(el.getAttribute('formaction') || form.action, location.href);
    if (destination.origin !== location.origin || !['http:', 'https:'].includes(destination.protocol)) throw new Error('Cross-origin form submissions are blocked.');
    if ((el.getAttribute('formtarget') || form.target || '_self') !== '_self') throw new Error('Forms opening another tab are unsupported.');
  }
  if (action.type === 'submit') {
    if (el.type === 'submit' || el.type === 'image') form.requestSubmit(el);
    else form.requestSubmit();
    return 'Submission requested; verify the next page for success.';
  }
  if (action.type === 'click') {
    const link = el.closest('a[href]');
    if (link) {
      const destination = new URL(link.href, location.href);
      if (!['http:', 'https:'].includes(destination.protocol) || destination.username || destination.password || link.hasAttribute('download')) throw new Error('Unsupported link.');
      if (link.target && !['_self', '_blank'].includes(link.target)) throw new Error('Named target frames are unsupported.');
      if (equivalentLink || destination.origin !== location.origin || link.target === '_blank') {
        return { navigateUrl: destination.href };
      }
    }
    el.click();
    return 'Click dispatched; verify the next snapshot for the result.';
  }
  throw new Error('Unsupported DOM action.');
  } catch (error) {
    // Chrome does not reliably serialize exceptions from injected functions.
    return { error: error.message || 'Browser action failed.' };
  }
}
