import test from 'node:test';
import assert from 'node:assert/strict';
import { downloadFile } from '../src/downloads.js';
import { validateAction, SYSTEM_PROMPT } from '../src/core.js';

test('download action requires a current element and prompt allows downloads, not uploads', () => {
  assert.deepEqual(validateAction({ type: 'download', element: 'e1' }, [{ id: 'e1' }]), { type: 'download', element: 'e1' });
  assert.throws(() => validateAction({ type: 'download', element: 'e2' }, [{ id: 'e1' }]));
  assert.match(SYSTEM_PROMPT, /Downloads of any file type are allowed/);
  assert.match(SYSTEM_PROMPT, /No file uploads/);
});

test('downloads track only their own ID and omit local paths from results', async () => {
  const api = {
    download: async options => { assert.equal(options.saveAs, false); assert.equal(options.conflictAction, 'uniquify'); return 7; },
    search: async query => { assert.deepEqual(query, { id: 7 }); return [{ state: 'complete', bytesReceived: 100, filename: 'private-path' }]; },
    cancel: async () => { throw new Error('Should not cancel'); }
  };
  assert.deepEqual(await downloadFile('https://example.com/file.exe', new AbortController().signal, api), { state: 'complete', bytesReceived: 100 });
});

test('interruptions, timeout and Stop never claim completion', async () => {
  let cancelled = 0;
  const api = { download: async () => 7, search: async () => [{ state: 'interrupted', error: 'NETWORK_FAILED' }], cancel: async id => { assert.equal(id, 7); cancelled++; } };
  await assert.rejects(downloadFile('https://example.com/file', new AbortController().signal, api), /NETWORK_FAILED/);
  api.search = async () => [{ state: 'in_progress' }];
  await assert.rejects(downloadFile('https://example.com/file', new AbortController().signal, api, 10), /timeout/);
  assert.equal(cancelled, 1);
  const controller = new AbortController();
  const promise = downloadFile('https://example.com/file', controller.signal, api);
  setTimeout(() => controller.abort(), 5);
  await assert.rejects(promise, /stopped/);
  assert.equal(cancelled, 2);
});

test('invalid URL and already stopped run never start download', async () => {
  const api = { download: async () => { throw new Error('must not start'); } };
  await assert.rejects(downloadFile('javascript:alert(1)', new AbortController().signal, api), /HTTP/);
  await assert.rejects(downloadFile('https://example.com/file', AbortSignal.abort(), api), /abort/i);
});
