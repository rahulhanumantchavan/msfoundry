import { chromium } from 'playwright';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { mkdtemp, cp, readFile, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { browserTool } from '../src/dom.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const temporary = await mkdtemp(path.join(tmpdir(), 'browser-pilot-test-'));
const fixture = `<!doctype html><html><head><title>Pilot fixture</title></head><body>
<h1>Public contact form</h1><p>Welcome. Contact info@example.com. Bearer very-secret-token</p>
<form action="/done" method="get"><label>Name <input id="name" name="name" value="PRIVATE_INITIAL_VALUE"></label>
<label>Topic <select id="topic" name="topic"><option value="general">General</option><option value="demo">Demo</option></select></label>
<label><input id="agree" type="checkbox">Agree</label><button id="send" type="submit">Send</button></form>
<a id="next" href="/next">Next page</a><button id="mutable">Original button</button>
<div style="height:1600px">Scroll area</div><p>Bottom</p></body></html>`;
let lastSubmission;
const server = createServer(async (req, res) => {
  if (req.url === '/sample.jpg') {
    res.writeHead(200, { 'Content-Type': 'image/jpeg', 'Content-Disposition': 'attachment; filename="sample-image-100kb.jpg"' });
    res.end(Buffer.alloc(100 * 1024, 0));
    return;
  }
  if (req.url === '/downloads') {
    res.end('<!doctype html><title>Files</title><ul><li>sample-image-100kb.jpg <a download href="/sample.jpg">Download</a></li></ul>');
    return;
  }
  if (req.url.startsWith('/done')) {
    let body = '';
    for await (const chunk of req) body += chunk;
    lastSubmission = { method: req.method, body };
  }
  res.setHeader('Content-Type', 'text/html');
  if (req.url.startsWith('/done')) res.end('<!doctype html><title>Done</title><h1>Thanks, your form was submitted</h1>');
  else if (req.url === '/next') res.end('<!doctype html><title>Next</title><h1>Next page</h1>');
  else if (req.url === '/login') res.end('<!doctype html><label>Password<input type="password"></label>');
  else if (req.url === '/search-home') res.end('<!doctype html><title>Search</title><form role="search" action="/search" method="get"><label>Search query<textarea name="q"></textarea></label><input type="hidden" name="source" value="homepage"><input type="hidden" name="sxsrf" value="local-antiforgery"><button>Search</button></form>');
  else if (req.url.startsWith('/search?')) res.end('<!doctype html><title>Search results</title><h1>Results</h1><a target="_blank" href="/article?ref=first">Azure OpenAI overview</a>');
  else if (req.url.startsWith('/article?')) res.end('<!doctype html><title>Azure OpenAI overview</title><main>Azure OpenAI provides language models through Azure APIs. Applications can generate text and summarize documents.</main>');
  else res.end(fixture);
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const origin = `http://127.0.0.1:${server.address().port}`;
let context;
let passed = 0;
async function test(name, callback) {
  await callback();
  passed++;
  console.log(`PASS ${name}`);
}
try {
  const extensionPath = path.join(temporary, 'extension');
  await cp(path.join(root, 'src'), path.join(extensionPath, 'src'), { recursive: true });
  const manifest = JSON.parse(await readFile(path.join(root, 'manifest.json'), 'utf8'));
  // Pre-grant fixture and fake Azure origins only in the disposable test copy.
  manifest.host_permissions = ['http://*/*', 'https://*/*'];
  await writeFile(path.join(extensionPath, 'manifest.json'), JSON.stringify(manifest));
  context = await chromium.launchPersistentContext(path.join(temporary, 'profile'), {
    channel: 'chromium', headless: true, downloadsPath: path.join(temporary, 'downloads'), acceptDownloads: true,
    args: [`--disable-extensions-except=${extensionPath}`, `--load-extension=${extensionPath}`]
  });
  const worker = context.serviceWorkers()[0] || await context.waitForEvent('serviceworker');
  const extensionId = new URL(worker.url()).host;
  const page = await context.newPage();
  const tool = async command => {
    const result = await page.evaluate(browserTool, command);
    if (result?.error) throw new Error(result.error);
    return result;
  };
  let data;
  const element = name => data.elements.find(e => e.label === name)?.id;
  const act = action => tool({ type: 'act', nonce: data.nonce, action });

  await test('snapshot excludes values and redacts obvious secrets', async () => {
    await page.goto(origin);
    data = await tool({ type: 'snapshot' });
    assert.ok(element('Name'));
    const text = JSON.stringify(data);
    assert.ok(!text.includes('PRIVATE_INITIAL_VALUE'));
    assert.ok(!text.includes('info@example.com'));
    assert.ok(!text.includes('very-secret-token'));
    assert.match(text, /\[redacted\]/);
  });
  await test('fill triggers native input/change, select works, checkbox clicks', async () => {
    await page.evaluate(() => { window.events = []; document.querySelector('#name').addEventListener('input', () => window.events.push('input')); document.querySelector('#name').addEventListener('change', () => window.events.push('change')); });
    await act({ type: 'fill', element: element('Name'), value: 'Ada' });
    assert.equal(await page.locator('#name').inputValue(), 'Ada');
    assert.deepEqual(await page.evaluate(() => window.events), ['input', 'change']);
    await act({ type: 'select', element: element('Topic'), value: 'demo' });
    assert.equal(await page.locator('#topic').inputValue(), 'demo');
    await act({ type: 'click', element: element('Agree') });
    assert.equal(await page.locator('#agree').isChecked(), true);
  });
  await test('scroll moves the page', async () => {
    await act({ type: 'scroll', direction: 'bottom' });
    assert.ok(await page.evaluate(() => scrollY > 0));
  });
  await test('changed labels and replaced elements fail closed', async () => {
    await page.locator('#mutable').evaluate(el => { el.textContent = 'Delete everything'; });
    await assert.rejects(act({ type: 'click', element: element('Original button') }), /Element changed/);
    await page.locator('#name').evaluate(el => { el.outerHTML = '<input id="name">'; });
    await assert.rejects(act({ type: 'fill', element: element('Name'), value: 'oops' }), /Element changed/);
  });
  await test('submission requests navigate to result page', async () => {
    await page.goto(origin);
    data = await tool({ type: 'snapshot' });
    await act({ type: 'fill', element: element('Name'), value: 'Ada' });
    await act({ type: 'submit', element: element('Send') });
    await page.waitForURL(`${origin}/done?**`);
    assert.match(await page.locator('h1').innerText(), /submitted/);
  });
  await test('click navigation, history and stale document protection', async () => {
    await page.goto(origin);
    data = await tool({ type: 'snapshot' });
    await act({ type: 'click', element: element('Next page') });
    await page.waitForURL(`${origin}/next`);
    await assert.rejects(act({ type: 'click', element: element('Next page') }), /Page changed/);
    await page.goBack();
    assert.equal(new URL(page.url()).pathname, '/');
    await page.goForward();
    assert.equal(new URL(page.url()).pathname, '/next');
  });
  await test('sensitive pages are blocked before context collection', async () => {
    await page.goto(`${origin}/login`);
    assert.equal((await tool({ type: 'probe' })).blocked, true);
    await assert.rejects(tool({ type: 'snapshot' }), /Sensitive page/);
  });
  await test('cross-origin forms stay blocked while local CSRF fields can submit', async () => {
    await page.goto(origin);
    await page.locator('form').evaluate(el => { el.action = 'https://example.com'; });
    data = await tool({ type: 'snapshot' });
    await assert.rejects(act({ type: 'submit', element: element('Send') }), /Cross-origin/);
    await page.locator('form').evaluate(el => { el.action = '/done'; el.insertAdjacentHTML('beforeend', '<input type="hidden" name="csrf" value="private">'); });
    data = await tool({ type: 'snapshot' });
    await act({ type: 'submit', element: element('Send') });
    await page.waitForURL(`${origin}/done?**`);
  });

  await test('POST forms preserve method and hidden anti-forgery fields without exposing them', async () => {
    await page.goto(origin);
    await page.locator('form').evaluate(form => {
      form.method = 'post';
      form.insertAdjacentHTML('beforeend', '<input type="hidden" name="csrfmiddlewaretoken" value="LOCAL_CSRF_VALUE"><input type="hidden" name="recordId" value="42">');
    });
    data = await tool({ type: 'snapshot' });
    assert.ok(!JSON.stringify(data).includes('LOCAL_CSRF_VALUE'));
    await act({ type: 'fill', element: element('Name'), value: 'Post Name' });
    await act({ type: 'submit', element: element('Send') });
    await page.waitForURL(`${origin}/done`);
    assert.equal(lastSubmission.method, 'POST');
    const fields = new URLSearchParams(lastSubmission.body);
    assert.equal(fields.get('name'), 'Post Name');
    assert.equal(fields.get('csrfmiddlewaretoken'), 'LOCAL_CSRF_VALUE');
    assert.equal(fields.get('recordId'), '42');
  });

  await test('ordinary full name and email fields accept supplied values and submit', async () => {
    await page.goto(origin);
    await page.locator('form').evaluate(form => {
      form.method = 'post';
      form.innerHTML = '<label>Full Name<input name="fullName" autocomplete="name" required></label><label>Email<input type="email" name="email" autocomplete="email" required></label><button type="submit">Submit</button>';
    });
    assert.equal((await tool({ type: 'probe' })).blocked, false);
    data = await tool({ type: 'snapshot' });
    await act({ type: 'fill', element: element('Full Name'), value: 'Test User' });
    await act({ type: 'fill', element: element('Email'), value: 'testuser@gmail.com' });
    data = await tool({ type: 'snapshot' });
    assert.ok(!JSON.stringify(data).includes('testuser@gmail.com'));
    await act({ type: 'submit', element: element('Submit') });
    await page.waitForURL(`${origin}/done`);
    const fields = new URLSearchParams(lastSubmission.body);
    assert.equal(fields.get('fullName'), 'Test User');
    assert.equal(fields.get('email'), 'testuser@gmail.com');
    const result = await tool({ type: 'snapshot' });
    assert.match(result.text, /your form was submitted/);
  });

  await test('partially covered news links remain clickable without clicking the overlay', async () => {
    await page.goto(origin);
    await page.locator('body').evaluate(body => {
      body.innerHTML = '<div role="tab" aria-selected="false" tabindex="0">India</div><a id="headline" href="/next" style="display:block;position:relative;width:300px;height:90px">First article</a><div id="cover" style="position:fixed;z-index:10;width:80px;height:40px">Overlay</div>';
      const rect = document.querySelector('#headline').getBoundingClientRect();
      Object.assign(document.querySelector('#cover').style, { left: `${rect.x + 110}px`, top: `${rect.y + 25}px` });
      window.overlayClicks = 0;
      document.querySelector('#cover').onclick = () => window.overlayClicks++;
      document.querySelector('#headline').onclick = event => { event.preventDefault(); window.headlineClicked = true; };
    });
    data = await tool({ type: 'snapshot' });
    assert.equal(data.elements.find(e => e.label === 'India').role, 'tab');
    assert.equal(data.elements.find(e => e.label === 'India').selected, false);
    await act({ type: 'click', element: element('First article') });
    assert.equal(await page.evaluate(() => window.headlineClicked), true);
    assert.equal(await page.evaluate(() => window.overlayClicks), 0);
  });
  await test('multiline headlines are hit-tested within individual line rectangles', async () => {
    await page.goto(origin);
    await page.locator('body').evaluate(body => {
      body.innerHTML = '<div style="width:180px;font:20px/80px sans-serif"><a id="headline" href="/next">First India headline with several lines of text</a></div>';
      document.querySelector('#headline').onclick = event => { event.preventDefault(); window.headlineClicked = true; };
    });
    assert.ok(await page.locator('#headline').evaluate(el => el.getClientRects().length > 1));
    data = await tool({ type: 'snapshot' });
    await act({ type: 'click', element: element('First India headline with several lines of text') });
    assert.equal(await page.evaluate(() => window.headlineClicked), true);
  });
  await test('full-page overlays still block actions with a useful target label', async () => {
    await page.goto(origin);
    data = await tool({ type: 'snapshot' });
    await page.locator('body').evaluate(body => body.insertAdjacentHTML('beforeend', '<div role="dialog" style="position:fixed;inset:0;z-index:999;background:white">Consent dialog</div>'));
    await assert.rejects(act({ type: 'click', element: element('Next page') }), /Next page.*covered.*Close any dialog/);
    assert.equal(new URL(page.url()).pathname, '/');
  });

  await test('overlapping sibling news links with identical destinations resolve without dispatching a hidden click', async () => {
    await page.goto(origin);
    await page.locator('body').evaluate(body => {
      body.innerHTML = '<div style="position:relative;width:300px;height:100px"><a id="headline" aria-label="First India story" href="/next?article=1" target="_blank" style="position:absolute;inset:0">Headline</a><a id="overlay-link" href="/next?article=1" style="position:absolute;inset:0;z-index:2">Image link</a></div>';
      window.dispatched = false;
      document.querySelector('#headline').onclick = () => window.dispatched = true;
    });
    data = await tool({ type: 'snapshot' });
    const result = await act({ type: 'click', element: element('First India story') });
    assert.equal(result.navigateUrl, `${origin}/next?article=1`);
    assert.equal(await page.evaluate(() => window.dispatched), false);
    await page.locator('#overlay-link').evaluate(el => {
      const wrapper = document.createElement('div');
      el.replaceWith(wrapper);
      wrapper.append(el);
    });
    assert.equal((await act({ type: 'click', element: element('First India story') })).navigateUrl, `${origin}/next?article=1`);
    await page.locator('#overlay-link').evaluate(el => { el.href = '/next?article=2'; });
    await assert.rejects(act({ type: 'click', element: element('First India story') }), /covered/);
    await page.locator('#overlay-link').evaluate(el => { el.href = '/next?article=1'; el.setAttribute('role', 'dialog'); });
    await assert.rejects(act({ type: 'click', element: element('First India story') }), /covered/);
    await page.locator('#overlay-link').evaluate(el => { el.removeAttribute('role'); el.setAttribute('download', 'article'); });
    await assert.rejects(act({ type: 'click', element: element('First India story') }), /covered/);
  });

  await test('short sensitive acronyms inside generated IDs do not block ordinary forms', async () => {
    await page.goto(origin);
    await page.locator('form').evaluate(form => {
      form.insertAdjacentHTML('beforeend', '<input type="hidden" name="metadata" id="abcotp123ssnxyz" value="local-only">');
    });
    data = await tool({ type: 'snapshot' });
    await act({ type: 'submit', element: element('Send') });
    await page.waitForURL(`${origin}/done?**`);
  });
  await test('explicit sensitive field names remain blocked with value-free diagnostics', async () => {
    for (const name of ['otp', 'user_ssn', 'card_cvv', 'iban']) {
      await page.goto(origin);
      await page.locator('form').evaluate((form, name) => {
        const field = document.createElement('input');
        field.type = 'hidden'; field.name = name; field.value = 'DO_NOT_DISPLAY_VALUE'; form.append(field);
      }, name);
      data = await tool({ type: 'snapshot' });
      const result = await page.evaluate(browserTool, { type: 'act', nonce: data.nonce, action: { type: 'submit', element: element('Send') } });
      assert.ok(result.error.includes(name));
      assert.ok(!result.error.includes('DO_NOT_DISPLAY_VALUE'));
    }
  });

  await test('empty file inputs do not block text-only forms; selected files still block submission', async () => {
    await page.goto(origin);
    await page.locator('form').evaluate(form => {
      form.insertAdjacentHTML('beforeend', '<input id="upload" type="file" name="attachment" hidden>');
    });
    data = await tool({ type: 'snapshot' });
    assert.ok(!data.elements.some(e => e.type === 'file'));
    await act({ type: 'fill', element: element('Name'), value: 'Text only' });
    await act({ type: 'submit', element: element('Send') });
    await page.waitForURL(`${origin}/done?**`);
    assert.equal(new URL(page.url()).searchParams.get('name'), 'Text only');
    await page.goto(origin);
    await page.locator('form').evaluate(form => {
      form.insertAdjacentHTML('beforeend', '<input id="upload" type="file" name="attachment" hidden>');
    });
    await page.locator('#upload').setInputFiles({ name: 'private.txt', mimeType: 'text/plain', buffer: Buffer.from('private fixture') });
    data = await tool({ type: 'snapshot' });
    await assert.rejects(act({ type: 'submit', element: element('Send') }), /blocked file field/);
    assert.equal(new URL(page.url()).pathname, '/');
  });

  const panel = await context.newPage();
  await panel.goto(`chrome-extension://${extensionId}/src/panel.html`);
  const browserErrors = [];
  panel.on('pageerror', error => browserErrors.push(error.message));
  await panel.evaluate(async () => {
    await chrome.storage.local.set({ config: { endpoint: 'https://pilot-test.openai.azure.com', deployment: 'test', key: 'test-not-real' } });
  });
  await panel.reload();
  let requests = 0;
  let slowPageMode = false;
  let downloadMode = false;
  let redirectMode = false;
  let redirectCount = 0;
  let redirectForever = false;
  let summaryRequests = 0;
  let failSummary = false;
  let pendingRequest;
  let loopMode = false;
  let searchMode = false;
  await panel.route('https://pilot-test.openai.azure.com/**', async route => {
    requests++;
    const body = route.request().postDataJSON();
    const data = JSON.parse(body.messages[2].content.split('\n').slice(1).join('\n'));
    assert.ok(!JSON.stringify(data).includes('PRIVATE_INITIAL_VALUE'));
    if (body.messages[0].content.includes('You write the final results')) {
      summaryRequests++;
      assert.match(data.snapshot.text, /summarize documents/);
      if (failSummary) await route.fulfill({ status: 429, json: { error: 'Rate limited' } });
      else await route.fulfill({ json: { choices: [{ message: { content: JSON.stringify({ summary: 'Azure OpenAI provides Azure APIs for text generation and document summaries.\n• Based on the observed overview page.' }) } }] } });
      return;
    }
    if (pendingRequest) await pendingRequest;
    if (redirectMode) {
      if (!redirectCount || redirectForever) {
        redirectCount++;
        await page.goto(`${origin}/?redirect=${redirectCount}`);
        await route.fulfill({ json: { choices: [{ message: { content: JSON.stringify({ type: 'fill', element: data.snapshot.elements.find(e => e.label === 'Name').id, value: 'STALE_ACTION' }) } }] } });
      } else {
        assert.equal(data.history.length, 0);
        await route.fulfill({ json: { choices: [{ message: { content: '{"type":"done","message":"Fresh destination inspected."}' } }] } });
      }
      return;
    }
    let action;
    const history = data.history;
    if (downloadMode) {
      if (!history.length) {
        const link = data.snapshot.elements.find(e => e.context?.includes('sample-image-100kb.jpg'));
        assert.ok(link);
        action = { type: 'download', element: link.id };
      } else {
        assert.equal(history[0].result.state, 'complete');
        assert.equal(history[0].result.bytesReceived, 100 * 1024);
        action = { type: 'done', message: 'Requested sample download completed.' };
      }
    } else if (slowPageMode) {
      action = history.length ? { type: 'done', message: 'Interactive page inspected despite pending resources.' } : { type: 'navigate', url: `${origin}/slow-news` };
    } else if (searchMode) {
      const snapshot = data.snapshot;
      if (snapshot.url.endsWith('/article')) {
        assert.match(snapshot.text, /summarize documents/);
        action = { type: 'done', message: 'Azure OpenAI offers language models via Azure APIs for text generation and document summarization.' };
      } else if (snapshot.url.endsWith('/search')) action = { type: 'click', element: snapshot.elements.find(e => e.label === 'Azure OpenAI overview').id };
      else if (!history.length) action = { type: 'fill', element: snapshot.elements.find(e => e.label === 'Search query').id, value: 'azure open ai' };
      else {
        assert.equal(history.at(-1).result, 'Field filled.');
        action = { type: 'submit', element: snapshot.elements.find(e => e.label === 'Search query').id };
      }
    }
    else if (loopMode) action = { type: 'scroll', direction: 'down' };
    else if (data.snapshot.url.includes('/done')) action = { type: 'done', message: 'Form submitted successfully.' };
    else if (!history.length) action = { type: 'fill', element: data.snapshot.elements.find(e => e.label === 'Name').id, value: 'Grace' };
    else action = { type: 'submit', element: data.snapshot.elements.find(e => e.label === 'Send').id };
    await route.fulfill({ json: { choices: [{ message: { content: JSON.stringify(action) } }] } });
  });
  // A side panel is not a tab. Select the fixture tab through the extension API.
  async function activateFixture() {
    await panel.evaluate(async origin => {
      const tabs = await chrome.tabs.query({});
      const tab = tabs.find(t => t.url?.startsWith(origin));
      await chrome.tabs.update(tab.id, { active: true });
    }, origin);
  }
  async function approveGate(matching) {
    await panel.locator('#gate').waitFor({ state: 'visible' });
    assert.match(await panel.locator('#gate-message').innerText(), matching);
    const requestId = await panel.locator('#gate').getAttribute('data-request-id');
    await panel.locator('#approve').click();
    await panel.waitForFunction(id => document.getElementById('gate').hidden || document.getElementById('gate').dataset.requestId !== id, requestId);
  }
  await test('extension loads configuration and executes all actions after one consent', async () => {
    await page.goto(origin);
    await panel.locator('#task').fill('Fill the name Grace and submit the form.');
    await activateFixture();
    await panel.locator('#start').click();
    await approveGate(/Allow automatic browser actions/);
    await panel.getByText('Form submitted successfully.', { exact: true }).waitFor();
    assert.equal(new URL(page.url()).searchParams.get('name'), 'Grace');
    assert.equal(requests, 3);
    assert.deepEqual(browserErrors, []);
  });
  await test('rejecting initial consent sends no model request', async () => {
    const before = requests;
    await activateFixture();
    await panel.locator('#start').click();
    await panel.locator('#gate').waitFor({ state: 'visible' });
    await panel.locator('#reject').click();
    await panel.locator('#start:not([disabled])').waitFor();
    assert.equal(requests, before);
  });
  await test('stop aborts an in-flight model request without filling the page', async () => {
    await page.goto(origin);
    await activateFixture();
    let release;
    pendingRequest = new Promise(resolve => { release = resolve; });
    await panel.locator('#start').click();
    await approveGate(/Allow automatic browser actions/);
    await panel.getByText('Asking your model for the next action…', { exact: true }).waitFor();
    await panel.locator('#stop').click();
    release();
    pendingRequest = undefined;
    await panel.locator('#start:not([disabled])').waitFor();
    assert.equal(await page.locator('#name').inputValue(), 'PRIVATE_INITIAL_VALUE');
    assert.equal(await panel.locator('#gate').isVisible(), false);
  });
  await test('automation loop stops at exactly thirty actions', async () => {
    const before = requests;
    loopMode = true;
    await page.goto(origin);
    await activateFixture();
    await panel.locator('#start').click();
    await approveGate(/Allow automatic browser actions/);
    await panel.getByText('30-action limit reached. Review the page before starting another run.', { exact: true }).waitFor({ timeout: 60000 });
    assert.equal(requests - before, 30);
    assert.equal(await panel.locator('#log li').count(), 31);
    loopMode = false;
  });
  await test('search submits ordinary hidden fields, opens the actual result href and summarizes destination', async () => {
    searchMode = true;
    const before = requests;
    await page.goto(`${origin}/search-home`);
    await panel.locator('#task').fill('Search for azure open ai, click the first result, summarize.');
    await activateFixture();
    await panel.locator('#start').click();
    await approveGate(/Allow automatic browser actions/);
    await panel.getByText('Azure OpenAI provides Azure APIs for text generation and document summaries.\n• Based on the observed overview page.', { exact: true }).waitFor();
    assert.equal(page.url(), `${origin}/article?ref=first`);
    assert.equal(requests - before, 5);
    assert.equal(summaryRequests, 1);
    assert.equal(await panel.locator('#results-panel').isVisible(), true);
    assert.equal(await panel.locator('#status').innerText(), 'Completed');
    searchMode = false;
  });
  await test('search forms still reject secret hidden fields with a serialized error', async () => {
    await page.goto(`${origin}/search-home`);
    await page.locator('form').evaluate(form => form.insertAdjacentHTML('beforeend', '<input type="hidden" name="access_token" value="private">'));
    data = await tool({ type: 'snapshot' });
    const result = await page.evaluate(browserTool, { type: 'act', nonce: data.nonce, action: { type: 'submit', element: element('Search query') } });
    assert.match(result.error, /sensitive fields/);
    await page.locator('input[name="access_token"]').evaluate(el => { el.name = 'csrf'; });
    data = await tool({ type: 'snapshot' });
    await act({ type: 'submit', element: element('Search query') });
    await page.waitForURL(`${origin}/search?**`);
  });
  await test('navigation without an injected result continues without resubmission', async () => {
    await panel.locator('#task').fill('Fill the name Grace and submit the form.');
    await panel.evaluate(() => {
      const executeScript = chrome.scripting.executeScript.bind(chrome.scripting);
      chrome.scripting.executeScript = async options => {
        const results = await executeScript(options);
        if (options.args?.[0]?.action?.type === 'submit') return results.map(result => ({ ...result, result: undefined }));
        return results;
      };
    });
    await page.goto(origin);
    await activateFixture();
    const before = requests;
    await panel.locator('#start').click();
    await approveGate(/Allow automatic browser actions/);
    await panel.getByText('Form submitted successfully.', { exact: true }).waitFor();
    assert.equal(requests - before, 3);
    assert.equal(await panel.locator('#log li').count(), 4);
  });
  await test('failed summary retains the automation report and shows a clear warning', async () => {
    failSummary = true;
    searchMode = true;
    await page.goto(`${origin}/article?ref=first`);
    await panel.locator('#task').fill('Summarize the results');
    await activateFixture();
    await panel.locator('#start').click();
    await approveGate(/Allow automatic browser actions/);
    await panel.locator('#start:not([disabled])').waitFor();
    assert.equal(await panel.locator('#status').innerText(), 'Summary unavailable');
    assert.match(await panel.locator('#results-note').innerText(), /HTTP 429/);
    assert.match(await panel.locator('#summary').innerText(), /Azure OpenAI offers language models/);
    failSummary = false;
    searchMode = false;
  });
  await test('redirect during model request discards stale action and replans on the fresh page', async () => {
    redirectMode = true;
    redirectCount = 0;
    await page.goto(origin);
    await panel.locator('#task').fill('Inspect the current destination.');
    await activateFixture();
    await panel.locator('#start').click();
    await approveGate(/Allow automatic browser actions/);
    await panel.getByText('Fresh destination inspected.', { exact: true }).waitFor();
    assert.equal(await page.locator('#name').inputValue(), 'PRIVATE_INITIAL_VALUE');
    assert.match(await panel.locator('#log').textContent(), /discarded stale model decision/);
    assert.equal(await panel.locator('#status').innerText(), 'Completed');
    redirectMode = false;
  });
  await test('repeated redirects stop after bounded refreshes without executing stale actions', async () => {
    redirectMode = true;
    redirectForever = true;
    redirectCount = 0;
    await page.goto(origin);
    await activateFixture();
    await panel.locator('#start').click();
    await approveGate(/Allow automatic browser actions/);
    await panel.locator('#start:not([disabled])').waitFor();
    assert.equal(redirectCount, 4);
    assert.match(await panel.locator('#result').innerText(), /Stopped after 3 refreshes/);
    assert.equal(await page.locator('#name').inputValue(), 'PRIVATE_INITIAL_VALUE');
    assert.equal(await panel.locator('#status').innerText(), 'Failed');
    redirectMode = false;
    redirectForever = false;
  });
  await test('interactive article with a stalled image completes without waiting for full load', async () => {
    slowPageMode = true;
    let releaseImage;
    const imagePending = new Promise(resolve => { releaseImage = resolve; });
    await page.route(`${origin}/slow-news`, route => route.fulfill({ contentType: 'text/html', body: '<!doctype html><title>News</title><h1>Readable article</h1><p>Article text is ready.</p><img src="/stalled-image">' }));
    await page.route(`${origin}/stalled-image`, async route => { await imagePending; await route.abort(); });
    try {
      await page.goto(origin);
      await activateFixture();
      await panel.locator('#start').click();
      await approveGate(/Allow automatic browser actions/);
      await panel.getByText('Interactive page inspected despite pending resources.', { exact: true }).waitFor({ timeout: 10000 });
      assert.equal(await page.evaluate(() => document.readyState), 'interactive');
      const tabStatus = await panel.evaluate(async origin => (await chrome.tabs.query({})).find(tab => tab.url === `${origin}/slow-news`)?.status, origin);
      assert.equal(tabStatus, 'loading');
      assert.equal(await panel.locator('#status').innerText(), 'Completed');
    } finally {
      releaseImage();
      slowPageMode = false;
      await page.unrouteAll({ behavior: 'wait' });
    }
  });
  await test('real browser download is tracked to completion and reported to the model', async () => {
    downloadMode = true;
    await page.goto(`${origin}/downloads`);
    await panel.locator('#task').fill('Download sample-image-100kb.jpg');
    await activateFixture();
    await panel.locator('#start').click();
    await approveGate(/Allow automatic browser actions/);
    await panel.getByText('Requested sample download completed.', { exact: true }).waitFor();
    assert.match(await panel.locator('#log').textContent(), /Download complete/);
    assert.equal(await panel.locator('#status').innerText(), 'Completed');
    const files = await panel.evaluate(() => chrome.downloads.search({}));
    assert.equal(files.length, 1);
    assert.equal(files[0].state, 'complete');
    downloadMode = false;
  });
  console.log(`\n${passed} browser tests passed.`);
} finally {
  await context?.close();
  await new Promise(resolve => server.close(resolve));
  await rm(temporary, { recursive: true, force: true });
}
