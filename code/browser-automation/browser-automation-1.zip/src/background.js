async function initialize() {
  await chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
}
chrome.runtime.onInstalled.addListener(() => { initialize().catch(console.error); });
chrome.runtime.onStartup.addListener(() => { initialize().catch(console.error); });
initialize().catch(console.error);

let owner;
chrome.runtime.onConnect.addListener(port => {
  if (port.name !== 'automation-run') return;
  if (owner) {
    port.postMessage({ acquired: false });
    return;
  }
  owner = port;
  port.postMessage({ acquired: true });
  port.onDisconnect.addListener(() => { if (owner === port) owner = undefined; });
});
