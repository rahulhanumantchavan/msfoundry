import { webUrl } from './core.js';

export async function downloadFile(url, signal, api = chrome.downloads, timeoutMs = 30_000) {
  webUrl(url);
  signal.throwIfAborted();
  const id = await api.download({ url, conflictAction: 'uniquify', saveAs: false });
  const cancel = async () => { try { await api.cancel(id); } catch { /* Already completed or removed. */ } };
  if (signal.aborted) { await cancel(); signal.throwIfAborted(); }
  return new Promise((resolve, reject) => {
    let finished = false;
    let checking = false;
    const cleanup = () => {
      clearInterval(poll);
      clearTimeout(timer);
      signal.removeEventListener('abort', abort);
    };
    const finish = (error, result) => {
      if (finished) return;
      finished = true;
      cleanup();
      if (error) reject(error); else resolve(result);
    };
    const abort = () => {
      if (finished) return;
      void cancel();
      finish(new Error('Download stopped; cancellation requested. Completed files are not deleted.'));
    };
    const check = async () => {
      if (finished || checking) return;
      checking = true;
      try {
        // Query only this run's download ID, never unrelated browser downloads.
        const [item] = await api.search({ id });
        if (finished) return;
        if (!item) { finish(new Error('Tracked download is no longer available.')); return; }
        if (item.state === 'complete') finish(null, { state: 'complete', bytesReceived: item.bytesReceived });
        else if (item.state === 'interrupted') finish(new Error(`Download interrupted (${item.error || 'unknown reason'}). Check the browser Downloads page.`));
      } catch {
        void cancel();
        finish(new Error('Could not inspect the tracked download. Cancellation requested.'));
      } finally { checking = false; }
    };
    const poll = setInterval(check, 250);
    const timer = setTimeout(() => {
      if (finished) return;
      void cancel();
      finish(new Error('Download did not complete within the tracking timeout. Cancellation requested; check browser Downloads.'));
    }, timeoutMs);
    signal.addEventListener('abort', abort, { once: true });
    if (signal.aborted) abort(); else void check();
  });
}
