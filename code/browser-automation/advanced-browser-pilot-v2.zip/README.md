# Advanced Browser Pilot

A standalone Manifest V3 Chrome extension: **DOM-first automation with opt-in vision fallback**, using your own Azure OpenAI vision-capable Chat Completions deployment. No backend, provisioning, production dependencies or build step. This project is independent of the parent Browser Pilot extension; neither its settings nor its browser secrets are read.

## Install and run

1. Open `chrome://extensions`, enable **Developer mode**, choose **Load unpacked**, and select this `advanced-browser-pilot` directory (not its parent).
2. Pin **Advanced Browser Pilot**, select a normal HTTP(S) website or a new/blank tab, and click its toolbar icon to open the side panel. From `chrome://newtab/`, `edge://newtab/` or `about:blank`, include the website to open in your task.
3. Enter your Azure **resource endpoint**, **deployment name**, and **API key**. Use a vision-capable chat deployment supporting JSON mode, e.g. GPT-4o. Save configuration. This makes no model request.
4. Describe the task using non-confidential data. Click **Run in current tab**, read the run consent, and approve automatic actions plus DOM/screenshot sharing. Chrome may separately show its site-permission/debugger notices.
5. Keep the task tab active and the side panel open. Watch readable progress, Results and Token Usage. **Stop** aborts pending requests and releases debugger ownership; already-dispatched actions cannot be undone.

Minimum Chrome 120; tested with installed Playwright Chromium in headless extension mode on Windows. Edge compatibility and the actual side-panel presentation require manual checking. Close DevTools or another debugger yourself before starting; the extension never takes over an existing debugger session.

### Independent configuration

Accepted endpoints: `https://RESOURCE.openai.azure.com` or `https://RESOURCE.services.ai.azure.com`, optionally ending in `/openai/v1/`. Custom domains, sovereign-cloud suffixes, proxies and arbitrary API URLs are not accepted. Configure the Azure **deployment name**, not merely a model family. Calls go to `${endpoint}/openai/v1/chat/completions`; v1 does not require an `api-version` query parameter.

The API key is stored only in this extension's `chrome.storage.local.advancedConfig`, restricted to `TRUSTED_CONTEXTS`. It is not synced, injected into websites or included in model evidence. Local extension storage is **not a secret vault**. **Forget key** removes this extension's configuration; revoke persistent site permissions separately in Chrome settings. Settings must be entered again to change them. Authentication uses the configured API key; Entra login and token acquisition are not implemented.

## Architecture and files

### Architecture diagram

```mermaid
flowchart LR
    User[User: task and upfront consent]
    subgraph Extension[Advanced Browser Pilot - trusted extension contexts]
        Panel[Side panel\nConfiguration, progress, results, tokens]
        Storage[(Local configuration\nEndpoint, deployment, API key)]
        Runner[runner.js\nDOM-first loop and recovery budgets]
        Core[core.js\nAction validation, Azure transport, usage]
        Driver[driver.js\nObservation, freshness, coordinate mapping]
        Background[background.js\nExclusive debugger ownership\nand allowlisted CDP commands]
        Downloads[downloads.js\nTrack only requested download ID]
        Panel <--> Storage
        Panel --> Runner
        Runner <--> Core
        Runner <--> Driver
        Driver <-->|Runtime port and CDP RPC| Background
        Driver --> Downloads
    end
    subgraph TaskTab[Selected website tab - untrusted content]
        DOM[Website DOM\nAccessible open shadows and same-origin frames]
        Tool[dom.js\nIsolated-world inspection and target checks]
        View[Visible viewport\nScreenshot and input surface]
        Tool <--> DOM
    end
    Azure[Azure OpenAI\nVision-capable Chat Completions v1]
    Manager[Browser download manager\nSave files, never open or execute]
    User --> Panel
    Driver <-->|chrome.scripting| Tool
    Background <-->|Tab-scoped Chrome Debugger API| View
    Core -->|HTTPS: task, bounded DOM evidence\nand optional JPEG| Azure
    Azure -->|Validated JSON action or text summary| Core
    Downloads <--> Manager
```

**Ownership and data boundaries:** the side panel starts the runner; the service worker owns debugger attachment and cleanup, not model planning. The driver translates allowlisted actions into DOM operations or tab-scoped CDP input. The model never receives arbitrary JavaScript execution or unrestricted CDP access.

The API key stays in trusted extension contexts and is sent only to the configured Azure endpoint. Website text and screenshot content are untrusted evidence. Screenshots are captured only under run consent, kept in memory for a decision, and excluded from history and final summary calls. Configuration persists locally; run evidence, reports and token counters do not persist across panel closure. Browser-managed files and download history persist separately.

### Technical execution flow

```mermaid
flowchart TD
    Start[Task and configuration entered] --> Consent{Upfront consent granted?}
    Consent -->|No| End[No automation starts]
    Consent -->|Yes| Acquire[Validate configuration\nReserve active task tab]
    Acquire --> Startup{New or blank tab?}
    Startup -->|Yes| NoPage[Fixed no-page context\nAllow HTTP/S navigation or done only]
    NoPage --> Navigate[Navigate to requested website]
    Startup -->|No: supported website| Attach[Attach debugger without taking over another session]
    Navigate --> Attach
    Attach --> Ready[Wait for interactive page and stable state]
    Ready --> Observe[Capture fresh bounded DOM snapshot]
    Observe --> Mode{Vision requested or covered-target fallback?}
    Mode -->|No| Decide[Azure proposes one JSON action]
    Mode -->|Yes| Capture[Capture bounded JPEG viewport\nRecord image dimensions and page state]
    Capture --> Decide
    Decide --> Validate[Validate action schema and arguments\nRecheck tab, document and target freshness]
    Validate --> Kind{Action type?}
    Kind -->|Done| Summary{Summary requested?}
    Summary -->|Yes| Summarize[Separate text-only Azure summary\nRecheck freshness before reporting]
    Summary -->|No| Results[Display automation report]
    Summarize --> Results
    Kind -->|Vision| Escalate[Consume action budget\nRequest image on next observation]
    Escalate --> Observe
    Kind -->|Browser action or wait| Budget[Check action and time budgets]
    Budget --> Execute[Execute DOM or CDP action\nor track requested download]
    Execute --> History[Record outcome and token usage\nCount non-wait actions]
    History --> Ready
    Validate -->|Stale decision| Stale[Discard decision\nUp to 3 consecutive stale recoveries]
    Execute -->|Target needs scrolling| Prepare[Scroll and refresh references\nBounded preparation retries]
    Execute -->|Recognized autocomplete blocks click| Auto[Bounded Escape dismissal\nRe-observe before deciding again]
    Execute -->|Covered DOM target| Vision[Up to 2 independent vision fallbacks\nNo blind replay of input]
    Stale --> Ready
    Prepare --> Ready
    Auto --> Ready
    Vision --> Ready
    Budget -->|Limit reached| Failed[Show failure or limit reason]
    Validate -->|Invalid or forbidden action| Failed
    Execute -->|Unsafe or unrecoverable error| Failed
    Results --> Cleanup[Release debugger and run ownership\nClear in-memory image evidence]
    Failed --> Cleanup
    Cancel[Stop, timeout, disconnect or tab closure] --> Cleanup
```

### Flow details

1. **Consent and startup:** a new/blank tab receives no page inspection or screenshot. Website navigation occurs before debugger attachment. Other protected browser pages remain blocked.
2. **Observe and decide:** DOM evidence is the default. A model `vision` request or covered-target recovery enables a fresh screenshot for the next decision. Coordinates are interpreted in resized screenshot pixels, then mapped to viewport CSS pixels.
3. **Validate before input:** semantic DOM targets are checked for identity and relevant changes rather than rejected for every unrelated mutation. Screenshot coordinates retain stricter layout/viewport freshness checks. A stale decision is discarded, not replayed.
4. **Execute and verify:** the driver performs the allowed action and records its outcome; the next observation supplies evidence of success. Wait and `waitFor` actions consume time but not the 30-action budget. Explicit vision requests and automatic covered-target escalation consume actions. No completion claim should rely solely on a dispatched click.
5. **Recover with bounds:** successful non-wait actions reset consecutive stale and preparation counters. Covered-target vision fallback has its own two-attempt run budget. Recognized autocomplete dismissal is limited to once per edited field state and twice per run, followed by a fresh decision. Genuine dialogs and unrelated overlays are not blindly bypassed.
6. **Report and clean up:** summaries use text evidence, not retained screenshots. A failed summary request keeps the automation report with a warning; stale summary evidence triggers recovery instead. Stop and deadlines terminate further actions and release ownership. Already-dispatched input and completed downloads cannot be undone.

Mermaid-capable Markdown viewers render these diagrams; other viewers display their source. The diagrams describe the implemented flow, not a guarantee that every website or visual control is supported.

### Source files

| File | Responsibility |
|---|---|
| `manifest.json` | Independent identity, side panel, trusted extension CSP and Chrome permissions. |
| `src/panel.html`, `panel.css`, `panel.js` | Configuration, single upfront run consent, Stop, readable progress, summaries and usage. |
| `src/runner.js` | DOM-first model loop, screenshot escalation, budgets, evidence-based results and bounded stale-decision recovery. |
| `src/core.js` | Endpoint/action validation, closed JSON action vocabulary, Azure transport and token accounting. |
| `src/dom.js` | Fixed isolated-world page tool: redacted snapshots, open shadows/same-origin frames, sensitive checks, references, hit testing and DOM operations. |
| `src/driver.js` | One-tab execution, active/URL/viewport checks, in-memory screenshots, coordinate mapping, trusted CDP mouse/keyboard input, waits and cleanup. |
| `src/background.js` | Exclusive run/debugger ownership, allowlisted CDP RPC, disconnect/tab/deadline cleanup. No browser-global model targeting. |
| `src/downloads.js` | Track only an explicitly requested download ID; completion/interruption/cancellation, no open/execute API. |
| `tests/` | Node unit tests and real unpacked-extension tests using the installed Playwright Chromium binary. |

Flow: **consent → reserve task tab → (navigate if new/blank) → attach website tab → DOM snapshot → Azure decision → validate and recheck → execute → observe**. New/blank startup provides only a fixed `noPage` description and empty elements: the model may navigate to HTTP(S) or finish with an explanation. No debugger, DOM injection or screenshot occurs until a website opens. Other internal pages (settings/history), files and extension pages remain blocked. A run that leaves an attached website for an internal page stops rather than inspecting it. The model can request `vision`; the next decision includes a JPEG viewport image and the latest DOM snapshot. Images are not retained in history or final-summary calls. The model does not execute code: no model selectors, `eval`, `Runtime.evaluate`, arbitrary CDP methods, browser-level target IDs, shell commands or external tool plugins are accepted.

## Implemented actions

- Navigation, history back/forward, same-task-tab link navigation.
- DOM-reference click, replacement typing (trusted `Input.insertText`), select, ordinary form submit.
- Trusted hover, pointer drag, restricted keyboard input, page and nested-element scroll.
- Fixed-duration waits and bounded visible/hidden text-state waits, including SPA updates.
- Vision-request escalation; image-coordinate click, hover, replacement typing, drag and scrolling.
- Direct HTTP(S) link downloads, with completion status/byte count and cancellation on Stop/timeout. Download bytes are never sent to Azure. The extension **never opens or executes downloads**. Chrome/user settings or external software can still decide how files are handled.
- Model-generated final results; a separate text-only summary request when the task asks for a summary/results, with fallback to the automation report if summary generation fails.
- Token totals across all decisions, image requests and summaries. API `prompt_tokens`, `completion_tokens`, `total_tokens` are accumulated exactly. Image tokens are already part of provider prompt usage; they are not estimated or added again. Missing/malformed/error/aborted-request usage is marked **incomplete**, not silently counted as zero known usage.

### Coordinate protocol

A screenshot is the **visible task-page viewport only**, not the entire document or browser chrome. Capture uses tab-scoped `Page.captureScreenshot`, JPEG quality 55, longest side at most 1024 pixels, and a 1.5 MB base64 bound. Actual JPEG dimensions are decoded locally. Azure receives `image_url: {url: "data:image/jpeg;base64,...", detail: "low"}`.

All model coordinates are **pixels in the resized JPEG**: origin `(0,0)` at top-left, x rightward and y downward. They are not page coordinates, CSS pixels, percentages or device pixels. The extension maps `cssX = imageX * cssViewportWidth / imageWidth` (and similarly for y), independently of device-pixel ratio. Pinch zoom is rejected. The image is valid for one decision only.

Exact additional action shapes (no extra fields accepted):

```json
{"type":"vision","reason":"Canvas target unavailable in DOM"}
{"type":"pointClick","x":120,"y":90}
{"type":"pointHover","x":120,"y":90}
{"type":"pointType","x":120,"y":90,"value":"ordinary text"}
{"type":"pointDrag","x":120,"y":90,"toX":220,"toY":140}
{"type":"pointScroll","x":120,"y":90,"direction":"down"}
{"type":"hover","element":"e1"}
{"type":"drag","element":"e1","target":"e2"}
{"type":"key","element":"e1","key":"Enter"}
{"type":"scrollElement","element":"e1","direction":"down"}
{"type":"waitFor","text":"Saved","state":"visible","milliseconds":3000}
```

Supported keys: Enter, Tab, Escape, arrow keys, Space, Backspace, Delete, Home, End. No arbitrary shortcuts. Point typing must hit an inspected ordinary editable DOM field; blind canvas/terminal text entry is not supported. `pointScroll` top/bottom means a bounded large wheel delta, not guaranteed absolute position; observe again. Pointer drag supports mouse/pointer-driven controls; complex HTML5 DataTransfer drag/drop, native drag payloads and multi-touch gestures are not guaranteed.

## Safety, freshness and limits

- **One upfront consent per run**, including automatic changes/submissions and screenshots to the configured Azure endpoint. Screenshots can include *any visible page information*, including images/canvas and field values. There is no dependable screenshot redaction: use only non-confidential pages. DOM redaction and sensitive detection are best-effort safeguards, not a guarantee that arbitrary websites contain no private data.
- Visible password/secret/payment/identity fields, known sensitive paths and detected CAPTCHA controls block inspection/automation. Sensitive form fields and cross-origin/form-new-target submissions are blocked, while ordinary names/email fields and hidden anti-forgery fields are supported. File uploads are not supported. Closed shadow internals cannot be inspected or guaranteed safe; do not use this on sites placing sensitive content there.
- Every action validates its document nonce and full URL (kept local). Semantic DOM actions validate only their referenced target(s): connectivity, current fingerprint, visibility, relevant geometry and hit testing; unrelated ticker/ad mutations no longer invalidate stable controls. Screenshot capture, coordinate actions, done reports and summaries retain strict global mutation, scroll, viewport and element-layout freshness. Hit testing prevents clicks through modal overlays. News-card duplicate links are recognized only when the visible hit-tested covering anchor has the exact full resolved href, shares the headline's non-body parent (directly or one wrapper below), belongs to the same document, has an ordinary target and neither anchor is a download or inside a dialog. Open modal dialogs disable this equivalence. The extension returns the verified destination for normal same-task-tab navigation, never a hidden DOM click. Different destinations, unrelated overlays and real dialogs are not treated as equivalent. Scroll/layout changes that move a referenced DOM target require a fresh decision; all nested scroll events invalidate image decisions. An offscreen target is scrolled into view, then re-observed without charging the stale-page budget (at most two such preparations without a successful action). No old coordinates are used after this preparation. Before coordinate input, a second bounded capture must be **byte-identical** to the decision image. Animation/video/caret blinking can therefore cause conservative rejection.
- Active task tab and HTTP(S) permission are checked on each command, including within drag/keyboard sequences. Links recognized by DOM are opened in the same task tab. Arbitrary site JavaScript can still open a popup/new tab; the extension never follows it, and deactivation stops the run. There is an unavoidable small race between independent page checks and browser input; browser automation cannot make those operations atomic against hostile/changing pages.
- **30 non-wait actions**, **5-minute wall-clock limit**, **30-second model requests**, **15-second page readiness**, **10-second UI-state waits**, **3 consecutive stale-page re-observations plus 2 independent per-run covered-target vision fallbacks**. A successful non-wait browser action resets the consecutive stale and preparation budgets; waits, vision requests and failed actions do not. The overall action/time limits still bound repeated progress cycles. Vision requests consume action budget; waits do not. A final done/summary decision can follow action 30. Stale decisions are discarded, never replayed blindly. Covered-target failures are a separate typed result emitted before input: they request a fresh DOM+image decision even if all three consecutive stale-page refreshes were used. Each automatic visual fallback consumes one action and one of two per-run fallback slots; image requests use the normal usage tracker. A third covered-target failure stops. During visual recovery, coordinate input is restricted to a click on an exposed part of the original target (identity/fingerprint checked) or its safe equivalent card anchor. It cannot click unrelated overlays or drag/type through them. The model can instead choose an appropriate current DOM dialog-dismiss control or report the obstruction; no blocked action is replayed automatically. Errors after state-changing input are terminal rather than retried. Dynamic pages may stop conservatively.
- Worker ownership is acquired only after consent and attaches only `{tabId}`. An existing attached debugger is refused. New/blank tabs reserve the same exclusive run lock without debugger attachment; attachment is deferred until HTTP(S) navigation commits. Stop, panel port disconnection/pagehide, tab activation change/removal, external debugger detach, errors and worker deadline release ownership. A Chrome alarm backs up the panel timeout. Open mutation observers are cleaned up best-effort; page navigation destroys their isolated world.
- Screenshots remain in extension memory and request bodies only, never in extension storage, logs, files or downloads. JavaScript garbage collection/OS paging and Azure retention policies are outside extension control. Requests have redirect rejection to prevent forwarding credentials. Provider error bodies are not echoed.

### Accessibility and scope boundaries

Open shadow roots and nested same-origin frames are inspected and hit-tested, up to eight nesting levels. Visible inaccessible/cross-origin/sandboxed or transformed frames are explicitly marked; screenshots/coordinate actions are blocked when present to avoid unknowingly sharing their content. DOM operations outside those frames can still work. Closed shadow roots, rotated/transformed frame coordinate systems, PDF viewers, Chrome/internal pages, browser toolbars, extensions pages, desktop apps, native menus/dialogs, file pickers, passkeys and CAPTCHA solving are not automated. Complex contenteditable editors/virtualized widgets may require manual intervention. The text snapshot is bounded (160 controls, 7,000 characters, 12,000 DOM-node safety bound), so reports are not exhaustive page reads.

### Autocomplete obstruction recovery

When a semantic DOM **click** is blocked by an accessible suggestion list, the extension may send **Escape once for the current field edit**, with a maximum of **two automatic dismissals per run**. This requires all of: the field was filled by this run and still owns focus; it declares an expanded combobox/autocomplete relationship; `aria-controls` or `aria-owns` resolves to the visible `role="listbox"` actually covering the target; the intended target is outside that list; and no visible dialog/modal is present. Detection is checked again immediately before Escape. It does not send Enter, disable autocomplete or click through the popup.

Escape consumes one non-wait action. The blocked click has not happened: the runner takes a fresh snapshot and asks for a fresh model decision, without consuming stale/vision recovery slots. Replacement or identity changes to the intended target during dismissal stop the run. If Escape does not close the popup, another automatic Escape is not attempted for that edit; existing bounded covered-target/vision handling applies. Suggestion options are included in snapshots and remain normally selectable without dismissal. Unrelated listboxes, blurred fields and genuine dialogs do not qualify.

This is **fixture-tested in real unpacked Chromium**, not a reproduction on the user's unspecified website. Browser-native autofill/autocomplete/password-manager popups may have no inspectable DOM and are not automatically dismissed. Canvas-coordinate typing, custom suggestions without explicit accessible relationships, and ambiguous popup ownership remain unsupported for this recovery. No blanket Escape is sent before clicks. Page-defined Escape handlers can have their own side effects, and focus changes between browser checks and key dispatch cannot be made atomic.

## Tests

From this directory:

```powershell
npm run check
npm test
```

The parent's existing Playwright package is resolved by Node, so no install is necessary in this workspace. For a standalone checkout, run `npm install` and `npx playwright install chromium` if Playwright/Chromium are missing. The extension itself needs no npm packages.

The browser suite launches **real unpacked Chromium**, attaches the harness only to the extension panel, and lets the real `chrome.debugger` implementation own the task tab. A normal Playwright page auto-attachment would correctly trigger the no-takeover guard, so the suite uses the Playwright-provided browser binary with a panel-only CDP test harness. Test-only fixed fixture scripts are injected through `chrome.scripting`; no task-page model-code evaluation is used. Azure is replaced by an in-memory fetch fixture; no user credentials or content are sent remotely. Profiles/downloads are created under `.test-artifacts` inside this project and removed on completion; screenshots are never saved.

Coverage: endpoint/action validation; vision request shape and coordinate mapping; usage totals/missing usage; real trusted input; shadow and frame fields; keyboard/select/submit; SPA changes/modal layering; hover/drag/nested scrolling/UI waits; canvas screenshots and stale pixels; download completion/no open; sensitive/opaque pages; cancellation, pagehide, tab deactivation, error and deadline detachment; existing-debugger refusal; bounded recovery; unrelated DOM churn versus replaced actual targets; self-scroll reference refresh without stale-budget consumption; successful-progress recovery resets; duplicate destination cards and modal/mismatched-link rejection; covered-target vision after three stale refreshes; extra image token totals; blocked unrelated-overlay coordinates and bounded repeated coverage failures; 30-action cap; new-tab navigation-only startup, deferred attachment, and continued rejection of other browser-internal pages. Full five-minute real-time expiry is not waited out: timeout constants are unit-checked and the worker alarm path is exercised with a shortened test-only alarm.

### Remaining manual checks

Use a real **non-confidential** Azure vision deployment to verify account/model availability, JSON-mode plus image support, Azure network policies, API usage reporting and summaries. Test actual Chrome side-panel UX, permission prompts, Stop during a real long request, website-specific pointer drag/keyboard semantics, browser zoom/device scaling and chosen real-world workflows. These tests do not certify prompt-injection resistance or reliable sensitive-data discovery; model reports always require user verification.

### Public Google News spot-check (2026-11-06)

A fresh disposable Chromium profile loaded `https://news.google.com/?hl=en-IN&gl=IN&ceid=IN:en` and selected India. Inspection confirmed covered `gPFEn` headlines with same-href covering links one wrapper below the same card parent. The exact covered headline reference returned a safe same-tab navigation URL with the updated fixed DOM tool. That destination was **not followed** and Azure was **not called**: this is a public DOM compatibility spot-check, not an end-to-end news-reading/summarization claim. Live page changes, regional dialogs and model behavior can still prevent a complete run. The profile was removed and no screenshots were saved.

## Protocol references

- [Azure OpenAI vision-enabled chat models](https://learn.microsoft.com/en-us/azure/foundry/openai/how-to/gpt-with-vision): multimodal content, base64 image URLs, detail settings and token usage.
- [Azure OpenAI API version lifecycle / v1](https://learn.microsoft.com/en-us/azure/foundry/openai/api-version-lifecycle): v1 `/openai/v1/` endpoints.
- [Chrome debugger API](https://developer.chrome.com/docs/extensions/reference/api/debugger): tab attachment, commands and detach lifecycle.
- [CDP Page.captureScreenshot](https://chromedevtools.github.io/devtools-protocol/tot/Page/#method-captureScreenshot) and [CDP Input](https://chromedevtools.github.io/devtools-protocol/tot/Input/): viewport capture and mouse/keyboard events.
