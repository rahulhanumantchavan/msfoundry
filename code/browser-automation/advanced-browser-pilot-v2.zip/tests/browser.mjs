import { chromium } from 'playwright';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { cp, mkdir, readFile, writeFile, rm } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const work = path.join(root, '.test-artifacts');
await mkdir(work, { recursive: true });
const fixture = `<!doctype html><title>Advanced fixture</title><style>body{margin:20px;font:16px sans-serif}button,input{margin:5px}#nested{height:80px;width:250px;overflow:auto;border:1px solid}#drag,#drop{display:inline-block;width:90px;height:60px;background:#ace;margin:20px}#hover:hover{background:red}#canvas{display:block;background:#ddd}dialog{padding:40px}</style>
<h1>Public fixture</h1><form action='/done'><label>Name<input id='name' name='name' value='PRIVATE_INITIAL_VALUE'></label><button id='send'>Send</button></form>
<button id='mutable'>Original</button><button id='hover'>Hover me</button><span id='hovered'></span>
<div id='shadow'></div><iframe src='/frame' style='width:300px;height:70px'></iframe>
<div id='nested' aria-label='Nested area'><div style='height:500px'>Nested text</div><button>Nested bottom</button></div>
<div id='drag' role='button' aria-label='Drag source'>Drag</div><div id='drop' role='button' aria-label='Drop target'>Drop</div><span id='dragged'></span>
<canvas id='canvas' width='400' height='80'></canvas><span id='canvas-result'></span>
<a download href='/file.txt'>Download fixture</a><button id='modal-open'>Open modal</button><dialog><button id='modal-close'>Close modal</button></dialog>
<script>window.events=[];const n=document.querySelector('#name');n.addEventListener('input',e=>events.push(e.isTrusted));document.querySelector('#hover').addEventListener('mouseenter',()=>document.querySelector('#hovered').textContent='Hovered');const s=document.querySelector('#shadow').attachShadow({mode:'open'});s.innerHTML='<label>Shadow field<input id="shadow-field"></label><button>Shadow button</button>';let dragging=false;document.querySelector('#drag').onmousedown=()=>dragging=true;document.querySelector('#drop').onmouseup=()=>{if(dragging)document.querySelector('#dragged').textContent='Dropped';dragging=false};const c=document.querySelector('#canvas');const cx=c.getContext('2d');cx.fillStyle='blue';cx.fillRect(100,10,100,50);c.onclick=e=>{if(e.offsetX>=100&&e.offsetX<=200)document.querySelector('#canvas-result').textContent='Canvas clicked'};document.querySelector('#modal-open').onclick=()=>document.querySelector('dialog').showModal();document.querySelector('#modal-close').onclick=()=>document.querySelector('dialog').close();</script>`;
const server = createServer((req, res) => {
  if (req.url === '/file.txt') { res.writeHead(200, { 'Content-Type': 'text/plain', 'Content-Disposition': 'attachment; filename="fixture.txt"' }); res.end('safe fixture'); return; }
  res.setHeader('Content-Type', 'text/html');
  if (req.url === '/frame') res.end('<!doctype html><label>Frame field<input id="frame-field"></label>');
  else if (req.url === '/sensitive') res.end('<!doctype html><input type="password" aria-label="Password">');
  else if (req.url === '/opaque') res.end('<!doctype html><iframe src="http://localhost:'+server.address().port+'/frame"></iframe>');
  else if (req.url.startsWith('/done')) res.end('<!doctype html><h1>Submission confirmed</h1>');
  else res.end(fixture);
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const origin = `http://127.0.0.1:${server.address().port}`;
let context, browserProcess, socket, passed = 0;
async function test(name, fn) { await fn(); passed++; console.log(`PASS ${name}`); }
try {
  const extension = path.join(work, 'extension');
  await cp(path.join(root, 'src'), path.join(extension, 'src'), { recursive: true });
  const manifest = JSON.parse(await readFile(path.join(root, 'manifest.json'), 'utf8'));
  manifest.host_permissions = ['http://*/*', 'https://*/*'];
  await writeFile(path.join(extension, 'manifest.json'), JSON.stringify(manifest));
  // Playwright auto-attaches every page, correctly triggering our no-debugger-takeover guard.
  // Launch its Chromium binary but attach the test harness ONLY to the extension panel.
  browserProcess = spawn(chromium.executablePath(), ['--headless=new', '--no-first-run', '--no-default-browser-check', '--remote-debugging-port=0', `--user-data-dir=${path.join(work, 'profile')}`, '--window-size=1200,987', `--disable-extensions-except=${extension}`, `--load-extension=${extension}`, origin], { stdio: ['ignore', 'ignore', 'pipe'] });
  let stderr = '';
  const endpoint = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('Chromium startup timeout')), 15000);
    browserProcess.stderr.on('data', chunk => { stderr += chunk; const match = stderr.match(/DevTools listening on (ws:\/\/\S+)/); if (match) { clearTimeout(timer); resolve(match[1]); } });
    browserProcess.on('exit', code => { clearTimeout(timer); reject(new Error(`Chromium exited ${code}`)); });
  });
  socket = new WebSocket(endpoint); await new Promise(resolve => socket.addEventListener('open', resolve, { once: true }));
  let sequence = 0; const pendingCalls = new Map();
  socket.addEventListener('message', event => { const message = JSON.parse(event.data); const entry = pendingCalls.get(message.id); if (entry) { pendingCalls.delete(message.id); message.error ? entry.reject(new Error(message.error.message)) : entry.resolve(message.result); } });
  const cdp = (method, params = {}, sessionId) => new Promise((resolve, reject) => { const id = ++sequence; pendingCalls.set(id, { resolve, reject }); socket.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) })); });
  let targets;
  for (let i = 0; i < 60; i++) { targets = (await cdp('Target.getTargets')).targetInfos; if (targets.some(t => t.type === 'service_worker' && t.url.endsWith('/src/background.js'))) break; await new Promise(r => setTimeout(r, 100)); }
  await cdp('Browser.setDownloadBehavior', { behavior: 'allow', downloadPath: path.join(work, 'downloads') });
  const id = new URL(targets.find(t => t.type === 'service_worker' && t.url.endsWith('/src/background.js')).url).host;
  const taskTarget = targets.find(t => t.type === 'page' && t.url.startsWith(origin)); assert.ok(taskTarget);
  const panelTarget = await cdp('Target.createTarget', { url: `chrome-extension://${id}/src/panel.html` });
  const { sessionId } = await cdp('Target.attachToTarget', { targetId: panelTarget.targetId, flatten: true });
  await cdp('Runtime.enable', {}, sessionId);
  await new Promise(r => setTimeout(r, 300));
  const panel = {
    async evaluate(fn, arg) { const result = await cdp('Runtime.evaluate', { expression: `(${fn.toString()})(${JSON.stringify(arg) ?? ''})`, awaitPromise: true, returnByValue: true }, sessionId); if (result.exceptionDetails) throw new Error(result.exceptionDetails.exception?.description || result.exceptionDetails.text); return result.result.value; },
    async waitForFunction(fn) { for (let i = 0; i < 100; i++) { if (await this.evaluate(fn)) return; await new Promise(r => setTimeout(r, 100)); } throw new Error('Condition timeout'); },
    async bringToFront() { await cdp('Target.activateTarget', { targetId: panelTarget.targetId }); },
    async reload() { await cdp('Page.reload', {}, sessionId); await new Promise(r => setTimeout(r, 300)); }
  };
  // Test-owned fixed fixture functions are injected via scripting from the panel.
  // Production never evaluates model code, and this harness never attaches the task tab.
  const fixtureEval = async (fn, arg) => {
    const expression = `(async()=>{const tab=(await chrome.tabs.query({})).find(t=>t.id===window.tabId||t.url?.startsWith(${JSON.stringify(origin)}));return (await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:${fn.toString()},args:[${JSON.stringify(arg) ?? 'null'}]}))[0].result})()`;
    const result = await cdp('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true }, sessionId);
    if (result.exceptionDetails) throw new Error(result.exceptionDetails.exception?.description || 'Fixture evaluation failed'); return result.result.value;
  };
  const locate = selector => ({
    inputValue: () => fixtureEval(selector => { const root = selector === '#shadow-field' ? document.querySelector('#shadow').shadowRoot : document; return root.querySelector(selector).value; }, selector),
    textContent: () => fixtureEval(selector => document.querySelector(selector).textContent, selector),
    boundingBox: () => fixtureEval(selector => { const r=document.querySelector(selector).getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height}; }, selector)
  });
  const page = {
    async goto(url) { await panel.evaluate(async ({id,url})=>chrome.tabs.update(id,{url}),{id: await panel.evaluate(async origin => (await chrome.tabs.query({})).find(t=>t.url?.startsWith(origin)).id,origin),url}); await new Promise(r=>setTimeout(r,350)); },
    async bringToFront() { await panel.evaluate(async origin => { const tab=(await chrome.tabs.query({})).find(t=>t.id===window.tabId||t.url?.startsWith(origin));await chrome.tabs.update(tab.id,{active:true});await chrome.windows.update(tab.windowId,{focused:true}); }, origin); }, 
    evaluate: fixtureEval,
    locator(selector) { const loc=locate(selector);loc.evaluate=(fn,arg)=>fixtureEval(new Function('arg',`const el = ${selector === '#shadow-field' ? "document.querySelector('#shadow').shadowRoot" : 'document'}.querySelector(${JSON.stringify(selector)});return (${fn.toString()})(el,arg);`),arg);return loc; },
    frameLocator() { return { locator() { return { inputValue: () => fixtureEval(()=>document.querySelector('iframe').contentDocument.querySelector('input').value) }; } }; }
  };
  const worker = panel;
  context = { async unroute() { await panel.evaluate(()=>window.fetch=window.realFetch); } };
  let windowRoute;
  // Fulfill local Azure fixtures in the extension fetch layer, without a network request.
  context.route = async (pattern, handler) => {
    windowRoute=handler;
    await cdp('Runtime.addBinding',{name:'testAzureRequest'},sessionId);
    await panel.evaluate(()=>{window.realFetch=window.fetch;window.mockPending=new Map();window.fetch=(url,options)=>new Promise(resolve=>{const id=crypto.randomUUID();mockPending.set(id,resolve);testAzureRequest(JSON.stringify({id,url,body:options.body}));});});
  };
  socket.addEventListener('message',async event=>{const m=JSON.parse(event.data);if(m.method!=='Runtime.bindingCalled'||m.params.name!=='testAzureRequest')return;const req=JSON.parse(m.params.payload);await windowRoute({request:()=>({postDataJSON:()=>JSON.parse(req.body)}),fulfill:async response=>{await panel.evaluate(({id,response})=>{mockPending.get(id)(new Response(response.body,{status:response.status||200,headers:{'Content-Type':'application/json'}}));mockPending.delete(id);},{id:req.id,response});}});});
  await panel.evaluate(async origin=>{const tab=(await chrome.tabs.query({})).find(t=>t.pendingUrl?.startsWith(origin)||t.url?.startsWith(origin));window.tabId=tab.id;await chrome.tabs.update(tab.id,{url:origin,active:true});},origin);
  await panel.waitForFunction(async()=>{const t=await chrome.tabs.get(tabId);return t.status==='complete'&&t.url.startsWith('http');});
  await page.bringToFront();
  await panel.evaluate(async origin => {
    const { Driver } = await import('./driver.js'); const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab.url.startsWith(origin)) throw new Error('Fixture must be active');
    window.tabId = tab.id; window.controller = new AbortController(); window.driver = new Driver(tab.id, controller.signal); await driver.acquire();
  }, origin);
  const snap = () => panel.evaluate(async () => { await driver.pause(150); return window.data = await driver.snapshot(); });
  const act = action => panel.evaluate(async action => driver.execute(action, data), action);
  const find = (data, label) => { const el = data.elements.find(e => e.label === label); assert.ok(el, `Missing ${label}`); return el.id; };
  await test('real unpacked extension, debugger ownership and isolated redacted DOM', async () => {
    const data = await snap(); assert.ok(find(data, 'Name')); assert.ok(find(data, 'Shadow field')); assert.ok(find(data, 'Frame field')); assert.ok(!JSON.stringify(data).includes('PRIVATE_INITIAL_VALUE'));
    const result = await panel.evaluate(async () => { const target = (await chrome.debugger.getTargets()).find(t => t.tabId === tabId); return target.attached; }); assert.equal(result, true);
  });
  await test('CDP typing produces trusted input in ordinary, shadow and same-origin frame controls', async () => {
    let data = await snap(); await act({ type: 'fill', element: find(data, 'Name'), value: 'Ada' }); assert.equal(await page.locator('#name').inputValue(), 'Ada'); assert.ok((await page.evaluate(() => events)).every(Boolean));
    data = await snap(); await act({ type: 'fill', element: find(data, 'Shadow field'), value: 'Shadow' }); assert.equal(await page.locator('#shadow-field').inputValue(), 'Shadow');
    data = await snap(); await act({ type: 'fill', element: find(data, 'Frame field'), value: 'Frame' }); assert.equal(await page.frameLocator('iframe').locator('input').inputValue(), 'Frame');
  });
  await test('keyboard, select and ordinary form submission are verified on the resulting page', async () => {
    let data=await snap();await act({type:'key',element:find(data,'Name'),key:'End'});
    await page.evaluate(()=>{const s=document.createElement('select');s.setAttribute('aria-label','Choice');s.innerHTML='<option value="a">A</option><option value="b">B</option>';document.body.prepend(s);});
    data=await snap();await act({type:'select',element:find(data,'Choice'),value:'b'});assert.equal(await page.locator('select').inputValue(),'b');
    data=await snap();await act({type:'submit',element:find(data,'Send')});
    await panel.waitForFunction(async()=> (await chrome.tabs.get(tabId)).url.includes('/done'));
    assert.equal(await page.locator('h1').textContent(),'Submission confirmed');await page.goto(origin);
  });
  await test('SPA mutations and modal layering reject stale actions before dispatch', async () => {
    let data = await snap(); const element = find(data, 'Original'); await page.locator('#mutable').evaluate(el => el.textContent = 'Changed'); await assert.rejects(act({ type: 'click', element }), /Page changed/);
    data = await snap(); await act({ type: 'click', element: find(data, 'Open modal') });
    data = await snap(); await assert.rejects(act({ type: 'click', element: find(data, 'Changed') }), /covered/);
    data = await snap(); await act({ type: 'click', element: find(data, 'Close modal') });
  });
  const autocompleteFixture = async (mode='normal') => {
    await page.goto(origin);
    await page.evaluate(mode=>{
      document.body.innerHTML='<form><label>Search<input id="query" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="suggestions"></label><button id="search" style="position:absolute;top:100px;left:20px;width:180px;height:40px">Search now</button><div id="suggestions" role="listbox" style="display:none;position:absolute;top:90px;left:10px;width:220px;height:80px;background:white;z-index:10"><div role="option" id="option" style="height:60px">Suggested item</div></div></form>';
      window.escapes=0;window.submissions=0;window.selections=0;
      const field=document.querySelector('#query'),list=document.querySelector('#suggestions');
      document.querySelector('form').onsubmit=e=>{e.preventDefault();submissions++;};
      field.oninput=()=>{list.style.display='block';field.setAttribute('aria-expanded','true');};
      field.onkeydown=e=>{if(e.key==='Escape'){escapes++;if(mode!=='persistent'){list.style.display='none';field.setAttribute('aria-expanded','false');}if(mode==='replace'){const b=document.querySelector('#search');b.replaceWith(b.cloneNode(true));}}};
      document.querySelector('#option').onclick=()=>{selections++;list.style.display='none';field.setAttribute('aria-expanded','false');};
      if(mode==='unlinked')field.removeAttribute('aria-controls');
    },mode);
  };
  await test('autocomplete dismissal re-observes once before safe submit, options remain selectable',async()=>{
    await autocompleteFixture();let d=await snap();await act({type:'fill',element:find(d,'Search'),value:'News'});
    d=await snap();await assert.rejects(act({type:'click',element:find(d,'Search now')}),/suggestion popup with Escape/);
    assert.deepEqual(await page.evaluate(()=>({escapes,submissions})),{escapes:1,submissions:0});
    d=await snap();await act({type:'click',element:find(d,'Search now')});assert.equal(await page.evaluate(()=>submissions),1);
    await autocompleteFixture();d=await snap();await act({type:'fill',element:find(d,'Search'),value:'News'});d=await snap();await act({type:'click',element:find(d,'Suggested item')});
    assert.deepEqual(await page.evaluate(()=>({escapes,selections,submissions})),{escapes:0,selections:1,submissions:0});
  });
  await test('autocomplete does not dismiss real dialogs, unrelated lists or unfocused fields',async()=>{
    for(const mode of ['modal','unlinked','blur']){
      await autocompleteFixture(mode);let d=await snap();await act({type:'fill',element:find(d,'Search'),value:'News'});
      await page.evaluate(mode=>{if(mode==='modal'){const dialog=document.createElement('dialog');dialog.textContent='Genuine dialog';document.body.append(dialog);dialog.showModal();document.querySelector('#query').focus();}if(mode==='blur')document.querySelector('#query').blur();},mode);
      d=await snap();await assert.rejects(act({type:'click',element:find(d,'Search now')}),/covered/);
      assert.deepEqual(await page.evaluate(()=>({escapes,submissions})),{escapes:0,submissions:0});
    }
  });
  await test('autocomplete preserves replacement protection and bounds Escape attempts',async()=>{
    await autocompleteFixture('replace');let d=await snap();await act({type:'fill',element:find(d,'Search'),value:'News'});d=await snap();await assert.rejects(act({type:'click',element:find(d,'Search now')}),/suggestion popup with Escape/);
    await assert.rejects(snap(),/Target changed after autocomplete/);assert.equal(await page.evaluate(()=>submissions),0);
    // Fresh run: one Escape for this edit, then ordinary covered-target handling.
    await panel.evaluate(()=>driver.close());await new Promise(r=>setTimeout(r,100));await page.goto(origin);
    await panel.evaluate(async()=>{const {Driver}=await import('./driver.js');controller=new AbortController();driver=new Driver(tabId,controller.signal);await driver.acquire();});
    await autocompleteFixture('persistent');d=await snap();await act({type:'fill',element:find(d,'Search'),value:'News'});d=await snap();await assert.rejects(act({type:'click',element:find(d,'Search now')}),/suggestion popup with Escape/);
    d=await snap();await assert.rejects(act({type:'click',element:find(d,'Search now')}),/covered/);assert.equal(await page.evaluate(()=>escapes),1);
    d=await snap();await act({type:'fill',element:find(d,'Search'),value:'Second'});d=await snap();await assert.rejects(act({type:'click',element:find(d,'Search now')}),/suggestion popup with Escape/);
    d=await snap();await act({type:'fill',element:find(d,'Search'),value:'Third'});d=await snap();await assert.rejects(act({type:'click',element:find(d,'Search now')}),/covered/);assert.equal(await page.evaluate(()=>escapes),2);
    await page.goto(origin);
  });
  await test('semantic actions ignore unrelated churn but reject replaced targets and stale images',async()=>{
    await page.goto(origin);let d=await snap();
    await page.evaluate(()=>{const ticker=document.createElement('span');ticker.style.cssText='position:fixed;right:0;bottom:0';ticker.id='ticker';ticker.textContent='News changed';document.body.append(ticker);});
    await act({type:'fill',element:find(d,'Name'),value:'Stable target'});assert.equal(await page.locator('#name').inputValue(),'Stable target');
    d=await snap();await page.locator('#name').evaluate(el=>el.replaceWith(el.cloneNode(true)));await assert.rejects(act({type:'fill',element:find(d,'Name'),value:'Wrong target'}),/referenced element/);
    await snap();await panel.evaluate(async()=>data.image=await driver.capture(data));await page.locator('#ticker').evaluate(el=>el.textContent='Changed again');await assert.rejects(act({type:'pointClick',x:10,y:10}),/DOM mutation/);
    await page.goto(origin);
  });
  await test('hover, pointer drag, nested scrolling and UI-state waits', async () => {
    let data = await snap(); await act({ type: 'hover', element: find(data, 'Hover me') }); assert.equal(await page.locator('#hovered').textContent(), 'Hovered');
    data = await snap(); await act({ type: 'drag', element: find(data, 'Drag source'), target: find(data, 'Drop target') }); assert.equal(await page.locator('#dragged').textContent(), 'Dropped');
    data = await snap(); await act({ type: 'scrollElement', element: find(data, 'Nested area'), direction: 'bottom' }); assert.ok(await page.locator('#nested').evaluate(el => el.scrollTop > 0));
    await snap(); await page.evaluate(() => setTimeout(() => { const p=document.createElement('p');p.textContent='Async ready';document.body.append(p); }, 250));
    assert.equal(await act({ type: 'waitFor', text: 'Async ready', state: 'visible', milliseconds: 2000 }), 'UI state observed.');
  });
  await test('bounded in-memory screenshot dimensions, pixel mapping and canvas input', async () => {
    await page.goto(origin); await snap();
    const image = await panel.evaluate(async () => { data.image = await driver.capture(data); return { width: data.image.width, height: data.image.height, length: data.image.data.length }; });
    assert.equal(image.width, 1024); assert.ok(image.height <= 1024); assert.ok(image.length < 1500000);
    const viewport = await page.evaluate(()=>({width:innerWidth,height:innerHeight}));
    const r = await page.locator('#canvas').boundingBox();
    await act({ type: 'pointClick', x: (r.x + 150) * image.width / viewport.width, y: (r.y + 30) * image.height / viewport.height }); assert.equal(await page.locator('#canvas-result').textContent(), 'Canvas clicked');
    await snap(); await panel.evaluate(async () => data.image = await driver.capture(data));
    await page.locator('#canvas').evaluate(c => { c.getContext('2d').fillStyle = 'red'; c.getContext('2d').fillRect(0,0,50,50); });
    await assert.rejects(act({ type: 'pointClick', x: 100, y: 100 }), /Screenshot pixels changed/);
  });
  await test('downloads tracked to completion, never auto-opened', async () => {
    let data = await snap(); const result = JSON.parse(await act({ type: 'download', element: find(data, 'Download fixture') })); assert.equal(result.state, 'complete'); assert.equal(result.bytesReceived, 12);
    const downloads = await panel.evaluate(async () => (await chrome.downloads.search({ query: ['fixture.txt'] })).map(d => ({ state: d.state, opened: d.opened })));
    assert.ok(downloads.length > 0); assert.ok(downloads.every(d => d.state === 'complete' && d.opened !== true));
  });
  await test('sensitive pages and opaque-frame screenshots fail closed', async () => {
    await page.goto(`${origin}/sensitive`); await assert.rejects(snap(), /Sensitive/);
    await page.goto(`${origin}/opaque`); const data = await snap(); assert.equal(data.opaqueFrames, true); await assert.rejects(panel.evaluate(async () => driver.capture(data)), /opaque/);
    await page.goto(origin);
  });
  await test('stop detaches debugger and rejects further input', async () => {
    await panel.evaluate(() => controller.abort());
    await assert.rejects(snap(), /abort|stopped/i);
    await panel.waitForFunction(async () => !(await chrome.debugger.getTargets()).some(t => t.tabId === tabId && t.attached));
  });
  const mockConfig = { endpoint: 'https://fixture.openai.azure.com', deployment: 'vision', key: 'FAKE_LOCAL_TEST_KEY' };
  await test('runner counts autocomplete Escape, requests fresh decision and submits only once',async()=>{
    await autocompleteFixture();let count=0;
    await context.route('https://fixture.openai.azure.com/**',async route=>{
      count++;const b=route.request().postDataJSON();const evidence=JSON.parse(b.messages[2].content[0].text.split('\n').slice(1).join('\n'));const s=evidence.snapshot;
      const action=count===1?{type:'fill',element:s.elements.find(e=>e.label==='Search').id,value:'News'}:count<=3?{type:'click',element:s.elements.find(e=>e.label==='Search now').id}:{type:'done',message:'Observed submit once.'};
      if(count===3){assert.ok(evidence.history.some(h=>h.action==='dismiss autocomplete'));assert.equal(await page.evaluate(()=>submissions),0);}
      await route.fulfill({body:JSON.stringify({choices:[{message:{content:JSON.stringify(action)}}],usage:{prompt_tokens:100,completion_tokens:10,total_tokens:110}})});
    });
    const r=await panel.evaluate(async config=>{const {runTask}=await import('./runner.js');let totals;const result=await runTask({tabId,task:'Search for News',config,consent:true,signal:new AbortController().signal,onUsage:t=>totals=t});return {result,totals};},mockConfig);
    assert.equal(r.result.actions,3);assert.equal(r.result.visionFallbacks,0);assert.equal(r.result.recoveries,0);assert.equal(r.totals.total,440);assert.equal(count,4);
    assert.deepEqual(await page.evaluate(()=>({escapes,submissions})),{escapes:1,submissions:1});await context.unroute();
  });
  await test('real runner uses DOM-first vision fallback, mocked Azure and token totals including summary', async () => {
    await page.goto(origin); await page.bringToFront();
    const requests = [];
    await context.route('https://fixture.openai.azure.com/**', async route => {
      const body = route.request().postDataJSON(); requests.push(body);
      let content;
      if (body.messages[0].content.startsWith('You write')) content = { summary: 'Public fixture observed. No submission claimed.' };
      else if (requests.length === 1) content = { type: 'vision', reason: 'Inspect canvas' };
      else content = { type: 'done', message: 'Public fixture observed.' };
      await route.fulfill({ contentType: 'application/json', body: JSON.stringify({ choices: [{ message: { content: JSON.stringify(content) } }], usage: { prompt_tokens: 100, completion_tokens: 10, total_tokens: 110 } }) });
    });
    const result = await panel.evaluate(async config => {
      const { runTask } = await import('./runner.js'); let totals;
      const result = await runTask({ tabId, task: 'Summarize public fixture', config, consent: true, signal: new AbortController().signal, onUsage: value => totals = value });
      return { result, totals };
    }, mockConfig);
    assert.equal(requests.length, 3); assert.equal(requests[0].messages[2].content.length, 1); assert.equal(requests[1].messages[2].content[1].type, 'image_url'); assert.equal(requests[2].messages[2].content.length, 1); assert.equal(result.totals.total, 330); assert.equal(result.result.actions, 1);
    await panel.waitForFunction(async () => !(await chrome.debugger.getTargets()).some(t => t.tabId === tabId && t.attached));
    await context.unroute('https://fixture.openai.azure.com/**');
  });
  await test('no consent means no model call or attachment; model errors detach', async () => {
    await assert.rejects(panel.evaluate(async config => { const { runTask }=await import('./runner.js'); return runTask({tabId,task:'test',config,consent:false,signal:new AbortController().signal}); }, mockConfig), /consent/);
    await context.route('https://fixture.openai.azure.com/**', route => route.fulfill({ status: 429, body: 'Do not echo this body' }));
    await assert.rejects(panel.evaluate(async config => { const {runTask}=await import('./runner.js'); return runTask({tabId,task:'test',config,consent:true,signal:new AbortController().signal}); }, mockConfig), /HTTP 429/);
    await panel.waitForFunction(async () => !(await chrome.debugger.getTargets()).some(t => t.tabId === tabId && t.attached)); await context.unroute('https://fixture.openai.azure.com/**');
  });
  await test('active-tab switch and panel pagehide detach ownership', async () => {
    await page.bringToFront();
    await panel.evaluate(async () => { const {Driver}=await import('./driver.js');controller=new AbortController();driver=new Driver(tabId,controller.signal);await driver.acquire(); });
    await panel.bringToFront(); await panel.waitForFunction(async () => !(await chrome.debugger.getTargets()).some(t => t.tabId === tabId && t.attached));
    await page.bringToFront(); await panel.evaluate(async () => { const {Driver}=await import('./driver.js');controller=new AbortController();driver=new Driver(tabId,controller.signal);await driver.acquire(); });
    await panel.reload();
    await worker.evaluate(async tabId => { for(let i=0;i<30;i++){if(!(await chrome.debugger.getTargets()).some(t=>t.tabId===tabId&&t.attached))return;await new Promise(r=>setTimeout(r,100));}throw new Error('Not detached'); }, await worker.evaluate(async origin => (await chrome.tabs.query({})).find(t=>t.url?.startsWith(origin)).id, origin));
  });
  await test('existing debugger session is never taken over', async () => {
    const other = await cdp('Target.attachToTarget', { targetId: taskTarget.targetId, flatten: true });
    try {
      await page.bringToFront();
      await assert.rejects(panel.evaluate(async origin => { const {Driver}=await import('./driver.js'); const t=(await chrome.tabs.query({})).find(t=>t.url?.startsWith(origin));const d=new Driver(t.id,new AbortController().signal);try{await d.acquire();}finally{d.close();} },origin), /Another debugger/);
      assert.ok((await cdp('Target.getTargetInfo',{targetId:taskTarget.targetId})).targetInfo.attached);
    } finally { await cdp('Target.detachFromTarget', { sessionId: other.sessionId }); }
  });
  await test('bounded recovery discards a stale model decision and completes without replay', async () => {
    await page.goto(origin);await page.bringToFront();
    await panel.evaluate(async origin=>window.tabId=(await chrome.tabs.query({})).find(t=>t.url?.startsWith(origin)).id,origin);
    let count=0;
    await context.route('https://fixture.openai.azure.com/**',async route=>{
      count++;const body=route.request().postDataJSON();const evidence=JSON.parse(body.messages[2].content[0].text.split('\n').slice(1).join('\n'));
      let action={type:'done',message:'Fresh observation complete.'};
      if(count===1){action={type:'click',element:evidence.snapshot.elements.find(e=>e.label==='Original').id};await page.locator('#mutable').evaluate(el=>el.textContent='Replaced while model was thinking');}
      await route.fulfill({body:JSON.stringify({choices:[{message:{content:JSON.stringify(action)}}]})});
    });
    const result=await panel.evaluate(async config=>{const {runTask}=await import('./runner.js');let totals;const result=await runTask({tabId,task:'Inspect fixture',config,consent:true,signal:new AbortController().signal,onUsage:t=>totals=t});return {result,totals};},mockConfig);
    assert.equal(result.result.recoveries,1);assert.equal(result.result.actions,0);assert.equal(result.totals.missing,2);
    await context.unroute();
  });
  await test('30 non-wait action cap is enforced on the real runner', async()=>{
    await page.goto(origin);await page.bringToFront();let count=0;
    await context.route('https://fixture.openai.azure.com/**',route=>{count++;return route.fulfill({body:JSON.stringify({choices:[{message:{content:JSON.stringify({type:'scroll',direction:'top'})}}]})});});
    await assert.rejects(panel.evaluate(async config=>{const {runTask}=await import('./runner.js');return runTask({tabId,task:'Exercise action cap',config,consent:true,signal:new AbortController().signal});},mockConfig),/30-action limit/);
    assert.equal(count,31);await context.unroute();
    await panel.waitForFunction(async()=>!(await chrome.debugger.getTargets()).some(t=>t.tabId===tabId&&t.attached));
  });
  await test('pending model request Stop cancels run and worker deadline detaches',async()=>{
    let requested=false;
    await context.route('https://fixture.openai.azure.com/**',async()=>{requested=true;});
    await panel.evaluate(async config=>{const {runTask}=await import('./runner.js');window.abortPending=new AbortController();window.pendingResult=runTask({tabId,task:'Wait for model',config,consent:true,signal:abortPending.signal}).then(()=> 'unexpected success',e=>e.message);},mockConfig);
    for(let i=0;i<100&&!requested;i++)await new Promise(r=>setTimeout(r,100));assert.ok(requested);
    await panel.evaluate(()=>abortPending.abort());
    await panel.waitForFunction(async()=>!(await chrome.debugger.getTargets()).some(t=>t.tabId===tabId&&t.attached));
    // Resolve mocked fetch to let its accounting finally path run; real fetch honors AbortSignal.
    await panel.evaluate(()=>{for(const resolve of mockPending.values())resolve(new Response('{}',{status:429}));mockPending.clear();});
    await panel.evaluate(async()=>pendingResult);await context.unroute();
    await panel.evaluate(async()=>{const {Driver}=await import('./driver.js');controller=new AbortController();driver=new Driver(tabId,controller.signal);await driver.acquire();await chrome.alarms.create('run-deadline',{when:Date.now()+100});});
    await panel.waitForFunction(async()=>!(await chrome.debugger.getTargets()).some(t=>t.tabId===tabId&&t.attached));
  });
  const coveredFixture = async (mode='partial') => {
    await page.goto(origin);await page.bringToFront();
    await page.evaluate(mode=>{
      document.body.innerHTML='<div id="card" style="position:relative;margin:40px;width:400px;height:100px"><a id="headline" href="/done" style="display:block;width:400px;height:100px">Fixture headline</a><div id="wrapper"><a id="cover" href="/done" style="position:absolute;inset:0" aria-label="Card cover"></a></div></div><p id="mutation">Stable</p>';
      window.clicks=0;window.overlayClicks=0;
      document.querySelector('#headline').onclick=e=>{e.preventDefault();clicks++;};
      const cover=document.querySelector('#cover');cover.onclick=e=>{e.preventDefault();overlayClicks++;};
      if(mode!=='card'){cover.removeAttribute('href');cover.style.left=mode==='partial'?'150px':'0';cover.style.right=mode==='partial'?'150px':'0';}
      if(mode==='modal'){const d=document.createElement('dialog');d.innerHTML='<button>Close real modal</button>';document.body.append(d);d.showModal();}
    },mode);
  };
  await test('identical destination card overlay navigates safely, modal and mismatched links do not',async()=>{
    await coveredFixture('card');
    await panel.evaluate(async()=>{const {Driver}=await import('./driver.js');controller=new AbortController();driver=new Driver(tabId,controller.signal);await driver.acquire();});
    let d=await snap();await act({type:'click',element:find(d,'Fixture headline')});
    await panel.waitForFunction(async()=>(await chrome.tabs.get(tabId)).url.includes('/done'));
    await coveredFixture('card');await page.locator('#cover').evaluate(el=>el.href='/unrelated');d=await snap();await assert.rejects(act({type:'click',element:find(d,'Fixture headline')}),/covered/);
    assert.equal(await page.evaluate(()=>overlayClicks),0);
    await coveredFixture('modal');d=await snap();await assert.rejects(act({type:'click',element:find(d,'Fixture headline')}),/covered/);
    assert.equal(await page.evaluate(()=>clicks),0);await panel.evaluate(()=>driver.close());await new Promise(r=>setTimeout(r,100));
  });
  await test('covered-target vision budget survives three stale recoveries, counts tokens and clicks once',async()=>{
    await coveredFixture();let count=0;
    await context.route('https://fixture.openai.azure.com/**',async route=>{
      count++;const body=route.request().postDataJSON();const evidence=JSON.parse(body.messages[2].content[0].text.split('\n').slice(1).join('\n'));const s=evidence.snapshot;
      let action={type:'click',element:s.elements.find(e=>e.label==='Fixture headline')?.id};
      if(count<=3)await page.locator('#headline').evaluate((el,n)=>el.href='/done?version='+n,count);
      if(count===5){assert.equal(s.coveredRecovery,true);assert.equal(body.messages[2].content[1].type,'image_url');const r=await page.locator('#headline').boundingBox();const v=await page.evaluate(()=>({w:innerWidth,h:innerHeight}));action={type:'pointClick',x:(r.x+30)*s.image.width/v.w,y:(r.y+30)*s.image.height/v.h};}
      if(count===6)action={type:'done',message:'Observed navigation to requested article.'};
      await route.fulfill({body:JSON.stringify({choices:[{message:{content:JSON.stringify(action)}}],usage:{prompt_tokens:100,completion_tokens:10,total_tokens:110}})});
    });
    const result=await panel.evaluate(async config=>{const {runTask}=await import('./runner.js');let totals;const result=await runTask({tabId,task:'Open the headline',config,consent:true,signal:new AbortController().signal,onUsage:t=>totals=t});return {result,totals};},mockConfig);
    assert.equal(result.result.recoveries,3);assert.equal(result.result.visionFallbacks,1);assert.equal(result.result.actions,2);assert.equal(result.totals.total,660);assert.equal(count,6);
    assert.ok((await panel.evaluate(async()=>(await chrome.tabs.get(tabId)).url)).includes('/done'));await context.unroute();
  });
  await test('vision cannot click through unrelated overlay and repeated covered targets are bounded',async()=>{
    await coveredFixture('full');let count=0;
    await context.route('https://fixture.openai.azure.com/**',async route=>{
      count++;const body=route.request().postDataJSON();const s=JSON.parse(body.messages[2].content[0].text.split('\n').slice(1).join('\n')).snapshot;
      let action={type:'click',element:s.elements.find(e=>e.label==='Fixture headline').id};
      if(count===2){const r=await page.locator('#headline').boundingBox();const v=await page.evaluate(()=>({w:innerWidth,h:innerHeight}));action={type:'pointClick',x:(r.x+200)*s.image.width/v.w,y:(r.y+50)*s.image.height/v.h};}
      await route.fulfill({body:JSON.stringify({choices:[{message:{content:JSON.stringify(action)}}]})});
    });
    await assert.rejects(panel.evaluate(async config=>{const {runTask}=await import('./runner.js');return runTask({tabId,task:'Open headline',config,consent:true,signal:new AbortController().signal});},mockConfig),/overlay input blocked/);
    assert.equal(await page.evaluate(()=>overlayClicks),0);assert.equal(await page.evaluate(()=>clicks),0);await context.unroute();
    count=0;await context.route('https://fixture.openai.azure.com/**',async route=>{count++;const body=route.request().postDataJSON();const s=JSON.parse(body.messages[2].content[0].text.split('\n').slice(1).join('\n')).snapshot;await route.fulfill({body:JSON.stringify({choices:[{message:{content:JSON.stringify({type:'click',element:s.elements.find(e=>e.label==='Fixture headline').id})}}]})});});
    await assert.rejects(panel.evaluate(async config=>{const {runTask}=await import('./runner.js');return runTask({tabId,task:'Open headline',config,consent:true,signal:new AbortController().signal});},mockConfig),/vision fallback limit/);
    assert.equal(count,3);assert.equal(await page.evaluate(()=>overlayClicks),0);await context.unroute();
  });
  await test('self-scrolling refreshes references without consuming stale budget',async()=>{
    await page.goto(origin);await page.evaluate(()=>{document.body.innerHTML='<div style="height:1600px"></div><button id="below">Below fold</button>';window.pressCount=0;document.querySelector('#below').onclick=()=>pressCount++;});let count=0;
    await context.route('https://fixture.openai.azure.com/**',async route=>{count++;const b=route.request().postDataJSON();const s=JSON.parse(b.messages[2].content[0].text.split('\n').slice(1).join('\n')).snapshot;const a=count<=2?{type:'click',element:s.elements.find(e=>e.label==='Below fold').id}:{type:'done',message:'Button pressed once.'};await route.fulfill({body:JSON.stringify({choices:[{message:{content:JSON.stringify(a)}}]})});});
    const r=await panel.evaluate(async config=>{const {runTask}=await import('./runner.js');return runTask({tabId,task:'Press below-fold button once',config,consent:true,signal:new AbortController().signal});},mockConfig);
    assert.equal(r.recoveries,0);assert.equal(r.actions,1);assert.equal(await page.evaluate(()=>pressCount),1);await context.unroute();
  });
  await test('successful actions reset consecutive stale budget without replaying input',async()=>{
    await page.goto(origin);await page.evaluate(()=>{document.body.innerHTML='<button id="progress">Progress</button>';window.pressCount=0;document.querySelector('#progress').onclick=()=>pressCount++;});let count=0;
    await context.route('https://fixture.openai.azure.com/**',async route=>{count++;const b=route.request().postDataJSON();const s=JSON.parse(b.messages[2].content[0].text.split('\n').slice(1).join('\n')).snapshot;const a=count===9?{type:'done',message:'Two presses observed.'}:{type:'click',element:s.elements[0].id};if([1,2,3,5,6,7].includes(count))await page.locator('#progress').evaluate((el,n)=>el.setAttribute('aria-label','Progress '+n),count);await route.fulfill({body:JSON.stringify({choices:[{message:{content:JSON.stringify(a)}}]})});});
    const r=await panel.evaluate(async config=>{const {runTask}=await import('./runner.js');return runTask({tabId,task:'Press progress twice',config,consent:true,signal:new AbortController().signal});},mockConfig);
    assert.equal(r.recoveries,6);assert.equal(r.actions,2);assert.equal(await page.evaluate(()=>pressCount),2);await context.unroute();
  });
  await test('new-tab startup uses no-page evidence, defers debugger and continues after navigation', async () => {
    await panel.evaluate(async()=>{await chrome.tabs.update(tabId,{url:'chrome://newtab/',active:true});});
    await panel.waitForFunction(async()=>{const t=await chrome.tabs.get(tabId);return t.url==='chrome://newtab/'&&t.status==='complete';});
    await panel.evaluate(async()=>{const {Driver}=await import('./driver.js');window.startDriver=new Driver(tabId,new AbortController().signal);await startDriver.acquire();window.startData=await startDriver.snapshot();});
    assert.equal(await panel.evaluate(()=>startData.noPage),true);
    assert.equal(await panel.evaluate(async()=> (await chrome.debugger.getTargets()).some(t=>t.tabId===tabId&&t.attached)),false);
    await assert.rejects(panel.evaluate(()=>startDriver.capture(startData)),/ordinary HTTP/);
    await assert.rejects(panel.evaluate(()=>startDriver.dom({type:'snapshot'})),/inaccessible/);
    await assert.rejects(panel.evaluate(()=>startDriver.execute({type:'vision',reason:'blocked'},startData)),/Only navigate/);
    await assert.rejects(panel.evaluate(()=>startDriver.execute({type:'back'},startData)),/Only navigate/);
    await panel.evaluate(()=>startDriver.close());await new Promise(r=>setTimeout(r,100));
    let count=0;
    await context.route('https://fixture.openai.azure.com/**',async route=>{
      count++;const body=route.request().postDataJSON();const evidence=JSON.parse(body.messages[2].content[0].text.split('\n').slice(1).join('\n'));
      if(count===1){assert.equal(evidence.snapshot.noPage,true);assert.deepEqual(evidence.snapshot.elements,[]);assert.equal(body.messages[2].content.length,1);assert.equal(await panel.evaluate(async()=> (await chrome.debugger.getTargets()).some(t=>t.tabId===tabId&&t.attached)),false);}
      else {assert.ok(!evidence.snapshot.noPage);assert.ok(evidence.snapshot.elements.length>0);assert.equal(await panel.evaluate(async()=> (await chrome.debugger.getTargets()).some(t=>t.tabId===tabId&&t.attached)),true);}
      const action=count===1?{type:'navigate',url:origin}:{type:'done',message:'Website inspected after new-tab navigation.'};
      await route.fulfill({body:JSON.stringify({choices:[{message:{content:JSON.stringify(action)}}]})});
    });
    const result=await panel.evaluate(async config=>{const {runTask}=await import('./runner.js');return runTask({tabId,task:'Open the fixture website and inspect it',config,consent:true,signal:new AbortController().signal});},mockConfig);
    assert.equal(result.actions,1);assert.equal(count,2);await context.unroute();
    await panel.waitForFunction(async()=>!(await chrome.debugger.getTargets()).some(t=>t.tabId===tabId&&t.attached));
  });
  await test('other internal pages still reject startup without attaching',async()=>{
    await panel.evaluate(async()=>chrome.tabs.update(tabId,{url:'chrome://settings/',active:true}));
    await panel.waitForFunction(async()=>(await chrome.tabs.get(tabId)).url.startsWith('chrome://settings'));
    await assert.rejects(panel.evaluate(async()=>{const {Driver}=await import('./driver.js');const d=new Driver(tabId,new AbortController().signal);try{await d.acquire();}finally{d.close();}}),/website or new\/blank/);
    assert.equal(await panel.evaluate(async()=> (await chrome.debugger.getTargets()).some(t=>t.tabId===tabId&&t.attached)),false);
  });
  console.log(`Browser integration: ${passed} passed`);
} finally {
  if (browserProcess && browserProcess.exitCode === null) { browserProcess.kill(); await Promise.race([once(browserProcess, 'exit'), new Promise(r => setTimeout(r, 3000))]); }
  socket?.close(); await new Promise(resolve => server.close(resolve)); await rm(work, { recursive: true, force: true, maxRetries: 20, retryDelay: 200 });
}
