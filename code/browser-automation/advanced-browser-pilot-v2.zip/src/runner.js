import { Driver, StaleError, CoveredError, PreparedError, AutocompleteError } from './driver.js';
import { MAX_ACTIONS, RUN_TIMEOUT, configFrom, nextAction, summarizeResults, wantsSummary, createUsageTracker, actionDescription, actionProgress } from './core.js';
export async function runTask({ tabId, task, config, consent, signal, onProgress = () => {}, onUsage = () => {}, onResult = () => {} }) {
  if (consent !== true) throw new Error('Explicit run consent is required before inspection or screenshots.');
  config = configFrom(config);
  if (!task?.trim() || task.length > 4000) throw new Error('Enter a task of at most 4000 characters.');
  const combined = AbortSignal.any([signal, AbortSignal.timeout(RUN_TIMEOUT)]);
  const driver = new Driver(tabId, combined);
  const usage = createUsageTracker(onUsage);
  const history = [];
  let actions = 0, preparations = 0, recoveries = 0, consecutiveRecoveries = 0, visionFallbacks = 0, vision = false, coveredRecovery = false;
  const recover = async error => {
    if (error instanceof AutocompleteError) {
      actions++;
      onProgress(error.message);
      history.push({ action: 'dismiss autocomplete', result: 'Escape sent only to the field filled by this run. Intended click was NOT dispatched. Inspect fresh references before deciding the next action.' });
      vision = false; coveredRecovery = false;
      await driver.ready(); return;
    }
    if (error instanceof PreparedError) {
      if (++preparations > 2) throw new Error('Target repeatedly needed scrolling; stopped before input.');
      onProgress('Target scrolled into view. Refreshing references before input; no stale-recovery budget used.');
      await driver.ready(); return;
    }
    if (error instanceof CoveredError) {
      if (++visionFallbacks > 2 || actions >= MAX_ACTIONS) throw new Error('Covered-target vision fallback limit reached; stopped without replaying input.');
      actions++; vision = true; coveredRecovery = true;
      history.push({ action: 'covered target', result: 'No input dispatched. Inspect the fresh image. Do not click an overlay or a different target. Use an exposed point on the original click target, an ordinary DOM action to dismiss a recognized dialog when appropriate to the task, or done explaining the obstruction.' });
      onProgress(`Target covered. Inspecting with vision (${visionFallbacks}/2); no input replayed.`);
      await driver.ready();
      return;
    }
    if (!(error instanceof StaleError) || ++consecutiveRecoveries > 3) throw error;
    recoveries++;
    onProgress(`Page changed or target unavailable. Discarding decision and re-observing (${consecutiveRecoveries}/3 consecutive).`);
    await driver.ready();
  };
  try {
    await driver.acquire();
    await driver.ready();
    while (true) {
      driver.assert();
      onProgress(`Inspecting task page · ${actions}/${MAX_ACTIONS} actions used.`);
      let data;
      try {
        data = await driver.snapshot();
        if (coveredRecovery) data.coveredRecovery = true;
        if (vision) { onProgress('Capturing a bounded viewport image under this run’s consent…'); data.image = await driver.capture(data); }
        const { tabUrl, ...modelData } = data;
        onProgress(vision ? 'Asking Azure using DOM and viewport image…' : 'Asking Azure using DOM evidence…');
        const action = await nextAction(config, task, modelData, history, AbortSignal.any([driver.signal, AbortSignal.timeout(30000)]), fetch, usage.record);
        await driver.fresh(data, action);
        if (action.type === 'done') {
          let report = action.message;
          let note = 'Automation model report; verify against the page.';
          if (wantsSummary(task)) {
            onProgress('Writing results from observed evidence…');
            try {
              const { image, ...textData } = modelData;
              report = await summarizeResults(config, task, textData, history, report, AbortSignal.any([driver.signal, AbortSignal.timeout(30000)]), fetch, usage.record);
              await driver.fresh(data);
              note = 'AI-generated summary from bounded page evidence; not independently verified.';
            } catch (error) {
              driver.assert();
              if (error instanceof StaleError) throw error;
              note = `Summary unavailable: ${error.message} Automation report retained.`;
            }
          }
          onResult({ report, note, source: data.url, actions });
          return { report, actions, history, recoveries, visionFallbacks };
        }
        const waiting = ['wait', 'waitFor'].includes(action.type);
        if (!waiting && actions >= MAX_ACTIONS) throw new Error('30-action limit reached. Review the page before another run.');
        if (action.type === 'vision') {
          actions++; vision = true;
          history.push({ action: 'vision', result: 'A fresh screenshot will accompany the next observation.' });
          continue;
        }
        onProgress(actionProgress(action, data.elements));
        const result = await driver.execute(action, data);
        if (!waiting) { actions++; consecutiveRecoveries = 0; preparations = 0; }
        history.push({ action: actionDescription(action), result });
        if (history.length > 60) history.shift();
        vision = false; coveredRecovery = false;
        await driver.ready();
      } catch (error) { await recover(error); }
      finally { if (data?.image) { data.image.data = ''; delete data.image; } }
    }
  } finally { driver.close(); }
}
