"""aks_browser_sandbox.py — Pattern A: Chrome + agent-browser on AKS."""

from __future__ import annotations

import time
import uuid
from typing import Optional

from kubernetes import client, config
from kubernetes.client.rest import ApiException

# Reuse your AKSSandbox class (execute / upload_files / download_files)
from aks_sandbox import AKSSandbox  # adjust import path


DEFAULT_BROWSER_IMAGE = "acrinfraeus.azurecr.io/deepagents-browser:v1"
DEFAULT_SESSION = "qa"


class AKSBrowserSandboxManager:
    """Create long-lived pods with Chromium + agent-browser."""

    def __init__(
        self,
        *,
        namespace: str = "deepagents-sandboxes",
        image: str = DEFAULT_BROWSER_IMAGE,
        image_pull_secret: str | None = None,
        service_account: str | None = None,
    ) -> None:
        try:
            config.load_incluster_config()
        except config.ConfigException:
            config.load_kube_config()
        self.api = client.CoreV1Api()
        self.namespace = namespace
        self.image = image
        self.image_pull_secret = image_pull_secret
        self.service_account = service_account

    def ensure_namespace(self) -> None:
        try:
            self.api.read_namespace(self.namespace)
        except ApiException as e:
            if e.status != 404:
                raise
            self.api.create_namespace(
                client.V1Namespace(metadata=client.V1ObjectMeta(name=self.namespace))
            )

    def create(self, *, name: str | None = None) -> AKSSandbox:
        self.ensure_namespace()
        name = (name or f"browser-{uuid.uuid4().hex[:10]}")[:63].rstrip("-")

        container = client.V1Container(
            name="sandbox",
            image=self.image,
            image_pull_policy="IfNotPresent",
            command=["sleep", "infinity"],
            working_dir="/workspace",
            env=[
                client.V1EnvVar(name="HOME", value="/workspace"),
            ],
            resources=client.V1ResourceRequirements(
                requests={"cpu": "1", "memory": "2Gi"},
                limits={"cpu": "2", "memory": "4Gi"},
            ),
            volume_mounts=[
                client.V1VolumeMount(name="dshm", mount_path="/dev/shm"),
                client.V1VolumeMount(name="workspace", mount_path="/workspace"),
            ],
            security_context=client.V1SecurityContext(
                allow_privilege_escalation=False,
            ),
        )

        spec_kwargs: dict = {
            "restart_policy": "Never",
            "containers": [container],
            "volumes": [
                client.V1Volume(
                    name="dshm",
                    empty_dir=client.V1EmptyDirVolumeSource(
                        medium="Memory", size_limit="1Gi"
                    ),
                ),
                client.V1Volume(
                    name="workspace",
                    empty_dir=client.V1EmptyDirVolumeSource(size_limit="5Gi"),
                ),
            ],
        }
        if self.service_account:
            spec_kwargs["service_account_name"] = self.service_account
        if self.image_pull_secret:
            spec_kwargs["image_pull_secrets"] = [
                client.V1LocalObjectReference(name=self.image_pull_secret)
            ]

        pod = client.V1Pod(
            metadata=client.V1ObjectMeta(
                name=name,
                namespace=self.namespace,
                labels={
                    "app": "deepagents-sandbox",
                    "browser": "true",
                    "sandbox-id": name,
                },
            ),
            spec=client.V1PodSpec(**spec_kwargs),
        )
        self.api.create_namespaced_pod(self.namespace, pod)
        self._wait_running(name, timeout=240)

        backend = AKSSandbox(
            name=name,
            namespace=self.namespace,
            api=self.api,
            working_dir="/workspace",
        )
        # Smoke-check tools exist
        check = backend.execute(
            "command -v agent-browser && (chromium --version || google-chrome --version || true)",
            timeout=60,
        )
        if check.exit_code != 0:
            raise RuntimeError(f"Browser tools missing in pod: {check.output}")

        return backend

    def _wait_running(self, name: str, timeout: int = 240) -> None:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            pod = self.api.read_namespaced_pod(name, self.namespace)
            phase = pod.status.phase
            if phase == "Running":
                return
            if phase in ("Failed", "Succeeded"):
                raise RuntimeError(f"Pod {name} phase={phase}")
            time.sleep(2)
        raise TimeoutError(f"Pod {name} not Running within {timeout}s")

    def delete(self, sandbox: AKSSandbox | str) -> None:
        name = sandbox._name if isinstance(sandbox, AKSSandbox) else sandbox
        try:
            self.api.delete_namespaced_pod(
                name=name,
                namespace=self.namespace,
                body=client.V1DeleteOptions(grace_period_seconds=0),
            )
        except ApiException as e:
            if e.status != 404:
                raise

    def get_or_create(self, *, sandbox_id: str) -> AKSSandbox:
        """Thread-scoped reuse: reattach if pod still exists."""
        name = sandbox_id[:63].rstrip("-")
        try:
            self.api.read_namespaced_pod(name, self.namespace)
            return AKSSandbox(
                name=name, namespace=self.namespace, api=self.api, working_dir="/workspace"
            )
        except ApiException as e:
            if e.status != 404:
                raise
            return self.create(name=name)


def browser_cmd(session: str, *parts: str, no_sandbox: bool = True) -> str:
    """Build a stable agent-browser command string for execute()."""
    args = '--args "--no-sandbox --disable-dev-shm-usage"' if no_sandbox else ""
    body = " ".join(parts)
    return f"agent-browser --session {session} {args} {body}".strip()


def warm_browser(backend: AKSSandbox, session: str = DEFAULT_SESSION) -> None:
    """Open a blank page so the first agent turn is faster."""
    r = backend.execute(browser_cmd(session, "open", "about:blank"), timeout=120)
    if r.exit_code != 0:
        raise RuntimeError(f"Failed to warm browser: {r.output}")