"""aks_sandbox.py — Deep Agents BaseSandbox backed by an AKS pod."""

from __future__ import annotations

import base64
import shlex
import time
import uuid
from typing import Optional

from kubernetes import client, config, watch
from kubernetes.client.rest import ApiException
from kubernetes.stream import stream

from deepagents.backends.protocol import (
    ExecuteResponse,
    FileDownloadResponse,
    FileUploadResponse,
)
from deepagents.backends.sandbox import BaseSandbox


class AKSSandbox(BaseSandbox):
    """
    Sandbox backend that runs commands inside a Kubernetes pod on AKS.

    Lifecycle of the Pod is owned by the caller (or by AKSSandboxManager below).
    BaseSandbox implements ls/read/write/edit/glob/grep on top of execute()
    and upload_files()/download_files().
    """

    def __init__(
        self,
        *,
        name: str,
        namespace: str = "default",
        container: str = "sandbox",
        api: Optional[client.CoreV1Api] = None,
        default_timeout: int = 30 * 60,
        working_dir: str = "/workspace",
    ) -> None:
        self._name = name
        self._namespace = namespace
        self._container = container
        self._default_timeout = default_timeout
        self._working_dir = working_dir
        self._api = api or self._load_api()

    @staticmethod
    def _load_api() -> client.CoreV1Api:
        # Prefer in-cluster if the agent host runs on AKS; else local kubeconfig.
        try:
            config.load_incluster_config()
        except config.ConfigException:
            config.load_kube_config()
        return client.CoreV1Api()

    @property
    def id(self) -> str:
        return f"{self._namespace}/{self._name}"

    # ------------------------------------------------------------------
    # Core: execute
    # ------------------------------------------------------------------

    def execute(self, command: str, *, timeout: int | None = None) -> ExecuteResponse:
        """Run a shell command in the pod and return stdout/stderr + exit code."""
        effective_timeout = timeout if timeout is not None else self._default_timeout

        # cd into working dir so relative paths match BaseSandbox expectations
        wrapped = f"cd {shlex.quote(self._working_dir)} && {command}"

        # Capture exit code explicitly (exec stream does not always surface it cleanly)
        script = (
            f"set +e; "
            f"({wrapped}); "
            f"ec=$?; "
            f"printf '\\n__DEEPAGENTS_EXIT_CODE__=%s\\n' \"$ec\"; "
            f"exit $ec"
        )

        try:
            resp = stream(
                self._api.connect_get_namespaced_pod_exec,
                self._name,
                self._namespace,
                container=self._container,
                command=["/bin/bash", "-lc", script],
                stderr=True,
                stdin=False,
                stdout=True,
                tty=False,
                _preload_content=False,
            )
        except ApiException as e:
            return ExecuteResponse(
                output=f"k8s exec failed: {e}",
                exit_code=1,
                truncated=False,
            )

        chunks: list[str] = []
        deadline = time.monotonic() + effective_timeout
        try:
            while resp.is_open():
                if time.monotonic() > deadline:
                    resp.close()
                    return ExecuteResponse(
                        output="".join(chunks) + "\n[timeout]",
                        exit_code=124,
                        truncated=False,
                    )
                resp.update(timeout=1)
                if resp.peek_stdout():
                    chunks.append(resp.read_stdout())
                if resp.peek_stderr():
                    chunks.append(resp.read_stderr())
        finally:
            resp.close()

        output = "".join(chunks)
        exit_code = 0
        marker = "__DEEPAGENTS_EXIT_CODE__="
        if marker in output:
            # Strip marker line from LLM-visible output
            lines = output.splitlines()
            kept = []
            for line in lines:
                if line.startswith(marker):
                    try:
                        exit_code = int(line.split("=", 1)[1].strip())
                    except ValueError:
                        exit_code = 1
                else:
                    kept.append(line)
            output = "\n".join(kept)

        # Soft truncation (BaseSandbox / harness may also truncate)
        max_bytes = 200_000
        truncated = False
        if len(output.encode("utf-8", errors="replace")) > max_bytes:
            output = output.encode("utf-8", errors="replace")[:max_bytes].decode(
                "utf-8", errors="replace"
            )
            truncated = True

        return ExecuteResponse(
            output=output,
            exit_code=exit_code,
            truncated=truncated,
        )

    # ------------------------------------------------------------------
    # File transfer (required by BaseSandbox for write / large payloads)
    # ------------------------------------------------------------------

    def upload_files(self, files: list[tuple[str, bytes]]) -> list[FileUploadResponse]:
        results: list[FileUploadResponse] = []
        for path, content in files:
            if not path.startswith("/"):
                results.append(FileUploadResponse(path=path, error="invalid_path"))
                continue
            try:
                b64 = base64.b64encode(content).decode("ascii")
                parent = path.rsplit("/", 1)[0] or "/"
                # Write atomically via temp file
                cmd = (
                    f"mkdir -p {shlex.quote(parent)} && "
                    f"echo {shlex.quote(b64)} | base64 -d > {shlex.quote(path)}.tmp && "
                    f"mv {shlex.quote(path)}.tmp {shlex.quote(path)}"
                )
                resp = self.execute(cmd, timeout=120)
                if resp.exit_code != 0:
                    results.append(
                        FileUploadResponse(
                            path=path,
                            error=resp.output.strip() or "upload_failed",
                        )
                    )
                else:
                    results.append(FileUploadResponse(path=path, error=None))
            except Exception as e:  # noqa: BLE001 — protocol wants per-file errors
                results.append(FileUploadResponse(path=path, error=str(e)))
        return results

    def download_files(self, paths: list[str]) -> list[FileDownloadResponse]:
        results: list[FileDownloadResponse] = []
        for path in paths:
            if not path.startswith("/"):
                results.append(
                    FileDownloadResponse(path=path, content=None, error="invalid_path")
                )
                continue
            try:
                # Fail clearly if missing or is a directory
                cmd = (
                    f'if [ ! -e {shlex.quote(path)} ]; then echo __NOT_FOUND__; exit 1; fi; '
                    f'if [ -d {shlex.quote(path)} ]; then echo __IS_DIR__; exit 1; fi; '
                    f"base64 {shlex.quote(path)}"
                )
                resp = self.execute(cmd, timeout=120)
                out = (resp.output or "").strip()
                if "__NOT_FOUND__" in out:
                    results.append(
                        FileDownloadResponse(
                            path=path, content=None, error="file_not_found"
                        )
                    )
                elif "__IS_DIR__" in out:
                    results.append(
                        FileDownloadResponse(
                            path=path, content=None, error="is_directory"
                        )
                    )
                elif resp.exit_code != 0:
                    results.append(
                        FileDownloadResponse(
                            path=path, content=None, error=out or "download_failed"
                        )
                    )
                else:
                    # last non-empty base64 lines
                    b64 = "".join(
                        line for line in out.splitlines() if line and not line.startswith("__")
                    )
                    content = base64.b64decode(b64)
                    results.append(
                        FileDownloadResponse(path=path, content=content, error=None)
                    )
            except Exception as e:  # noqa: BLE001
                results.append(
                    FileDownloadResponse(path=path, content=None, error=str(e))
                )
        return results


# ----------------------------------------------------------------------
# Optional: create / delete pods on AKS
# ----------------------------------------------------------------------

SANDBOX_POD_TEMPLATE = {
    # Minimal long-running shell pod; replace image with your hardened base.
    "image": "python:3.12-slim",
    "command": ["sleep", "infinity"],
    "working_dir": "/workspace",
}


class AKSSandboxManager:
    """Create and delete per-thread sandbox pods on AKS."""

    def __init__(
        self,
        *,
        namespace: str = "deepagents-sandboxes",
        image: str = SANDBOX_POD_TEMPLATE["image"],
        service_account: str | None = None,
        resource_requests: dict | None = None,
        resource_limits: dict | None = None,
        node_selector: dict | None = None,
    ) -> None:
        try:
            config.load_incluster_config()
        except config.ConfigException:
            config.load_kube_config()
        self.api = client.CoreV1Api()
        self.namespace = namespace
        self.image = image
        self.service_account = service_account
        self.resource_requests = resource_requests or {"cpu": "250m", "memory": "512Mi"}
        self.resource_limits = resource_limits or {"cpu": "1", "memory": "1Gi"}
        self.node_selector = node_selector

    def ensure_namespace(self) -> None:
        try:
            self.api.read_namespace(self.namespace)
        except ApiException as e:
            if e.status != 404:
                raise
            body = client.V1Namespace(metadata=client.V1ObjectMeta(name=self.namespace))
            self.api.create_namespace(body)

    def create(self, *, name: str | None = None) -> AKSSandbox:
        self.ensure_namespace()
        name = name or f"sandbox-{uuid.uuid4().hex[:10]}"

        container = client.V1Container(
            name="sandbox",
            image=self.image,
            command=SANDBOX_POD_TEMPLATE["command"],
            working_dir=SANDBOX_POD_TEMPLATE["working_dir"],
            resources=client.V1ResourceRequirements(
                requests=self.resource_requests,
                limits=self.resource_limits,
            ),
            # Optional: drop capabilities, read-only root, etc. for hardening
            security_context=client.V1SecurityContext(
                allow_privilege_escalation=False,
                run_as_non_root=False,  # set True + runAsUser if your image supports it
            ),
        )

        pod = client.V1Pod(
            metadata=client.V1ObjectMeta(
                name=name,
                namespace=self.namespace,
                labels={"app": "deepagents-sandbox", "sandbox-id": name},
            ),
            spec=client.V1PodSpec(
                restart_policy="Never",
                containers=[container],
                service_account_name=self.service_account,
                node_selector=self.node_selector,
            ),
        )
        self.api.create_namespaced_pod(self.namespace, pod)
        self._wait_ready(name, timeout=180)
        # Ensure workspace exists
        backend = AKSSandbox(
            name=name,
            namespace=self.namespace,
            api=self.api,
            working_dir=SANDBOX_POD_TEMPLATE["working_dir"],
        )
        backend.execute("mkdir -p /workspace", timeout=30)
        return backend

    def _wait_ready(self, name: str, timeout: int = 180) -> None:
        w = watch.Watch()
        start = time.monotonic()
        for event in w.stream(
            self.api.list_namespaced_pod,
            namespace=self.namespace,
            field_selector=f"metadata.name={name}",
            timeout_seconds=timeout,
        ):
            pod = event["object"]
            phase = pod.status.phase
            if phase == "Running":
                w.stop()
                return
            if phase in ("Failed", "Succeeded"):
                w.stop()
                raise RuntimeError(f"Pod {name} entered phase {phase}")
            if time.monotonic() - start > timeout:
                w.stop()
                raise TimeoutError(f"Pod {name} not ready within {timeout}s")

    def delete(self, sandbox: AKSSandbox | str) -> None:
        name = sandbox._name if isinstance(sandbox, AKSSandbox) else sandbox
        try:
            self.api.delete_namespaced_pod(
                name=name,
                namespace=self.namespace,
                body=client.V1DeleteOptions(grace_period_seconds=0),
            )
        except ApiException as e:
            if e.status != 404:
                raise