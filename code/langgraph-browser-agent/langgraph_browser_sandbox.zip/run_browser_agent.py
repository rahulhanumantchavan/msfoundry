"""run_browser_agent.py"""

import os

from azure.identity import AzureCliCredential, get_bearer_token_provider
from deepagents import create_deep_agent
from langchain_openai import ChatOpenAI

from aks_browser_sandbox import (
    DEFAULT_SESSION,
    AKSBrowserSandboxManager,
    browser_cmd,
    warm_browser,
)

SESSION = DEFAULT_SESSION

DEFAULT_ENDPOINT = "https://rahulhchavan-secondproj-resource.services.ai.azure.com/openai/v1"
DEFAULT_DEPLOYMENT = "gpt-5"
COGNITIVE_SERVICES_SCOPE = "https://cognitiveservices.azure.com/.default"


def build_model() -> ChatOpenAI:
    """Azure OpenAI (v1 endpoint) chat model authenticated via ``az login``.

    The bearer token provider is invoked per request, so tokens refresh automatically.
    """
    token_provider = get_bearer_token_provider(AzureCliCredential(), COGNITIVE_SERVICES_SCOPE)
    return ChatOpenAI(
        base_url=os.getenv("AZURE_OPENAI_ENDPOINT", DEFAULT_ENDPOINT),
        api_key=token_provider,
        model=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", DEFAULT_DEPLOYMENT),
    )

SYSTEM = f"""
You are a coding and browser agent. Shell and files run in an AKS pod under /workspace.
Chrome is available via the agent-browser CLI.

RULES:
- For every browser action use session "{SESSION}".
- Prefer this form:
    agent-browser --session {SESSION} --args "--no-sandbox --disable-dev-shm-usage" <subcommand>
- Workflow: open URL → snapshot -i → click/fill using element ids → new snapshot after navigation.
- Start local apps with host 0.0.0.0 so the browser can open http://127.0.0.1:<port>.
- Save screenshots under /workspace (e.g. /workspace/shot.png).
- Do not use a different session name unless the user asks.

Useful subcommands:
  open <url>
  snapshot -i
  click @eN
  fill @eN "text"
  type @eN "text"
  press Enter
  screenshot /workspace/shot.png
  close
""".strip()


def main() -> None:
    mgr = AKSBrowserSandboxManager(
        namespace="deepagents-sandboxes",
        image="acrinfraeus.azurecr.io/deepagents-browser:v1",
        # image_pull_secret="acr-secret",  # if needed
    )
    print("Creating sandbox pod...")
    backend = mgr.create()  # or mgr.get_or_create(sandbox_id=f"thread-{thread_id}")
    print(f"Sandbox ready: {getattr(backend, '_name', backend)}")

    try:
        print("Warming browser...")
        warm_browser(backend, SESSION)

        agent = create_deep_agent(
            model=build_model(),
            backend=backend,
            system_prompt=SYSTEM,
        )

        # Example 1: public site
        result = agent.invoke(
            {
                "messages": [
                    {
                        "role": "user",
                        "content": (
                            "Open https://example.com, take an interactive snapshot, "
                            "and report the main heading. Save a screenshot to /workspace/example.png."
                        ),
                    }
                ]
            }
        )
        print("--- Agent reply ---")
        print(result["messages"][-1].content)

        # Example 2: app in the same pod (uncomment when you have an app)
        # backend.execute("cd /workspace && python -m http.server 3000", timeout=1)  # bad: blocks
        # Prefer: start server in background inside the pod:
        # backend.execute(
        #     "cd /workspace && nohup python -m http.server 3000 > /tmp/http.log 2>&1 & echo $!",
        #     timeout=30,
        # )
        # backend.execute(
        #     "curl --fail --retry 20 --retry-connrefused --retry-delay 1 "
        #     "--retry-max-time 30 http://127.0.0.1:3000/",
        #     timeout=60,
        # )
        # agent.invoke({"messages": [{"role": "user", "content":
        #     "Open http://127.0.0.1:3000, snapshot, describe what you see."}]})

        # Optional: pull screenshot to local disk
        try:
            files = backend.download_files(["/workspace/example.png"])
            for f in files:
                if getattr(f, "content", None) and not getattr(f, "error", None):
                    with open("example.png", "wb") as out:
                        out.write(f.content)
                    print("Saved example.png locally")
        except Exception as e:
            print(f"Download skipped: {e}")

    finally:
        print("Deleting sandbox pod...")
        mgr.delete(backend)
        print("Done.")


if __name__ == "__main__":
    main()