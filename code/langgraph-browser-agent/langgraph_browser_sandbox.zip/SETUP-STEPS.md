az acr login -n acrinfraeus  

docker build -f dockerfile -t acrinfraeus.azurecr.io/deepagents-browser:v1 .

docker push acrinfraeus.azurecr.io/deepagents-browser:v1


-------------------------------------------------------------------------------------------------
az account set --subscription 7bc369e0-c292-4f04-a549-0803d2052650

az aks get-credentials -n devaksclusrer -g RG-AKS

kubectl create namespace deepagents-sandboxes

kubectl apply -f rbac-sandbox.yaml

kubectl -n deepagents-sandboxes run browser-smoke \
  --image=acrinfraeus.azurecr.io/deepagents-browser:v1 \
  --restart=Never \
  --command -- sleep infinity

kubectl -n deepagents-sandboxes wait --for=condition=Ready pod/browser-smoke --timeout=180s

kubectl -n deepagents-sandboxes exec -it browser-smoke -- bash -lc '
  command -v agent-browser
  agent-browser --session test --args "--no-sandbox --disable-dev-shm-usage" open https://example.com
  agent-browser --session test snapshot -i | head -40
  agent-browser --session test screenshot /workspace/t.png || agent-browser --session test screenshot /tmp/t.png
  ls -la /workspace /tmp 2>/dev/null | head
'

----------------------------------------------------------------------------------------------------------

pip install kubernetes deepagents langchain-openai azure-identity

# Model: Azure OpenAI v1 endpoint, authenticated with Azure CLI (no API key)
az login
$env:AZURE_OPENAI_ENDPOINT = "https://rahulhchavan-secondproj-resource.services.ai.azure.com/openai/v1"
$env:AZURE_OPENAI_DEPLOYMENT_NAME = "gpt-5"
python run_browser_agent.py


