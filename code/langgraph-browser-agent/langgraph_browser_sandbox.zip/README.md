# Sandbox Browser Agent on AKS

A **Deep Agents** (LangGraph) coding and browser agent. The agent's reasoning runs on your machine. Its shell commands, files and a headless **Chromium** browser run inside a short-lived **Kubernetes pod on Azure Kubernetes Service (AKS)**. The LLM is **Azure OpenAI (GPT-5)**, and it signs in with Azure CLI credentials, so you don't need an API key.

The agent drives the browser with the [`agent-browser`](https://www.npmjs.com/package/agent-browser) CLI. It sends `agent-browser` commands through the sandbox's `execute()` tool, which runs `kubectl exec` under the hood.

---

## Architecture

```mermaid
flowchart LR
    subgraph Local["Local machine / Agent host"]
        RUN["run_browser_agent.py<br/>(entry point)"]
        AGENT["Deep Agent<br/>(deepagents / LangGraph)"]
        MGR["AKSBrowserSandboxManager<br/>(aks_browser_sandbox.py)"]
        SB["AKSSandbox backend<br/>(aks_sandbox.py)<br/>execute / upload / download"]
        CRED["AzureCliCredential<br/>(az login)"]
    end

    subgraph Azure["Azure"]
        AOAI["Azure OpenAI<br/>v1 endpoint (gpt-5)"]
        ACR["Azure Container Registry<br/>acrinfraeus / deepagents-browser:v1"]

        subgraph AKS["AKS cluster"]
            API["Kubernetes API server<br/>(RBAC: deepagents-sandbox Role)"]
            subgraph NS["Namespace: deepagents-sandboxes"]
                subgraph POD["Pod: browser-xxxxxxxxxx"]
                    SH["bash shell<br/>/workspace (emptyDir 5Gi)"]
                    AB["agent-browser CLI<br/>session 'qa'"]
                    CHR["Chromium (Playwright)<br/>/dev/shm (memory 1Gi)"]
                end
            end
        end
    end

    WEB["Target websites / <br/>local apps on 127.0.0.1"]

    RUN --> MGR
    RUN --> AGENT
    AGENT -- "chat completions<br/>(bearer token)" --> AOAI
    CRED -. token .-> AGENT
    AGENT -- "tool calls" --> SB
    MGR -- "create / wait / delete pod" --> API
    SB -- "pods/exec (stream)" --> API
    API --> POD
    ACR -- "image pull" --> POD
    SH --> AB --> CHR --> WEB
```

### Components

| File | Purpose |
|------|---------|
| [`run_browser_agent.py`](run_browser_agent.py) | Entry point. Builds the Azure OpenAI model, creates the sandbox pod, warms up the browser, runs the Deep Agent with a browser system prompt, downloads the screenshot and then deletes the pod. |
| [`aks_browser_sandbox.py`](aks_browser_sandbox.py) | `AKSBrowserSandboxManager` creates long-lived browser pods (CPU and memory limits, `/dev/shm` and `/workspace` volumes), waits for `Running`, and checks that `agent-browser` and Chromium are present. Also contains the helpers `browser_cmd()` and `warm_browser()`, and `get_or_create()` for reusing a pod per thread. |
| [`aks_sandbox.py`](aks_sandbox.py) | `AKSSandbox` is a Deep Agents `BaseSandbox` implementation. `execute()` runs commands through the Kubernetes exec stream and captures the exit code. `upload_files()` and `download_files()` move files as base64. Also includes a general-purpose `AKSSandboxManager` that does not include a browser. |
| [`dockerfile`](dockerfile) | Sandbox image built on `mcr.microsoft.com/playwright:v1.48.0-noble`, with Python 3, `agent-browser` (npm) and Chromium. It runs `sleep infinity`. |
| [`rbac-sandbox.yaml`](rbac-sandbox.yaml) | Contains the ServiceAccount `deepagents-runner` and a Role/RoleBinding that allow pod `create/get/list/watch/delete` and `pods/exec`, `pods/log`. |
| [`SETUP-STEPS.md`](SETUP-STEPS.md) | Commands to build and push the image, set up the cluster, run a smoke test and run the agent. |

---

## Execution Flow

```mermaid
sequenceDiagram
    autonumber
    participant U as User / run_browser_agent.py
    participant M as AKSBrowserSandboxManager
    participant K as AKS API Server
    participant P as Sandbox Pod
    participant A as Deep Agent
    participant L as Azure OpenAI (gpt-5)

    U->>M: create()
    M->>K: ensure namespace + create Pod (image from ACR)
    loop every 2s (≤240s)
        M->>K: read pod status
    end
    K-->>M: phase = Running
    M->>P: exec "command -v agent-browser && chromium --version"
    M-->>U: AKSSandbox backend

    U->>P: warm_browser(): agent-browser --session qa open about:blank

    U->>A: create_deep_agent(model, backend, system_prompt)
    U->>A: invoke("Open https://example.com ...")
    loop Agent reasoning loop
        A->>L: messages + tools
        L-->>A: tool call (execute / read / write ...)
        A->>P: execute("agent-browser --session qa open|snapshot -i|click @eN|screenshot ...")
        P-->>A: stdout/stderr + exit code
    end
    A-->>U: final answer

    U->>P: download_files(["/workspace/example.png"])
    P-->>U: base64 → example.png (local)
    U->>M: delete(backend)
    M->>K: delete pod (grace 0)
```

### Browser workflow used by the agent

1. `open <url>` loads the page.
2. `snapshot -i` returns an interactive accessibility snapshot with element refs (`@e1`, `@e2`, …).
3. `click @eN`, `fill @eN "text"`, `type`, `press Enter` interact with the page.
4. After each navigation, the agent takes a new snapshot.
5. `screenshot /workspace/<file>.png` saves an image, which can then be downloaded locally.

Every command uses `--session qa --args "--no-sandbox --disable-dev-shm-usage"`, so the same browser instance carries over between `execute()` calls.

---

## Technology Stack

| Layer | Technology |
|-------|-----------|
| Agent framework | [Deep Agents](https://github.com/langchain-ai/deepagents) (`create_deep_agent`, `BaseSandbox`) on **LangGraph** / **LangChain** |
| LLM | **Azure OpenAI** v1 endpoint (`gpt-5`) via `langchain-openai` `ChatOpenAI` |
| Authentication | `azure-identity` `AzureCliCredential` + `get_bearer_token_provider` (Entra ID token, auto-refresh) |
| Sandbox runtime | **Azure Kubernetes Service (AKS)** pods, managed with the `kubernetes` Python client (exec stream) |
| Container image | `mcr.microsoft.com/playwright` (Ubuntu Noble), **Chromium**, **Node.js**, **Python 3** |
| Browser automation | `agent-browser` CLI (npm) on top of Playwright/Chromium |
| Registry | **Azure Container Registry** (`acrinfraeus.azurecr.io`) |
| Access control | Kubernetes RBAC (ServiceAccount, Role, RoleBinding) |
| Language | Python 3.12+ |

---

## Prerequisites

- Azure subscription with access to an AKS cluster and an ACR
- Azure CLI (`az`), `kubectl` and Docker
- Python 3.10 or later
- An Azure OpenAI deployment where your identity has the **Cognitive Services OpenAI User** role

## Quick Start

```powershell
# 1. Build & push the sandbox image
az acr login -n acrinfraeus
docker build -f dockerfile -t acrinfraeus.azurecr.io/deepagents-browser:v1 .
docker push acrinfraeus.azurecr.io/deepagents-browser:v1

# 2. Cluster access + RBAC
az aks get-credentials -n devaksclusrer -g RG-AKS
kubectl create namespace deepagents-sandboxes
kubectl apply -f rbac-sandbox.yaml

# 3. Python deps
pip install kubernetes deepagents langchain-openai azure-identity

# 4. Run
az login
$env:AZURE_OPENAI_ENDPOINT = "https://<your-resource>.services.ai.azure.com/openai/v1"
$env:AZURE_OPENAI_DEPLOYMENT_NAME = "gpt-5"
python run_browser_agent.py
```

For the full steps, including a manual smoke test of the pod, see [SETUP-STEPS.md](SETUP-STEPS.md).

### Configuration

| Env var | Default | Description |
|---------|---------|-------------|
| `AZURE_OPENAI_ENDPOINT` | `https://rahulhchavan-secondproj-resource.services.ai.azure.com/openai/v1` | Azure OpenAI v1 base URL |
| `AZURE_OPENAI_DEPLOYMENT_NAME` | `gpt-5` | Model deployment name |

You can also pass these settings to `AKSBrowserSandboxManager(...)`: `namespace`, `image`, `image_pull_secret` and `service_account`.

---

## Pod Spec Highlights

- **Resources:** requests 1 CPU / 2Gi, limits 2 CPU / 4Gi
- **Volumes:** `/dev/shm` is a 1Gi in-memory `emptyDir` so Chromium has enough shared memory. `/workspace` is a 5Gi `emptyDir`.
- **Security:** `allowPrivilegeEscalation: false`, `restartPolicy: Never`
- **Labels:** `app=deepagents-sandbox`, `browser=true`, `sandbox-id=<name>`
- **Lifecycle:** one pod per run, deleted in a `finally` block. Use `get_or_create(sandbox_id=...)` to reuse a pod per thread.

## Notes

- To test local apps inside the pod, start them in the background, bound to `0.0.0.0` (for example `nohup python -m http.server 3000 &`). Then have the agent open `http://127.0.0.1:<port>`.
- `--no-sandbox` is required because Chromium runs as root in a container. The pod itself is the isolation boundary.
