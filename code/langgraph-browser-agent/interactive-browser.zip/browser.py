"""Browser lifecycle for the self-hosted deep agent.

Replaces Managed Deep Agents' ``define_browser`` with a locally launched Chrome
driven by Stagehand. Your application owns the browser and must close it.

Scope (mirrors the managed ``scope`` option):
- ``thread``: fresh, temporary profile per session; no cookies/logins carried over.
- ``user``:   persistent profile directory under ``.browser-profiles/<user_id>``,
              so website logins survive across sessions for that user.
"""

from __future__ import annotations

import os
import re
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncIterator, Literal

from stagehand import Stagehand, local_browser

BrowserScope = Literal["thread", "user"]

PROFILES_DIR = Path(__file__).parent / ".browser-profiles"


def _safe(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]", "_", name) or "default"


@asynccontextmanager
async def open_browser(
    *,
    scope: BrowserScope = "thread",
    user_id: str = "default",
    headless: bool | None = None,
) -> AsyncIterator[Stagehand]:
    """Launch local Chrome and yield a Stagehand client bound to it."""
    if headless is None:
        headless = os.getenv("BROWSER_HEADLESS", "false").lower() == "true"

    launch_kwargs: dict = {
        "headless": headless,
        "viewport_width": 1280,
        "viewport_height": 800,
    }
    if executable := os.getenv("CHROME_PATH"):
        launch_kwargs["executable_path"] = executable
    if scope == "user":
        profile = PROFILES_DIR / _safe(user_id)
        profile.mkdir(parents=True, exist_ok=True)
        launch_kwargs["user_data_dir"] = profile
        launch_kwargs["preserve_user_data_dir"] = True

    browser = await local_browser.launch(**launch_kwargs)
    try:
        yield await Stagehand.create(browser=browser)
    finally:
        await browser.close()
