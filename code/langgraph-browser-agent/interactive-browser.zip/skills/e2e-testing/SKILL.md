---
name: e2e-testing
description: Verify a web app change end-to-end by driving it in the browser and optionally saving the steps as a Playwright test.
---

# End-to-end testing with the browser

Use this skill when asked to check that a web page or app flow works.

1. Open the target URL with `run` (local Chrome can reach apps on this machine's
   `localhost:<port>`).
2. `snapshot` to get element IDs.
3. Drive the flow with one `run` per logical step (fill form, submit,
   assert the expected text/URL appears).
4. Report pass/fail with the observed evidence (text, URL, screenshot if useful).
5. If asked, combine the `run` code into a Playwright test file (use `write_file`)
   so later runs can replay it without model calls.
