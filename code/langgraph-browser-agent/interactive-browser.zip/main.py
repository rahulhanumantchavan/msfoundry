"""Interactive CLI for the browsing deep agent.

Usage:
    uv run main.py                              # thread scope, fresh browser
    uv run main.py --scope user --user alice    # persist logins for "alice"
    uv run main.py --approve                    # approve every browser `run` call
    uv run main.py --task "Open news.ycombinator.com and summarize the top 3 stories"
"""

from __future__ import annotations

import argparse
import asyncio
import json
import uuid

from dotenv import load_dotenv
from langgraph.types import Command

from agent import build_agent
from browser import open_browser


def _final_text(result: dict) -> str:
    message = result["messages"][-1]
    content = message.content
    if isinstance(content, list):
        return "\n".join(b.get("text", "") for b in content if isinstance(b, dict))
    return str(content)


def _review(interrupts) -> dict:
    """Ask the human to approve or reject each pending tool call."""
    decisions = []
    for request in interrupts[0].value["action_requests"]:
        print(f"\n[APPROVAL] Tool `{request['name']}` wants to run:")
        print(json.dumps(request["args"], indent=2, ensure_ascii=False))
        answer = input("Approve? [y/N]: ").strip().lower()
        if answer == "y":
            decisions.append({"type": "approve"})
        else:
            reason = input("Reason for rejecting (sent to the agent): ").strip()
            decisions.append({"type": "reject", "message": reason or "Rejected by user."})
    return {"decisions": decisions}


async def ask(agent, config: dict, text: str) -> str:
    result = await agent.ainvoke({"messages": [{"role": "user", "content": text}]}, config)
    while result.get("__interrupt__"):
        result = await agent.ainvoke(Command(resume=_review(result["__interrupt__"])), config)
    return _final_text(result)


async def main() -> None:
    load_dotenv()
    parser = argparse.ArgumentParser(description="Browsing deep agent (Azure OpenAI)")
    parser.add_argument("--scope", choices=["thread", "user"], default="thread")
    parser.add_argument("--user", default="default", help="User id for --scope user")
    parser.add_argument("--headless", action="store_true", help="Run Chrome without a window")
    parser.add_argument("--approve", action="store_true", help="Require approval for `run`")
    parser.add_argument("--task", help="Run one task and exit")
    args = parser.parse_args()

    async with open_browser(
        scope=args.scope, user_id=args.user, headless=args.headless or None
    ) as stagehand:
        agent = build_agent(stagehand, require_approval=args.approve)
        config = {"configurable": {"thread_id": str(uuid.uuid4())}, "recursion_limit": 200}

        if args.task:
            print(await ask(agent, config, args.task))
            return

        print("Browsing agent ready. Type a task, or 'exit' to quit.")
        while True:
            text = (await asyncio.to_thread(input, "\nYou: ")).strip()
            if text.lower() in {"exit", "quit"}:
                break
            if text:
                print(f"\nAgent: {await ask(agent, config, text)}")


if __name__ == "__main__":
    asyncio.run(main())
