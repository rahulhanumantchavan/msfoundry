"""Self-hosted Deep Agent with browser use, powered by Azure OpenAI.

Equivalent of the Managed Deep Agents browsing agent, without LangSmith:
- Model: Azure OpenAI (``AzureChatOpenAI``)
- Browser: local Chrome via Stagehand (``run``, ``snapshot``, ``screenshot`` tools)
- Human handoff: ``browser_handoff`` tool — you act in the visible Chrome window
- Approval: optional human approval before every ``run`` call
"""

from __future__ import annotations

import os
from pathlib import Path

from azure.identity import AzureCliCredential, get_bearer_token_provider
from deepagents import create_deep_agent
from deepagents.backends import FilesystemBackend
from langchain.tools import tool
from langchain_openai import ChatOpenAI
from langchain_stagehand import StagehandMiddleware
from langgraph.checkpoint.memory import InMemorySaver
from stagehand import Stagehand

PROJECT_ROOT = Path(__file__).parent

DEFAULT_ENDPOINT = "https://rahulhchavan-secondproj-resource.services.ai.azure.com/openai/v1"
DEFAULT_DEPLOYMENT = "gpt-5"
COGNITIVE_SERVICES_SCOPE = "https://cognitiveservices.azure.com/.default"


def build_model() -> ChatOpenAI:
    """Azure OpenAI (v1 endpoint) chat model authenticated with the Azure CLI login.

    Uses a bearer token from ``az login`` instead of an API key. The token provider
    is called per request, so expired tokens are refreshed automatically.
    """
    token_provider = get_bearer_token_provider(AzureCliCredential(), COGNITIVE_SERVICES_SCOPE)
    return ChatOpenAI(
        base_url=os.getenv("AZURE_OPENAI_ENDPOINT", DEFAULT_ENDPOINT),
        api_key=token_provider,
        model=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", DEFAULT_DEPLOYMENT),
    )


@tool
def browser_handoff(reason: str) -> str:
    """Hand the browser to the human for login, CAPTCHA, or two-factor authentication.

    Blocks until the human has finished in the visible Chrome window and pressed Enter.
    Never ask for passwords in chat; use this tool instead.

    Args:
        reason: Short explanation of what the human needs to do.
    """
    print(f"\n[HANDOFF] The agent needs you in the browser: {reason}")
    input("Complete the step in the Chrome window, then press Enter to hand back... ")
    return "The human handed control back. Take a new snapshot to verify the page state."


def build_agent(stagehand: Stagehand, *, require_approval: bool = False):
    """Create the deep agent bound to a running Stagehand browser."""
    instructions = (PROJECT_ROOT / "instructions.md").read_text(encoding="utf-8")

    return create_deep_agent(
        name="browsing",
        model=build_model(),
        system_prompt=instructions,
        tools=[browser_handoff],
        middleware=[StagehandMiddleware(stagehand=stagehand)],
        # Files and skills are read from this project folder (virtual root "/").
        backend=FilesystemBackend(root_dir=PROJECT_ROOT, virtual_mode=True),
        skills=["/skills/"],
        interrupt_on={"run": True} if require_approval else None,
        checkpointer=InMemorySaver(),
    )
