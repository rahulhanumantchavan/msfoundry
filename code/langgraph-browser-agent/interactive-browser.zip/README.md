# Browsing Deep Agent (Azure OpenAI + local Chrome)

A [Deep Agents](https://docs.langchain.com/oss/python/deepagents/overview) agent that
uses a real browser to do work on websites: navigating, clicking, filling forms,
reading JS-rendered pages and testing web apps end to end.

It follows the approach described in
[Browser Use in Managed Deep Agents](https://www.langchain.com/blog/browser-use-in-managed-deep-agents)
but is **self-hosted**, so it needs **no LangSmith account**:

| Managed Deep Agents | This project |
| --- | --- |
| LangSmith-hosted runtime (`mda dev` / `mda deploy`) | Runs locally with `uv run main.py` |
| `define_browser(...)` remote browser sandbox | Local Chrome launched by [Stagehand](https://www.stagehand.dev/) (`browser.py`) |
| `browser_snapshot` / `browser_run` / `browser_screenshot` | `snapshot` / `run` / `screenshot` via `StagehandMiddleware` |
| `browser_handoff` (Studio card + **Hand back**) | `browser_handoff` tool: act in the Chrome window, press **Enter** to hand back |
| `scope="thread"` / `scope="user"` | `--scope thread` (temporary profile) / `--scope user` (persistent profile per user) |
| `openai:gpt-5.5` + `OPENAI_API_KEY` | Azure OpenAI `gpt-5` (v1 endpoint) with Azure CLI auth |

## Project structure

```text
interactive-browser/
├── agent.py                    # Azure OpenAI model + deep agent (tools, skills, approval)
├── browser.py                  # Local Chrome / Stagehand lifecycle and browser scope
├── main.py                     # Interactive CLI (chat loop, approvals, handoff)
├── instructions.md             # System prompt
├── skills/
│   └── e2e-testing/SKILL.md    # Skill: end-to-end test a web app through its UI
├── pyproject.toml              # Dependencies (uv)
├── .env.example                # Environment variable template
└── .gitignore
```

## Prerequisites

- Python 3.11+ and [uv](https://docs.astral.sh/uv/)
- Google Chrome or Chromium installed locally
- [Azure CLI](https://learn.microsoft.com/cli/azure/install-azure-cli), signed in with `az login`
- A `gpt-5` deployment on the Azure AI Foundry / Azure OpenAI resource. Your
  account needs the **Cognitive Services OpenAI User** role (or higher) on it.

## Setup

```powershell
cd interactive-browser

# 1. Sign in to Azure (the agent authenticates with this login, no API key)
az login

# 2. Install dependencies
uv sync

# 3. (Optional) configure environment; defaults are already in agent.py
Copy-Item .env.example .env
```

`.env`:

```dotenv
# Auth uses your Azure CLI login (`az login`), no API key needed.
AZURE_OPENAI_ENDPOINT=https://rahulhchavan-secondproj-resource.services.ai.azure.com/openai/v1
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-5

# Optional
# BROWSER_HEADLESS=false
# CHROME_PATH=C:\Program Files\Google\Chrome\Application\chrome.exe
LANGSMITH_TRACING=false
```

## Run

```powershell
# Interactive chat; Chrome opens visibly, with a fresh profile per session
uv run main.py

# Single task
uv run main.py --task "Open news.ycombinator.com and summarize the top 3 stories"

# Keep website logins across sessions for a user
uv run main.py --scope user --user alice

# Approve every browser `run` call before it executes
uv run main.py --approve

# No visible window
uv run main.py --headless
```

### CLI options

| Option | Default | Description |
| --- | --- | --- |
| `--scope` | `thread` | `thread`: temporary browser profile. `user`: persistent profile in `.browser-profiles/<user>` |
| `--user` | `default` | User ID for `--scope user` |
| `--approve` | off | Human approval before each `run` tool call |
| `--headless` | off | Run Chrome without a window. Handoff is not possible in this mode |
| `--task` | — | Run one task and exit |

## How it works

1. `browser.py` launches local Chrome with `stagehand.local_browser` and creates a
   `Stagehand` client.
2. `agent.py` builds a deep agent with `create_deep_agent`:
   - `gpt-5` through `ChatOpenAI` pointed at the Azure OpenAI `/openai/v1` endpoint.
     It authenticates with `AzureCliCredential`, and a bearer token provider for the
     `https://cognitiveservices.azure.com/.default` scope refreshes tokens per request.
   - `StagehandMiddleware`, which adds the browser tools:
     - `snapshot`: reads the page's accessibility tree and labels elements with IDs
     - `run`: runs batched actions (`click`, `fill`, `type`, `press`, `select`)
       or Playwright-style JavaScript (`page.goto(...)`, etc.)
     - `screenshot`: returns an image of the page to the model
   - `browser_handoff`: pauses so you can sign in, solve a CAPTCHA or complete 2FA
     directly in Chrome. Credentials never go into chat, prompts or traces.
   - `FilesystemBackend` rooted at the project, so the agent can read and write files
     and load `skills/`
   - `InMemorySaver` checkpointer, which keeps conversation state and supports approvals
3. `main.py` runs the chat loop and handles approval interrupts (`approve` / `reject`).

### Login handoff

When the agent reaches a login page, it calls `browser_handoff`. The terminal shows:

```text
[HANDOFF] The agent needs you in the browser: Please sign in to Acme Travel so I can continue.
Complete the step in the Chrome window, then press Enter to hand back...
```

Sign in through the Chrome window, then press **Enter**. The agent takes a new
snapshot and continues. With `--scope user`, the login is kept in the profile and
reused next time.

## Customize

- **Behavior**: edit `instructions.md`.
- **Skills**: add `skills/<name>/SKILL.md` with `name` / `description` frontmatter.
- **Model**: set `AZURE_OPENAI_DEPLOYMENT_NAME` / `AZURE_OPENAI_ENDPOINT`, or edit
  `build_model()` in `agent.py`. To use a managed identity or other non-CLI credentials,
  swap `AzureCliCredential()` for `DefaultAzureCredential()`.

## Troubleshooting

| Error | Fix |
| --- | --- |
| `AzureCliCredential: Please run 'az login'` | Run `az login`, and `az account set -s <subscription>` if needed |
| `401 PermissionDenied` | Assign **Cognitive Services OpenAI User** on the resource to your account |
| `404 DeploymentNotFound` | Check that the deployment name matches `AZURE_OPENAI_DEPLOYMENT_NAME` (`gpt-5`) |
- **Remote browser**: replace `local_browser.launch(...)` with
  `stagehand.browserbase.launch(api_key=...)` to run the browser on Browserbase.

## Security notes

- `run` executes JavaScript written by the model inside the browser. That code can
  use any account the browser is signed in to. Use test accounts for risky flows, and
  use `--approve` for anything that could make purchases or submit data.
- Treat page content as untrusted input, since a page can include text meant to
  redirect the agent.
- `.browser-profiles/` holds session cookies. Keep it private (it is in `.gitignore`).
- Never commit `.env`.

## Notes

- `langchain-stagehand` is not on PyPI yet. It is installed from the git revision
  used in the LangChain docs (see `pyproject.toml`).
- The browser tools are async, so the agent is invoked with `ainvoke`.
